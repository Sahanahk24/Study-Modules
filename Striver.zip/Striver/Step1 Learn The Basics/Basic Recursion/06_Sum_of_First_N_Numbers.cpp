#include <iostream>
using namespace std;

// int print_first_N_Numbers(int start, int count, int num)
// {
//     if(start>num)
//     {
//         return count;
//     }
//     return print_first_N_Numbers(start+1, count+start, num);
// }

// int print_Sum_first_N_Numbers(int num, int sum)
// {
//     if(num<0)
//     {
//         return sum;
//     }
//     return print_Sum_first_N_Numbers(num-1, sum+num);
// }

int print_sum(int num)
{
    if(num==0)
    {
        return 0;
    }
    return print_sum(num - 1) + num;
}

int main()
{
    // int start;
    // cout<<"Enter start limit: ";
    // cin>>start;
    int num;
    cout<<"Enter Nth number: ";
    cin>>num;
    // cout<<"Sum of numbers from "<<start<<" and "<<num<<" : "<<print_first_N_Numbers(start, 0 , num)<<endl;
    // cout<<"Sum of 1st "<<num<<" : "<<"nums: "<<print_Sum_first_N_Numbers(num, 0)<<endl;
    cout<<"Sum of 1st "<<num<<" : "<<"nums: "<<print_sum(num)<<endl;
    return 0;
}