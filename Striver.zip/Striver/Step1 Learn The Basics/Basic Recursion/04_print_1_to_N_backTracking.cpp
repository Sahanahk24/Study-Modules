#include <iostream>
using namespace std;

void print_1_to_N(int start, int num)
{
    if(start>num)
    {
        return;
    }
    //cout<<start<<endl;
    print_1_to_N(start+1, num);
    cout<<start<<endl;
}

int main()
{
    int i;
    cout<<"Enter the number: ";
    cin>>i;
    print_1_to_N(1, i);
    return 0;
}