#include <iostream>
#include <string>
using namespace std;


int x = 0;

void printNameRecursively(string name, int start, int num)
{
    if(start > num)
    {
        return;
    }
    cout<<name<<endl;
    printNameRecursively(name, start++ , num);
}

//either use start+1 or ++start
/*
Passes an incremented start (using start++) during the recursive call. However, postfix increment does not modify start in the current call, so start remains the same in each call. This effectively leads to infinite recursion unless start is adjusted.
*/

void func(int i, int n){
   
   // Base Condition.
   if(i>n)
   {
        return;
   }

   cout<<"Raj"<<endl;

   // Function call to print till i increments.
   func(i+1,n);

}

int main()
{   
    string name;
    int num;
    cout<<"Enter the name : ";
    getline(cin,name);
    cout<<"Enter the number of times to print "<<name<<" : ";
    cin>>num;
    printNameRecursively(name, 1, num);
    func(1,10);
    return 0;
}