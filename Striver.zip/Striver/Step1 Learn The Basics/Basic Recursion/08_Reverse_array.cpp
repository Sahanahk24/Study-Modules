#include <iostream>
#include <vector>
using namespace std;

void reverseArrayUsingRecursion(int arr[], int size)
{   
    if(size<=0)
    {
        return;
    }
    cout<<arr[size-1]<<" ";
    return reverseArrayUsingRecursion(arr, size - 1);
}

void reverseArrayUsingRecursion_2(int arr[], int start, int end)
{   
    if(start>=end)
    {
        return;
    }
    swap(arr[start],arr[end]);
    return reverseArrayUsingRecursion_2(arr, start+1, end-1);
}

void reverseArrayUsingForLoop(int arr[], int size)
{
    for(int i=size-1; i>=0; i--)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

void reverseArrayUsingWhileLoop(int arr[], int size)
{
    int i=0;
    int j = size-1;
    while(i<=j)
    {
        swap(arr[i], arr[j]);
        i++;
        j--;
    }

    for(int i=0; i<=size-1; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;

}

void reverseArray(vector<int> &arr) {
        // code here
        int size = arr.size();
        cout<<"size : "<<size<<endl;
        int i=0;
        int j= size-1;
        while(i<=j)
        {
            swap(arr[i], arr[j]);
            i++;
            j--;
        }
    }

int main()
{
    int arr[] = {1,2,3,4,5,6,7,8,9,10};
    vector<int> arr1 = {1,2,3,4,5,6};
    int arr2[] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    int size = sizeof(arr)/sizeof(arr[0]);
    cout<<"size : "<<size<<endl;
    cout<<"Using FOR LOOP\n";
    reverseArrayUsingForLoop(arr, size);

    cout<<"Using WHILE LOOP\n";
    reverseArrayUsingWhileLoop(arr2, size);

    cout<<"Using Recursion\n";
    reverseArrayUsingRecursion(arr, size);
    cout<<endl;

    for(int i=0; i<=size-1; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;

    // cout<<"Using Recursion\n";
    // reverseArrayUsingRecursion_2(arr, 0, size-1);
    // for(int i=0; i<=size-1; i++)
    // {
    //     cout<<arr[i]<<" ";
    // }
    // cout<<endl;
    
    reverseArray(arr1);
    for(auto x : arr1)
    {
        cout<<x<<" ";
    }
    cout<<endl;

    return 0;
}