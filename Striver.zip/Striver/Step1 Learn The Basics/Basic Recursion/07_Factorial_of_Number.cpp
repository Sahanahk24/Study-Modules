#include <iostream>
#include <vector>
using namespace std;

int getFactorial1(int num)
{
    cout<<num<<endl;
    if(num==1)
    {
        return num;
    }
    return num * getFactorial1(num - 1);
}

vector<int> getFactorial2_gfg(int num, vector<int> res)
{
    int fact = 1;
    int i = 2;
    while(fact <= num)
    {
        res.push_back(fact);
        fact = fact * i;
        i++;
    }
    return res;
}


int main()
{
    int num;
    vector<int> facts;
    cout<<"Enter the number: ";
    cin>>num;
    // cout<<"Factorial of "<<num<<" : "<<getFactorial1(num);
    // cout<<endl;
    facts =  getFactorial2_gfg(num, facts);
    cout<<"\nFacts "<<endl;
    for(auto x : facts)
    {
        cout<<x<<" ";
    }   
    cout<<endl;
    
    return 0;
}