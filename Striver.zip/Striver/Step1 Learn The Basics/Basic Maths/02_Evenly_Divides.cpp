//https://www.geeksforgeeks.org/problems/count-digits5716/1

//Input: n = 12
// Output: 2
// Explanation: 1, 2 when both divide 12 leaves remainder 0.

#include <iostream>
using namespace std;


int evenlyDivides(int n) {
        int m = n;
        int count=0;
        while(n!=0)
        {
            int dig = n % 10;
            if(dig!=0 && m%dig==0)
            {
                count++;
            }
            n = n / 10;
        }
        return count;
    }


int main()
{   
    int num;
    cout<<"Enter number: ";
    cin>>num;
    cout<<"EvenLy Divides "<<num<<" is : "<<evenlyDivides(num)<<endl;
}