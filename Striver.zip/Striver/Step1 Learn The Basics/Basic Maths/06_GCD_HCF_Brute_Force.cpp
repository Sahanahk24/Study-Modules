#include <iostream>
using namespace std;

int gcd_bruteforece_1(int a, int b)   //TC - O(min(a,b))
{   
    int gcd = 0;
    for(int i=1; i<=min(a,b); i++)
    {
        if(a%i==0 && b%i==0)
        {
            gcd = i;
        }
    }
    return gcd;
}

int gcd_bruteforece_2(int a, int b)  ////TC - O(min(a,b))   comparatively less iterations
{   
    int gcd = 0;
    for(int i=min(a,b); i>=1; i--)
    {
        if(a%i==0 && b%i==0)
        {
            gcd = i;
            break;
        }
    }
    return gcd;
}


int main()
{   
    int n, m;
    cout<<"Enter num 1 : ";
    cin>>n;
    cout<<"Enter num 2 : ";
    cin>>m;
    cout<<"GCD of "<<n<<" and "<<m<<" : "<<gcd_bruteforece_1(n,m)<<endl;
    cout<<"GCD of "<<n<<" and "<<m<<" : "<<gcd_bruteforece_2(n,m)<<endl;
    return 0;
}