/*
LCM - least common multipler
ex :  a=15, b =20   output = 60
*/

#include <iostream>
using namespace std;

int getLcm(int a, int b)
{
    int max_val = max(a,b);
    // int res=0;
    while(1)
    {
        if(max_val % a == 0 && max_val % b == 0)
        {
            // res = max_val;
            return max_val;
        }
        max_val++;
    }
    // return res;
}

int getGcd_usingEcludeanALgo(int a, int b)
{
    while(a>0 && b>0)
    {
        if(a>b)
        {
            a = a % b;
        }
        else
        {
            b = b % a;
        }
    }
    return (a==0 ? b : a);
}    

int getLcm_using_GCD(int a, int b)
{
    //formula --> a*b = lcm(a,b) * gcd (a,b)
    //lcm(a,b) =  a*b / gcd(a,b)

    int gcd_val = getGcd_usingEcludeanALgo(a,b);
    return (a*b)/gcd_val;
}


int main()
{
    int num1, num2;
    cout<<"Enter num1: ";
    cin>>num1;
    cout<<"Enter num2: ";
    cin>>num2;
    int res = getLcm(num1,num2);
    cout<<"Least common multiplier of "<<num1<<" and "<<num2<<" : "<<res<<endl;
    cout<<"Least common multiplier of "<<num1<<" and "<<num2<<" : "<<getLcm_using_GCD(num1,num2)<<endl;
    
    return 0;
}