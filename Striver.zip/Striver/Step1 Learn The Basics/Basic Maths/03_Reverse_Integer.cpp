//https://leetcode.com/problems/reverse-integer/

#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int reverse(int x)
{
    bool isNeg = 0;
    if(x>=INT_MAX || x<=INT_MIN)
    {
        return 0;
    }
    if(x<0)  //checking for negative sign(-)
    {
        x = abs(x); //-2147483648
        isNeg = 1;
    }
    long res=0;
    while(x!=0)
    {
        int dig = x % 10;
        res = res*10 + dig;
        x = x / 10;
    }
    if(res>INT_MIN && res<INT_MAX)  //checking for int range
    {
        if(isNeg)
        {
            auto val = to_string(res);
            val.insert(0,"-");
            res = stoi(val);
            return res;
        }
        return res;
    }
    return 0;
}

int main()
{
    int num;
    cout<<"Enter Number : ";
    cin>>num;
    cout<<"Reverse of "<<num<<" : "<<reverse(num)<<endl;
    return 0;
}