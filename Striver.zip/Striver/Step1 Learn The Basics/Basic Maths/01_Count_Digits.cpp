// num = 12345    output -> 5
// num = 784    output -> 3 
// count number of digits in a number.

#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int countDigits(int n) //Time Complexity: O(log10N + 1) //Space Complexity : O(1)
{   
    int count=0;
    while(n!=0)
    {
        count++;
        n = n/10;
    }
    return count;
}

int countDigitsOptimal(int n) //Time Complexity: O(1) //Space Complexity : O(1)
{   
   int count = (int)(log10(n)+1);
   return count;
}

int main()
{
    int num;
    cout<<"Enter number: ";
    cin>>num;
    cout<<"Number of digits in "<<num<<" is : "<<countDigits(num)<<endl;
    cout<<"Number of digits in "<<num<<" is : "<<countDigitsOptimal(num)<<endl;

    return 0;
}

// Time Complexity: O(log10N + 1) where N is the input number. The time complexity is determined by the number of digits in the input integer N. In the worst case when N is a multiple of 10 the number of digits in N is log10N + 1.

//Space Complexity : O(1) as only a constant amount of additional memory for the counter regardless of size of the input number.