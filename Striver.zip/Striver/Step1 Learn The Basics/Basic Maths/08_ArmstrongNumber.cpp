//Armstrong ==> 153 == 1^3 + 5^3 + 3^3

#include <iostream>
using namespace std;

int powerFunc(int num, int power)
{
    int res=1;
    while(power!=0)
    {
        res = res * num;
        power--;
    }
    return res;
}

bool isArmStrongNumber(int num)
{
    int res = 0;
    int val = num;
    while(num!=0)
    {
        int dig = num % 10;
        res = res + powerFunc(dig,3);
        num = num / 10;
    }
    cout<<"res : "<<res<<"  val : "<<val<<endl;
    if(val == res)
    {
        return true;
    }
    return false;
}


int main()
{
    int num;
    cout<<"Enter the number: ";
    cin>>num;
    if(isArmStrongNumber(num))
    {
        cout<<num<<" is Armstrong Number"<<endl;
    }
    else{
        cout<<num<<" is Not an Armstrong Number"<<endl;

    }
    return 0;
}