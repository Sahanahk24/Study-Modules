//https://leetcode.com/problems/palindrome-number/

#include <iostream>
#include <bits/stdc++.h>
using namespace std;

bool isPalindrome(int x)
{
    if(x<0)
    {
        return false;
    }
    int num = x;
    long res = 0;
    while(x!=0)
    {
        int dig = x % 10;
        res = res * 10 + dig;
        x = x / 10;
    }
    if(res == num)
    {
        return true;
    }
    return false;
}

int main()
{
    int num;
    cout<<"Enter Number : ";
    cin>>num;
    cout<<"isPalindrome : "<<isPalindrome(num)<<endl;
    return 0;
}