/*
A prime number is a number greater than 1 that has no divisors other than 1 and itself.
The smallest prime number is 2, and it is the only even prime number.
*/

#include <iostream>
using namespace std;

bool checkIsPrime(int num)
{
    bool isPrime = 1;
    if(num<2)
    {
        return false;
    }
    for(int i=2; i*i<=num; i++) 
    {
        if(num%i==0)
        {
            isPrime=0;
            break;
        }
    }
    if(isPrime)
    {
        return true;
    }
    return false;
}



int main()
{   
    int num;
    cout<<"Enter the number: ";
    cin>>num;
    for(int i=0; i<=num; i++)
    {
        if(checkIsPrime(i))
        {
            cout<<i<<" is Prime\n";
        }
        else{
            cout<<i<<" is Not Prime\n";
        }
    }
    

    return 0;
}