#include <iostream>
#include <unordered_map>
#include <map>
#include <string>
using namespace std;



int main()
{
    unordered_map<int, int> uno_map;  //O(1) , O(n)
    map<int, int> map; //O(log n)
    
    int arr[] = {12, 1, 2, 3, 2, 1, 2, 4, 4, 5, 5};
    for(auto x : arr)
    {
        map[x]++;  //sorted  
        uno_map[x]++; //unordered
    }
    cout<<"In normal map<int,int> its sorted\n";
    for(auto z : map)
    {
        cout<<z.first<<" --> "<<z.second<<endl;
    }
    cout<<endl;

    cout<<"In unordered_map<int,int> its unordered\n";
    for(auto z : uno_map)
    {
        cout<<z.first<<" --> "<<z.second<<endl;
    }
    cout<<endl;

    // int q;
    // cout<<"query : ";
    // cin>>q;
    // while(q--)
    // {
    //     int num;
    //     cout<<"Num : "; 
    //     cin>>num;
    //     cout<<map[num]<<endl;
    // }

    string s = "absdandsabslkjabcd";

    unordered_map<char, int> s_map;
    cout<<endl;
    for(auto c : s)
    {
        s_map[c]++;
    }
    for(auto z : s_map)
    {
        cout<<z.first<<" --> "<<z.second<<endl;
    }
    cout<<endl;
    return 0;
}