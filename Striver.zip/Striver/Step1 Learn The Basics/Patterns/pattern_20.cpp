/*

E
D E
C D E
B C D E
A B C D E

n=5
*/

#include <iostream>
using namespace std;

void printPattern(int n)
{
    
    for(int i=0; i<n; i++)
    {
        char ch=64+n-i;
        
        for(char m = ch; m<=ch+i; m++)
        {   
            cout<<m<<" ";
            // cout<<(char)ch<<" ";
        }
        cout<<endl;
    }
}

int main()
{
    int Num;
    cout<<"Num : ";
    cin>>Num;
    printPattern(Num);
}