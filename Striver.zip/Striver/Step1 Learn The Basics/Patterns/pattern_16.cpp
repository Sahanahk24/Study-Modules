/*

A
AB
ABC
ABCD
ABCDE

n=5
*/

#include <iostream>
using namespace std;

void printPattern(int n)
{
    
    for(int i=0; i<n; i++){
        char ch='A';
        for(int j=0; j<=i; j++){
            cout<<ch<<" ";
            ch+=1;
        }
        cout<<endl;
    }
}

int main()
{
    int Num;
    cout<<"Num : ";
    cin>>Num;
    printPattern(Num);
}