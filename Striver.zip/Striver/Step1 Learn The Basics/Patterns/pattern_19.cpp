/*

      A
    A B A
  A B C B A
A B C D C B A

n=5
*/

#include <iostream>
using namespace std;

void printPattern(int n)
{
    for(int i=0; i<n; i++){
        //char ch = 64;
        for(int j=0; j<n-i-1; j++)
        {
                cout<<" ";
        }
        char ch=64;
        int breakThru = ((2*i+1)/2)+1;
        for(int k=0; k<2*i+1; k++){
                if(k<breakThru){
                    ch+=1;
                    cout<<ch;
                    
                }
                else{
                    ch-=1;
                    cout<<ch;  
                }
            }
        cout<<endl;
    }
}

int main()
{
    int Num;
    cout<<"Num : ";
    cin>>Num;
    printPattern(Num);
}