/*
* * * *
* * * *
* * * *
* * * *
*/

#include <iostream>
using namespace std;

void printPattern(int num)
{
    for(int i=0; i<num; ++i){
        for(int j=0; j<num; ++j){
            cout<<"* ";
        }
        cout<<endl;
    }
}

int main()
{
    int Num;
    cout<<"Num : ";
    cin>>Num;
    printPattern(Num);
}