#include <iostream>
#include <vector>
#include <set>
using namespace std;

void printArray(vector<int> arr)
{
    for(auto x: arr)
    {
        cout<<x<<" ";
    }
    cout<<endl;
}


vector<int> union_array_brute(vector<int> arr1, vector<int> arr2)  
{                           // n1 -> arr1.size()  n2 -> arr2.size()
    set<int> set;           // TC : O(n1logn) + O(n2logn) + O(n1+n2)
    for(auto x : arr1)      // SC : O(n1+n2) + O(n1+n2)
    {
        set.insert(x);
    }

    for(auto y : arr2)
    {
        set.insert(y);
    }

    vector<int> union_arr;
    for(auto x : set)
    {
        union_arr.push_back(x);
    }

    return union_arr;
}


vector<int> union_array_optimal(vector<int> arr1, vector<int> arr2)
{
    int i=0, j=0;
    vector<int> union_arr;
    int n = arr1.size();
    int m = arr2.size();

    while(i<n && j<m)
    {
        if(arr1[i] <=  arr2[j])
        {
            if(union_arr.size()==0 || union_arr.back() != arr1[i])
            {
                union_arr.push_back(arr1[i]);
            }
            i++;
        }
        else
        {
            if(union_arr.size()==0 || union_arr.back() != arr2[j])
            {
                union_arr.push_back(arr2[j]);
            }
            j++;
        }
        
    }

    while(i<n)
    {
        if(union_arr.size()==0 ||union_arr.back() != arr1[i])
        {
            union_arr.push_back(arr1[i]);
        }
        i++;
    }
    while(j<m)
    {
        if(union_arr.size()==0 || union_arr.back() != arr2[j])
        {
            union_arr.push_back(arr2[j]);
        }
        j++;
    }
    return union_arr;
}


int main()
{

    vector<int> arr1 =  {1,2,2,3,4,4,6};
    vector<int> arr2 = {1,2,3,5,9,10};


    // vector<int> res = union_array_brute(arr1, arr2);

    vector<int> res = union_array_optimal(arr1, arr2);
    
    printArray(res);

    return 0;
}