//https://www.naukri.com/code360/problems/remove-duplicates-from-sorted-array_1102307?utm_source=youtube&utm_medium=affiliate&utm_campaign=striver_Arrayproblems&leftPanelTabValue=PROBLEM

//https://leetcode.com/problems/remove-duplicates-from-sorted-array/description/


#include <iostream>
#include <vector>
#include <set>
using namespace std;

int removeDuplicates_brute(vector<int> &arr, int n) {
	// Write your code here.

	// brute force
	set<int> s;
	for(auto ele : arr)
	{
		s.insert(ele);  // O(nlogn)
 	}
	return s.size();
}

int removeDuplicates_returnOnlyUniqueEleCount(vector<int> &arr, int n)
{
	int i=0, j=1;   //code to only return n unique elements
	while(j<n)    //O(n)
	{
		if(arr[j]>arr[i])
		{
			arr[i+1] = arr[j];
			i++;
		}
		j++;
	}
	return i+1;
}	

int removeDuplicates_getUniqueEle_atstart(vector<int> &arr, int n)
{
	//code with getting all unique elements at start of arr and return unique elements count
	int i=0, j=1, max = arr[0], k=1;
	while(j<n)
	{
		if(arr[j]>arr[i] && arr[j]!=max)
		{
			max = arr[j];
			arr[k] = arr[j];
			swap(arr[k], arr[j]);
			i=j;
            k++;
		}
		j++;
	}
	return k;
}


int main()
{
    vector<int> arr = {0,0,1,1,1,2,3,3,4};

    cout<<removeDuplicates_brute(arr, arr.size())<<endl;
    cout<<removeDuplicates_returnOnlyUniqueEleCount(arr, arr.size())<<endl;
    cout<<removeDuplicates_getUniqueEle_atstart(arr, arr.size())<<endl;

    return 0;
}