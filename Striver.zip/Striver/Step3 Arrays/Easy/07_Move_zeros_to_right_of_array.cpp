#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

printVector(vector<int> &arr)
{
    for(auto x : arr)
    {
        cout<<x<<" ";
    }
    cout<<endl;
}


void move_zeros_brute(vector<int> &arr)  // TC : O(2*n)  // SC :  O(n)
{                                        //->O(n) + O(m) + O(n-m) 
    vector<int> non_zeros;               //->O(n) + O(n)           
    for(auto x: arr)  //O(n)             //->O(2*n)   
    {
        if(x!=0)
        {
            non_zeros.push_back(x);
        }
    } 

    for(int i=0; i<non_zeros.size(); i++) // O(m)
    {
        arr[i] = non_zeros[i];
    }

    for(int i=non_zeros.size(); i<arr.size(); i++)  // O(n-m)
    {
        arr[i] = 0;
    }
}   

void move_zeros_optimal(vector<int> &arr)  //TC : O(n) | Sc : O(1)
{                                          //-> O(x) + O(n-x) 
   int j=-1;                               //-> O(n)
   for(int i=0; i<arr.size(); i++)  // O(x)
   {
        if(arr[i]==0)
        {
            j=i;
            break;
        }
   }
    // assign j with the first 0 in the arr, then assign i = j+1
    // loop through the arr and check if arr[i]!=0 then swap

   for(int i=j+1; i<arr.size(); i++) // O(n-x)
   {
        if(arr[i]!=0)
        {
            swap(arr[i], arr[j]);
            j++;
        }
   }
}


int main()
{   
    vector<int> arr = {0,0,0,1,3,2,0,0,2,30,0,8,55};
    printVector(arr);

    // move_zeros_brute(arr);
    move_zeros_optimal(arr);
    printVector(arr);
    return 0;
}