//https://www.naukri.com/code360/problems/ninja-and-the-sorted-check_6581957?utm_source=youtube&utm_medium=affiliate&utm_campaign=striver_Arrayproblems

#include <iostream>
#include <vector>
using namespace std;

void printArray(vector<int> arr)
{
    for(int i=0; i<arr.size() ; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

bool isSorted(vector<int> arr)
{
    for(int i=1; i<arr.size(); i++)
    {
        if(arr[i]<arr[i-1])
        {
            return false;
        }
    }
    return true;
}


int main()
{
    vector<int> arr = {1, 2, 3,4,5,6};
    // vector<int> arr = {5,4,6,7,8,9};
    printArray(arr);
    if(isSorted(arr))
    {
        cout<<"Array is Sorted\n";
    }
    else
    {
        cout<<"Array is not Sorted\n";
    }

    return 0;
}