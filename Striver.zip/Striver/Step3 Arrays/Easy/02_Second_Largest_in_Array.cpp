
//https://www.naukri.com/code360/problems/ninja-and-the-second-order-elements_6581960?utm_source=youtube&utm_medium=affiliate&utm_campaign=striver_Arrayproblems

#include <iostream>
#include <algorithm>
#include <vector>
#include <bits/stdc++.h>
using namespace std;

void printArray(vector<int> arr)
{
    for(int i=0; i<arr.size() ; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}


int sec_largest_brute(vector<int> arr)  //O(nlogn) + O(n)
{
    sort(arr.begin(), arr.end());
    int n = arr.size();
    int max = arr[n-1];
    printArray(arr);

    for(int i=n-2; i>=0; i--)
    {
        if(arr[i] != max)
        {
            return arr[i];
        }
    }

    return max;
}

int sec_largest_better(vector<int> arr) //o(n) + o(n) ==> O(2n)
{
    int largest = arr[0];
    int sec_largest = INT_MIN;

    for(int i=1; i<arr.size(); i++)
    {
        if(arr[i]>largest)
        {
            largest = arr[i];
        }
    }

    for(int i=1; i<arr.size(); i++)
    {
        if(arr[i]>sec_largest && arr[i]<largest)
        {
            sec_largest = arr[i];
        }
    }
    return sec_largest;

}

int sec_largest_optimal(vector<int> arr) //o(n)
{
    // Code Here
    int largest = arr[0];
    int sec_largest;
    for(int i=1; i<arr.size(); i++)
    {
        if(arr[i] > largest)
        {
            sec_largest = largest;
            largest = arr[i];
        }
        else if(arr[i]<largest && arr[i]>sec_largest)
        {
            sec_largest = arr[i];
        }
    }
    return sec_largest;
}



int main()
{
    vector<int> arr = {12, 98, 34, 45, 2, 5, 98, 90, 34, -17, 95}; //45
    // vector<int> arr= {12, 35, 1, 10, 34, 1};
    printArray(arr);

    
    cout<<sec_largest_brute(arr)<<endl;    //O(nlogn) brute
    
    cout<<sec_largest_better(arr)<<endl;   //O(n) + O(n) better

    cout<<sec_largest_optimal(arr)<<endl; //O(n) optimal

    return 0;
}