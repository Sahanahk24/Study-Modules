#include <iostream>
#include <vector>
using namespace std;

int linear_search(vector<int> &arr, int k)
{
    for(int i = 0; i<arr.size(); i++)
    {
        if(arr[i]==k)
        {
            return i;
        }
    }
    return -1;
}


int main()
{
    vector<int> arr = {1, 2, 3, 89, 20, 23, 2, 344, 10, -5, -10};
    int k = 20;
    cout<<linear_search(arr, k)<<endl;
    return 0;
}