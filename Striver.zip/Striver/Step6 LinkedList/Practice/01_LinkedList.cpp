#include <iostream>
#include <vector>
using namespace std;

class ListNode{
    public:
        int val;
        ListNode *next;

        ListNode(int data)
        {
            this->val = data;
            this->next = nullptr;
        }
};

void traverseLL(ListNode* head)
{
    ListNode* curr = head;
    while(curr)
    {
        cout<<curr->val<<" --> ";
        curr = curr->next;
    }
    cout<<endl;
}

ListNode* convertArr2LL(vector<int> arr)
{
    if(arr.size() == 0)
    {
        return nullptr;
    }
    ListNode* head = new ListNode(arr[0]);
    ListNode* curr = head;
    for(int i=1; i<arr.size(); i++)
    {
        ListNode* newNode = new ListNode(arr[i]);
        curr->next = newNode;
        curr = curr->next;
    }
    return head;
}

int getLength(ListNode* head)
{
    int cnt = 0;
    ListNode* curr = head;
    while(curr)
    {
        cnt++;
        curr = curr->next;
    }
    return cnt;
}

bool searchForElement(ListNode* head, int k)
{
    ListNode* curr = head;
    while(curr)
    {
        if(curr->val == k)
        {
            return true;
        }
        curr = curr->next;
    }
    return false;
}

ListNode* deleteAtHead(ListNode* head)
{
    if(head == nullptr)
    {
        return head;
    }

    head = head->next;
    return head;
}

ListNode* insertAtHead(ListNode* head,int k)
{
    ListNode* newNode = new ListNode(k);

    if(head == nullptr)
    {   
        return newNode;
    }

    newNode->next = head;
    return newNode;
}


int main()
{
    ListNode* head = new ListNode(99);
    ListNode* curr = head;

    for(int i=1; i<=10; i++)
    {
        ListNode* newNode = new ListNode(i);
        curr->next = newNode;
        curr = newNode;
    }

    traverseLL(head);
    cout<<"Length is : "<<getLength(head)<<endl<<endl;

    vector<int> arr = {2,4,6,8,10,12,14,16,18};
    ListNode* h1 = convertArr2LL(arr);
    traverseLL(h1);
    searchForElement(h1,2) ? cout<<"Present\n" : cout<<"Not Present\n"; 
    cout<<"Length is : "<<getLength(h1)<<endl<<endl;

    ListNode* h2 = deleteAtHead(h1);
    traverseLL(h2);
    cout<<"Length is : "<<getLength(h2)<<endl<<endl;

    ListNode* h3 = insertAtHead(h2, 99);
    traverseLL(h3);
    cout<<"Length is : "<<getLength(h3)<<endl<<endl;
    
    return 0;
}
