#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;


class ListNode
{
    public:
        int val;
        ListNode* next;

        ListNode(int data)
        {
            this->val = data;
            this->next = nullptr;
        }
};

ListNode* convert_to_LL(vector<int> arr)
{
    if(arr.size() == 0)
    {
        return nullptr;
    }
    ListNode* head = new ListNode(arr[0]);
    ListNode* curr = head;
    for(int i=1; i<arr.size(); i++)
    {
        ListNode* newNode = new ListNode(arr[i]);
        curr->next = newNode;
        curr = newNode;
    }
    return head;
}

void traverse(ListNode* head)
{
    ListNode* curr = head;
    while(curr)
    {
        cout<<curr->val<<" ";
        curr = curr->next;
    }
    cout<<endl;
}

ListNode* reverse_LL_using_vector(ListNode* head, int m, int n)
{
    vector<int> rev;
    ListNode* temp = head;
    while(temp)
    {
        rev.push_back(temp->val);
        temp = temp->next;
    }

    reverse(rev.begin()+m, rev.begin()+n);

    head = convert_to_LL(rev);
    return head;

}

ListNode* reverse_LL_using_stack(ListNode* head, int m , int n)
{
    stack<int> s;
    ListNode* temp = head;
    int cnt = 0;
    while(temp)
    {
        cnt++;
        if(cnt > m && cnt <= n)
        {
            s.push(temp->val);
        }
        temp = temp->next;
    }
    temp = head;
    cnt = 0;
    while(temp)
    {
        cnt++;
        if(cnt > m && cnt <= n)
        {
            temp->val = s.top();
            s.pop();
        }
        temp = temp->next;
    }
    return head;
}


ListNode* reverse_LL_Iterative(ListNode* head)
{
    ListNode* prev = nullptr;
    ListNode* temp = head;
    while(temp)
    {
        ListNode* front = temp->next;
        temp->next = prev;
        prev = temp;
        temp = front;
    }
    return prev;
}


int main()
{
    vector<int> arr = {1,2,3,4,5,6,7,8,9,10};
    ListNode* h1 = convert_to_LL(arr);
    traverse(h1);

    // ListNode* rev_vec = reverse_LL_using_vector(h1, 2, 8);
    // traverse(rev_vec);

    // ListNode* rev_stk = reverse_LL_using_stack(h1, 2, 8);
    // traverse(rev_stk);

    ListNode* rev_iter = reverse_LL_Iterative(h1);
    traverse(rev_iter);
    return 0;
}