#include <iostream>
#include <vector>
#include <stack>

using namespace std;

class Node
{
    public:
        int data;
        Node* next;

        Node(int data)
        {
            this->data = data;
            this->next = nullptr;
        }
};

int lengthOfLL(Node* head)
{
    Node* temp = head;
    int cnt=0;
    while(temp)
    {
        temp = temp->next;
        cnt++;
    }
    return cnt;
}

Node* convertArrayIntoLL(vector<int> arr)
{
    Node* head = new Node(arr[0]);
    Node* curr = head;
    for(int i=1; i<arr.size(); i++)
    {
        Node* NextNode = new Node(arr[i]);
        curr->next = NextNode;
        curr = NextNode;
    }
    return head;
}

void traverseLinkedListElements(Node* head)
{
    Node* curr = head;
    while(curr != nullptr)
    {   
        cout<<curr->data<<" ";
        curr = curr->next;
    }
    cout<<endl;
}

int SearchInLL(Node* head, int k)
{
    Node* temp = head;
    while(temp)
    {
        if(temp->data  == k)
        {
            return 1;
        }
        temp = temp->next;
    }
    return -1;
}

Node* deleteHead(Node* head)
{
    if(head==nullptr)
    {
        return head;
    }

    Node* temp = head;
    head = head->next;
    delete temp;
    return head;
}

Node* deleteTail(Node* head)
{
    if(head==nullptr || head->next == nullptr)
    {
        return nullptr;
    } 
    Node* temp = head;
    while(temp->next->next != nullptr)
    {
        temp = temp->next;
    }
    delete temp->next;
    temp->next = nullptr;
    return head;
}

Node* deleteElementAtPositionK(Node* head, int k)
{
    if(head==nullptr)
    {
        return nullptr;
    }
    if(k==1)
    {
        Node* curr = head;
        head = head->next;
        delete curr;
        return head;
    }
    int cnt=0;
    Node* prev = nullptr;
    Node* curr = head;
    while(curr!=nullptr)
    {
        cnt++;
        if(cnt==k)
        {
            prev->next = prev->next->next;
            delete curr;
            break;
        }
        prev = curr;
        curr = curr->next;
    }
    return head;

}

Node* reverseLLStack(Node* head)
{
    Node* temp = head;
    stack<int> st;
    while(temp)
    {
        st.push(temp->data);
        temp = temp->next;
    }

    temp = head;

    while(temp)
    {
        temp->data = st.top();
        st.pop();
        temp = temp->next;
    }

    return head;
}

Node* deleteElement(Node* head, int k)
{
    if(head==nullptr)
    {
        return nullptr;
    }
    if(head->data == k)
    {
        Node* curr = head;
        head = head->next;
        delete curr;
        return head;
    }
    Node* curr = head;
    Node* prev = nullptr;
    while(curr!=nullptr)
    {
        if(curr->data == k)
        {
            prev->next = prev->next->next;
            delete curr;
            break;
        }
        prev = curr;
        curr = curr->next;
    }
    return head;
}


int main()
{
    Node* head = new Node(100);
    Node* curr = head;

    for(int i=1; i<=10; i++)
    {   
        // int n;
        // cout<<"Enter num "<<i<<" : ";
        // cin>>n;
        Node* nextNode = new Node(i);
        curr->next = nextNode;
        curr = nextNode;
    } 

    traverseLinkedListElements(head);
    cout<<"Length : "<<lengthOfLL(head)<<endl;

    cout<<endl;
    cout<<"Convert Array to Linked List"<<endl;
    vector<int> arr = {10,20,30,40,50,60,70,80,90};
    Node* head2 = convertArrayIntoLL(arr);
    traverseLinkedListElements(head2);
    cout<<"Length : "<<lengthOfLL(head2)<<endl;
    int k = 22;
    cout<<"Element found : "<<SearchInLL(head2, k)<<endl;

    cout<<endl;
    Node* head3 = deleteHead(head2);
    cout<<"Delete from Head : ";
    traverseLinkedListElements(head3);

    cout<<endl;
    Node* head4 = deleteTail(head2);
    cout<<"Delete from Tail : ";
    traverseLinkedListElements(head4);

    cout<<endl;
    vector<int> arr1 = {100,200,300,400,500,600,700,800,900};
    Node* head5 = convertArrayIntoLL(arr1);
    traverseLinkedListElements(head5);
    int pos = 3;
    Node* head6 = deleteElementAtPositionK(head5, pos);
    cout<<"Delete from "<<pos<<"th Position : \n";
    traverseLinkedListElements(head6);
    
    cout<<endl;
    traverseLinkedListElements(head5);
    int ele = 400;
    Node* head7 = deleteElement(head5, ele);
    cout<<"Delete "<<ele<<" from Linked List : \n";
    traverseLinkedListElements(head7);

    cout<<endl;
    cout<<"Reverse a Linked List using Stack"<<endl;
    Node* head8 = reverseLLStack(head7);
    traverseLinkedListElements(head8);
    return 0;
}