#include <iostream>
#include <vector>
using namespace std;

class Node
{
    public:
        int data;
        Node* next;

        Node(int data)
        {
            this->data = data;
            this->next = nullptr;
        }
};

int lengthOfLL(Node* head)
{
    Node* temp = head;
    int cnt=0;
    while(temp)
    {
        temp = temp->next;
        cnt++;
    }
    return cnt;
}

Node* convertArrayIntoLL(vector<int> arr)
{
    Node* head = new Node(arr[0]);
    Node* curr = head;
    for(int i=1; i<arr.size(); i++)
    {
        Node* NextNode = new Node(arr[i]);
        curr->next = NextNode;
        curr = NextNode;
    }
    return head;
}

void traverseLinkedListElements(Node* head)
{
    Node* curr = head;
    while(curr != nullptr)
    {   
        cout<<curr->data<<" ";
        curr = curr->next;
    }
    cout<<endl;
}

int SearchInLL(Node* head, int k)
{
    Node* temp = head;
    while(temp)
    {
        if(temp->data  == k)
        {
            return 1;
        }
        temp = temp->next;
    }
    return -1;
}

int middleOfLL(Node* head)
{
    int m = lengthOfLL(head);
    Node* curr = head;
    int cnt=0;
    while(curr)
    {
        cnt++;
        if(cnt == (m/2)+1)
        {
            return curr->data;
        }
        curr = curr->next;
    }
    return -1;
}

int main()
{
    Node* head = new Node(100);
    Node* curr = head;

    for(int i=1; i<=10; i++)
    {   
        // int n;
        // cout<<"Enter num "<<i<<" : ";
        // cin>>n;
        Node* nextNode = new Node(i);
        curr->next = nextNode;
        curr = nextNode;
    } 

    traverseLinkedListElements(head);
    cout<<"Length : "<<lengthOfLL(head)<<endl;

    cout<<endl;
    cout<<"Convert Array to Linked List"<<endl;
    vector<int> arr = {10,20,30,40,50,60};
    Node* head2 = convertArrayIntoLL(arr);
    traverseLinkedListElements(head2);
    cout<<"Length : "<<lengthOfLL(head2)<<endl;
    int k = 22;
    cout<<"Element found : "<<SearchInLL(head2, k)<<endl;

    cout<<"Middle of LL : "<<middleOfLL(head2)<<endl;

    return 0;
}