#include <iostream>
#include <vector>
#include <math.h>
using namespace std;

class Stack
{
    public:
        int size;
        int top;
        int *arr;

        Stack(int n)
        {   
            size = n;
            top = -1;
            arr = new int[size];
        }

        void push(int x)    
        {
            if(top>size)
            {
                cout<<"Stack OverFlow"<<endl;
                return;
            }
            top++;
            arr[top] = x;
        }

        void pop()
        {
            top = top -1;
        }

        int Top()
        {
            if(top==-1)
            {
                cout<<"Stack underflow"<<endl;
                return -999;
            }
            return arr[top];
        }

        int Size()
        {
            return top+1;
        }
};


int main()
{
    Stack st(3);
    st.push(10);
    st.push(20);
    st.push(30);
    st.push(40);
    cout<<st.Top()<<endl;
    st.pop();
    cout<<st.Size()<<endl;
    cout<<st.Top()<<endl;
    st.push(80);
    st.push(50);
    cout<<st.Size()<<endl;
    int sz = st.Size();
    for(int i=0; i<sz; i++)
    {
        cout<<st.Top()<<" ";
        st.pop();
    }

    return 0;
}