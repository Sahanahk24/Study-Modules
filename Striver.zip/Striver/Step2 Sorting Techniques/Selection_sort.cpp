#include <iostream>
using namespace std;
//Best - O(n^2)  (for sorted Array)
//Avg - O(n^2)
//Worst - O(n^2)
//Space complexity - O(1)

void printArray(int arr[], int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}


void selectionSort(int arr[], int n)
{
    for(int i=0; i<n-1; i++){
        int min = i;
        for(int j=i+1; j<n-1; j++)
        {
            if(arr[j]<arr[min])
            {
                min = j;
            }
            swap(arr[min], arr[i]);
        }
    }
}

int main()
{
    int arr[] = {34, 12, 9, 23, 0, -2, 60};
    //int arr[] = {1,2,3,4,5,6};
    // int arr[] = {6,5,4,3,2,1};
    int size = sizeof(arr)/sizeof(arr[0]);
    printArray(arr,size);

    selectionSort(arr,size);
    printArray(arr,size);
    return 0;
}