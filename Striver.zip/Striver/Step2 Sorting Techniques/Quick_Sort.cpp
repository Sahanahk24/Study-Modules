#include <iostream>
using namespace std;


int partition(int arr[], int start, int end)
{
    int idx = start-1; 
    int pivot = arr[end];
    for(int j=start; j<end; j++)l
    {
        if(arr[j]<=pivot)
        {
            idx++;
            swap(arr[idx], arr[j]);
        }
    }
    idx++;
    swap(arr[idx], arr[end]);
    return idx;
}

void quickSort(int arr[], int start, int end)
{
    if(start>=end)
    {
        return;
    }
    int pivot = partition(arr, start, end);
    quickSort(arr, start, pivot-1);
    quickSort(arr, pivot+1, end);
}



int main()
{
    int arr[] = {1,34,5,6,7,0,9,-2,13};
    int size  = sizeof(arr)/sizeof(arr[0]);
    cout<<"Before Sorting\n";
    for(auto x:arr)
    {
        cout<<x<<" ";
    }
    cout<<endl;

    quickSort(arr, 0, size-1);
    cout<<"After Sorting\n";
    for(auto x:arr)
    {
        cout<<x<<" ";
    }
    cout<<endl;
    return 0;
}