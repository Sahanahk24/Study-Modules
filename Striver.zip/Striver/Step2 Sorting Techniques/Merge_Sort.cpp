#include <iostream>
#include <vector>
using namespace std;

void merge(int arr[], int start, int mid, int end)
{
    vector<int> temp;
    int i=start;
    int j=mid+1;
    while(i<=mid && j<=end)
    {
        if(arr[i]<=arr[j]){
            temp.push_back(arr[i]);
            i++;  
        }
        else{
            temp.push_back(arr[j]);
            j++;
        }
    }
    while(i<=mid)
    {
        temp.push_back(arr[i]);
        i++;
    }
    while(j<=end)
    {
        temp.push_back(arr[j]);
        j++;
    }

    for(int idx=0; idx<temp.size(); idx++)
    {
        arr[idx+start] = temp[idx];
    }
}

void mergeSort(int arr[], int start, int end)
{
    if(start >= end)
    {
        return;
    }
    int mid  = start + ((end-start)/2);
    
    mergeSort(arr,start,mid); //left
    mergeSort(arr,mid+1,end); //right
    merge(arr, start, mid, end);
}





int main()
{
    int arr[] = {23, 1, 0, -4, 454, 6, 34, 3};
    int size  = sizeof(arr)/sizeof(arr[0]);
    cout<<"Before Sorting\n";
    for(auto x:arr)
    {
        cout<<x<<" ";
    }
    cout<<endl;

    mergeSort(arr, 0, size-1);
    cout<<"After Sorting\n";
    for(auto x:arr)
    {
        cout<<x<<" ";
    }
    cout<<endl;
    return 0;
}