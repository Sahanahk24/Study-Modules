#include <iostream>
#include <bits/stdc++.h>
using namespace std;

bool isPalindrome(string s)
{
    string lowerCase = "";
    for(auto c : s)
    {
        if(isalnum(c))
        {
            lowerCase += tolower(c);
        }
    }

    int i=0;
    int j=lowerCase.size()-1;
    while(i<=j)
    {
        if(lowerCase[i]!=lowerCase[j])
        {
            return false;
        }
        i++;
        j--;
    }
    cout<<lowerCase<<endl;
    return true;
}

int main()
{
    string s;
    cout<<"Enter the String : ";
    getline(cin,s);
    //s="Marge, let's \"[went].\" I await {news} telegram";
    //s= "Hello worlDD!0$3sd";
    //s= Malaya#l!a+m_
    if(isPalindrome(s))
    {
        cout<<"True\n";
    }
    else{
        cout<<"False\n";
    }
}