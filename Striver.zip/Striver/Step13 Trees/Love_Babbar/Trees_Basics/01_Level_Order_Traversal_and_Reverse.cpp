#include <iostream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;

class Node{
    public:
    int data;
    Node* left;
    Node* right;

    Node(int val)
    {
        this->data = val;
        this->left = NULL;
        this->right = NULL;
    }
};


Node* createTree()
{
    int data;
    cout<<"Enter Data: ";
    cin>>data;
    Node* root = new Node(data);

    if(data == -1){return NULL;}

    cout<<"Enter left Node data for "<<data<<endl;
    root->left = createTree();

    cout<<"Enter right Node data for "<<data<<endl;
    root->right = createTree();

    return root;
}

void Level_Order_Traversal(Node* root)
{
    if(!root) { return; }
    queue<Node*> q;
    q.push(root);

    while(!q.empty())
    {
        Node* temp = q.front();
        q.pop();

        cout<<temp->data<<" ";
        if(temp->left) {q.push(temp->left);}
        if(temp->right) {q.push(temp->right);}
    }
}

void Level_Order_Traversal_Tree(Node* root)
{
    if(!root) { return; }
    queue<Node*> q;
    q.push(root);
    q.push(NULL);

    while(!q.empty())
    {
        Node* temp = q.front();
        q.pop();
        if(temp == NULL)
        {
            cout<<endl;
            if(!q.empty())
            {
                q.push(NULL);
            }
        }
        else
        {
            cout<<temp->data<<" ";
            if(temp->left) {q.push(temp->left);}
            if(temp->right) {q.push(temp->right);}
        }
    }
}

void Reverse_Level_Order(Node* root)
{
    if(!root) { return; }

    queue<Node*> q;
    stack<Node*> s;

    q.push(root);
    
    while(!q.empty())
    {
        Node* temp = q.front();
        q.pop();

        s.push(temp);
        if(temp->right) {q.push(temp->right);}
        if(temp->left) {q.push(temp->left);}
    }

    while(!s.empty())
    {
        cout<<s.top()->data<<" ";
        s.pop();
    }
}

int main()
{
    Node* root = createTree(); //1 2 4 -1 -1 5 -1 -1 3 6 -1 -1 7 -1 -1 
    Level_Order_Traversal(root);
    cout<<endl;
    Level_Order_Traversal_Tree(root);
    cout<<endl;
    Reverse_Level_Order(root);
    cout<<endl;
    return 0;
}