#include <iostream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;

class Node{
    public:
    int data; 
    Node* left;
    Node* right;

    Node(int val)
    {
        this->data = val;
        this->left = NULL;
        this->right = NULL;
    }
};

Node* createTree()
{
    int data;
    cout<<"Enter Data: ";
    cin>>data;
    Node* root = new Node(data);

    if(data == -1)
    {
        return NULL;
    }

    cout<<"Enter left node data for "<<data<<endl;
    root->left = createTree();

    cout<<"Enter right node data for "<<data<<endl;
    root->right = createTree();

    return root;
}

void levelOrderTraversal(Node* root)
{
    queue<Node*> q;
    q.push(root);
    q.push(NULL);
    while(!q.empty())
    {
        Node* temp = q.front();
        q.pop();

        if(temp==NULL)
        {
            cout<<endl;
            if(!q.empty())
            {
                q.push(NULL);
            }
        }
        else{
            cout<<temp->data<<" ";
            if(temp->left) {q.push(temp->left);}
            if(temp->right) {q.push(temp->right);}
        }
    }
}

void reverseLevelOrderTraversal(Node* root)
{
    queue<Node*> q;
    stack<Node*> st;

    q.push(root);
    while(!q.empty())
    {
        Node* temp = q.front();
        st.push(temp);
        q.pop();

        if(temp->right) {q.push(temp->right);}
        if(temp->left) {q.push(temp->left);}
    }

    while(!st.empty())
    {
        cout<<st.top()->data<<" ";
        st.pop();
    }
}

Node* createTreefromLevelOrder()
{
    queue<Node*> q;
    int data;
    cout<<"Enter data: ";
    cin>>data;
    Node* root = new Node(data);
    q.push(root);

    while(!q.empty())
    {
        Node* temp = q.front();
        q.pop();

        cout<<"Enter left node data for "<<temp->data<<": ";
        int leftData;
        cin>>leftData;

        if(leftData != -1) 
        {
           temp->left = new Node(leftData);
            q.push(temp->left);
        }

        cout<<"Enter right node data for "<<temp->data<<": ";
        int rightData;    
        cin>>rightData;

        if(rightData != -1)
        {
            temp->right = new Node(rightData);
            q.push(temp->right);
        }

    }
}

void inOrderTraversal(Node* root)
{
    if(!root) {return;}

    inOrderTraversal(root->left);
    cout<<root->data<<" ";
    inOrderTraversal(root->right);
}

int main()
{
    Node* root = createTree(); //1 3 7 -1 -1 9 -1 -1 5 -1 17 -1 -1
    cout<<endl;
    levelOrderTraversal(root);
    cout<<endl;
    reverseLevelOrderTraversal(root);
    cout<<endl;
    inOrderTraversal(root);
    return 0;
}