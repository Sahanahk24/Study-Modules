#include <iostream>
#include <vector>
using namespace std;

class Vehicle
{
    public:
    //    virtual void turnOnEngine() = 0;
        int numoberOfWheels = 2;
        void accelerate() = 0;
};

class VehicleWithEngine : Vehicle{
    public:
        void turnOnEngine() = 0;
};

class VehicleWithOutEngine : Vehicle
{

};

class MotorBike : public Vehicle
{
    bool isEngineOn;
    int speed;
    public:
        void turnOnEngine()
        {
            isEngineOn = true;
            if(isEngineOn)
            {
                // logic
            }
             
        }

        void accelerate()
        {
            speed = speed + 40;
        }
};

class cycle: public Vehicle
{
    int speed;
    public:
        void turnOnEngine()
        {
            throw exception ("Cycle dont have engine");
            // logic 
        }

        void accelerate()
        {
            speed = speed + 10;
        }
}

class VehicleWithEngine : Vehicle{
    public:
        void turnOnEngine() = 0;
};

class VehicleWithOutEngine : Vehicle
{
       
};

class MotorBike : public VehicleWithEngine
{

};

class Cycle : public VehicleWithOutEngine
{

};