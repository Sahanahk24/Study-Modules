#include <iostream>
#include <vector>
using namespace std;

class RestaurantEmployee
{
    public:
    virtual void cookFood() = 0;
    virtual void serveFood() = 0;
    virtual void getOrder() = 0;
    virtual void washDishes() = 0;
};

class waiter : public RestaurantEmployee
{
    public:
        void cookFood(){ }   //unnecessary implementation
        void serveFood(){ }   //waiters job
        void getOrder(){ }    //waiters job
        void washDishes(){ }  //unnecessary implementation
};      


class waiterInterface
{
    public:
        virtual void serveFood() = 0;
        virtual void getOrder() = 0; 
};

class waiter : public waiterInterface
{
    public:
        void serveFood(){ }  
        void getOrder(){ }    
};


class ChefInterface{
    public:
        virtual cookFood() = 0;
};

class Chef1 : public ChefInterface
{
    public:  
        void cookFood(){ }
};


class HelperInterface 
{
    public:
        virtual void washDishes() = 0; 
        virtual void clearFloor() = 0;
};

class Helper1 : public HelperInterface
{
    public:
        void washDishes(){}
        void clearFloor(){}
};

int main()
{
    return 0;
}
