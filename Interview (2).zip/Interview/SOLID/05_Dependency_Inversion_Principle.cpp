#include <iostream>
#include <vector>
using namespace std;

class Mouse
{
};

class WiredMouse : public Mouse
{
};

class BluetoothMouse : public Mouse
{
};



class Keyboard
{
};

class WiredKeyboard : public Keyboard
{
};

class BluetoothKeyboard : public Keyboard
{
};


class MacBook
{
    BluetoothMouse mouse;
    BluetoothKeyboard keyboard;

    MacBook()
    {
        keyboard = new BluetoothKeyboard();
        mouse = new BluetoothMouse();
    }
};

class macBook
{
    Mouse mouse;
    Keyboard Keyboard;

    macBook(Mouse mouse, Keyboard Keyboard)
    {
        this->Keyboard = Keyboard;
        this->mouse = mouse;
    }
};


int main()
{
    return 0;
}