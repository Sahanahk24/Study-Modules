#include <iostream>
#include <vector>
using namespace std;

class Marker{
    int m_price;
    string m_color;

    public:
        Marker(int price, string color)
        {
            this->m_price = price;
            this->m_color = color;
        }
};

class Invoice{
    Marker m_marker;
    int m_quantity;

    public:
        Invoice(Marker marker, int quantity)
        {
            this->m_marker = marker;
            this->m_quantity = quantity;
        }

        int calculateTotalPrice()
        {
            int price = m_marker.m_price * m_quantity;
            return price;
        }
}

class InvoiceSaver
{
    Invoice invoice;
    public: 
        InvoiceSaver(Invoice invoice)
        {
            this->invoice = invoice;
        }

        void saveToDatabase()
        {
            //logic
        }
        
        void saveToFile()
        {
            //logic
        }
};

//-------------------------------------------------------------------------------------------------------

class InvoiceSaver
{
    public:
        virtual void save(Invoice invoice) = 0;
};

class InvoiceSaveToDataBase : public InvoiceSaver
{
    public:
        void save(Invoice invoice)
        {
            //logic to save in db
        }
};

class InvoiceSaveToFile : public InvoiceSaver
{
    public:
        void save(Invoice invoice)
        {
            //logic to save in File
        }
};


int main()
{
    return 0;
}