#include <iostream>
#include <vector>
using namespace std;


template<typename T>
class UniquePtr{
    private:
        T* res;
    public:
        explicit UniquePtr(T* p = nullptr) : res(p){
            cout<<"Constructor called"<<endl; //Constructor
        }

        UniquePtr(const UniquePtr& obj) = delete; //copy constructor
        UniquePtr& operator=(const UniquePtr& obj) = delete; //copy assignement operator

        UniquePtr(UniquePtr&& obj){ //Move Constructor
            res = obj.res;
            obj.res = nullptr;
        }

        UniquePtr& operator=(UniquePtr&& obj)
        {  //Move assignment Constructor
            if(this != &obj)
            {
                delete res;
                res = obj.res;
                obj.res = nullptr;
            }
            return *this;
        }

        T& operator*()
        {
            return *res;
        }

        T* operator->()
        {
            return res;
        }

        T* get()
        {
            return res;
        }

        void reset(T* ptr=nullptr)
        {
            delete res;
            res = ptr;
        }

        T* release()
        {
            T* temp = res;
            res = nullptr;
            return temp;
        }

        ~UniquePtr()
        {
            if(res)
            {
                cout<<"Destructor Called for"<<*res<<endl;
            }
            else
            {
                cout<<"Yes Called"<<endl;
            }
            delete res;
            res = nullptr;
            
        }
};


int main()
{
    UniquePtr<int> ptr1(new int(20)); //constructor
    UniquePtr<int> ptr2(new int(30));
    // UniquePtr<int> ptr3 = ptr1; //Copy Contructor // Error
    // ptr2 = ptr1; //Copy Assignment Operator //Error
    UniquePtr<int> ptr5 = std::move(ptr1); //Move copy constructor
    cout<<*ptr5<<endl;
    ptr1 = std::move(ptr2); //Move copy Assignment;
    cout<<*ptr1<<endl;
    int* q = ptr1.get();
    cout<<*q<<endl;
    // ptr1.reset(ptr2);

    return 0;
}