#include <iostream>
#include <vector>
#include <memory>
using namespace std;

//get, release, swap, reset, get_deleter

class Car
{
    string m_model;
    public:
        Car(const string& model) : m_model(model)
        {
            cout<<"Constructor for "<<m_model<<" called"<<endl;
        }

        ~Car()
        {
            cout<<"Destructor for "<<m_model<<" called"<<endl;
        }

        void drive()
        {
            cout<<"Driving "<<m_model<<" car"<<endl;
        }
};


int main()
{
    
    std::unique_ptr<Car> car1 = std::make_unique<Car>("Honda"); //method 1
    std::unique_ptr<Car> car4 = std::make_unique<Car>("Tesla"); //method 1

    std::unique_ptr<Car> car3 (new Car("BMW")); //method 2

    //car3 = car1; Error Copying is not allowed

    car1->drive();
    std::unique_ptr<Car> car2 = std::move(car1); //cannot be copied, can be ony moved.
    car2->drive();
    
    if(car1)
    {
        car1->drive();
    }
    else
    {
        cout<<"ownership moved to car2, car1 is now nullptr"<<endl;
    }

    cout<<endl;
    car2.reset(car4.release());

    car2->drive();
    // car4->drive(); the resource for car4 is released, not valid anymore. car2 is reset to the object of car4

    return 0;
}