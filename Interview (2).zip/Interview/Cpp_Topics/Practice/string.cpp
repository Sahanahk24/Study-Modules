#include <iostream>
#include <vector>
#include <cstring>
using namespace std;

class MyString
{
    private:
        char* res;
        int len;
    public:
        MyString() : res(nullptr), len(0)
        { }

        MyString(const char* str)
        {
            len = strlen(str);
            res = new char[len+1];
            strcpy(res, str);
        }

        MyString(const MyString& obj)
        {
            len = obj.len;
            res = new char[len+1];
            strcpy(res, obj.res);
        }

        MyString& operator=(const MyString& obj)
        {
            if(this != &obj)
            {
                delete[] res;
                len = obj.len;
                res = new char[len + 1];
                strcpy(res, obj.res);
            }
            return *this;
        }

        MyString(MyString&& obj)
        {
            len = obj.len;
            res = obj.res;

            obj.len = 0;
            obj.res = nullptr;
        }

        MyString& operator=(MyString&& obj)
        {
            if(this != &obj)
            {
                delete[] res;
                len = obj.len;
                res = obj.res;

                obj.len =  0;
                obj.res = nullptr;
            }
            return *this;
        }

        ~MyString()
        {
            delete[] res;
        }

        int getLength()
        {
            return len;
        }

        friend ostream& operator<<(ostream& out, const MyString& obj);
};

ostream& operator<<(ostream& out, const MyString& obj)
{
    out<<obj.res<<endl;
    return out;
}

int main()
{
    MyString str1; //default c'tor
    MyString str2 = "Hello"; //parameterized c'tor
    cout<<str2;
    MyString str3 = str2; //copy constructor
    cout<<str3;
    // str1 = str3; //copy assignment operator overloading
    // MyString str4 = std::move(str2); //move copy c'tor
    // str1 = std::move(str4); //move assignement operator
    cout<<str1.getLength()<<endl;
    return 0;
}