#include <iostream>
#include <vector>
using namespace std;

class Sample{
    public:
        int data;
        int *ptr;
    
        Sample(int val=0, int* p = nullptr)
        {
            data = val;
            ptr = p;
        }

        Sample(const Sample& obj)
        {
            data = obj.data;
            ptr = new int();
            *ptr = *obj.ptr;
        }

        void display()
        {
            cout<<data<<" "<<ptr<<" "<<*ptr<<endl;
        }
};


int main()
{
    Sample s;
    s.data = 10;
    int a = 20;
    s.ptr = &a;
    s.display();

    Sample s1(s);
    s1.display();

    *s1.ptr = 40;
    s1.data = 30;
    s1.display();
}