#include <iostream>
// #include <vector>
using namespace std;

class MyVector
{
    private:
        int* arr;
        int capacity;
        int current;
    
    public:
        MyVector()
        {
            arr = new int[1];
            capacity = 1;
            current = 0;
        }

        MyVector(int size)
        {
            arr = new int[size];
            capacity = size;
            current = 0;
        }

        void push(int num)
        {
            if(current == capacity)
            {
                capacity *= 2;
                int* temp = new int[capacity];
                for(int i=0; i<current; i++)
                {
                    temp[i] = arr[i];
                }
                delete [] arr;
                arr = temp;
            }

            *(arr+current) = num;
            current++;
        }

        int getSize()
        {
            return current;
        }

        int getCapacity()
        {
            return capacity;
        }

        void displayVector()
        {
            for(int i=0; i<current; i++)
            {
                cout<<arr[i]<<" ";
            }
            cout<<endl;
        }

        ~MyVector()
        {
            delete[] arr;
        }
};


int main()
{
    MyVector arr;
    cout<<arr.getSize()<<endl;
    cout<<arr.getCapacity()<<endl;

    arr.push(10);
    arr.push(20);
    arr.push(30);
    arr.displayVector();
    cout<<arr.getSize()<<endl;
    cout<<arr.getCapacity()<<endl;
    
    arr.push(40);
    arr.push(50);
    arr.displayVector();
    cout<<arr.getSize()<<endl;
    cout<<arr.getCapacity()<<endl;
    return 0;
}