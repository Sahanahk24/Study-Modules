#include <iostream>
#include <vector>
using namespace std;

template<typename T1, typename T2>

class Calculator{

    public:
        T1 add(T1 a, T1 b)
        {
            return a+b;
        }

        T2 add(T2 a, T2 b)
        {
            return a+b;
        }

        auto add(T1 a, T2 b, T1 c) // we can also use auto to determine the type of result. will be taken care by compiler
        {
            return a+b+c;
        }
};


int main()
{
    Calculator<int, double> cal;
    cout<<cal.add(2, 3)<<endl;
    cout<<cal.add(2, 3.4, 4)<<endl;
    cout<<cal.add(2.2, 3.3)<<endl;

    return 0;
}
