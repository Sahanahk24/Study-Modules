#include <iostream>
#include <vector>
using namespace std;

class CopyConstructorExample
{
    public:
    int data;
    int *ptr;

    CopyConstructorExample(int val=0, int* p=nullptr)
    {
        data = val;
        ptr = p;
    }

    CopyConstructorExample(const CopyConstructorExample& obj)
    {
        data = obj.data;
        ptr = new int();
        *ptr = *obj.ptr;        
    }

    void display()
    {
        cout<<" data : "<<data<<"\n *ptr : "<<*ptr<<" \n ptr: "<<ptr<<endl<<endl;
    }

};


int main()
{
    int num = 20;
    CopyConstructorExample c1(10, &num);
    c1.display();

    CopyConstructorExample c2(c1);
    c2.display();

    *c2.ptr = 30;
    c2.data = 300;
    c2.display();

    c1.display();
    return 0;
}