#include <iostream>
#include <vector>
#include <cstring>
using namespace std;

class MyString
{
    private:
        char* res;
        unsigned int len;

    public:
        MyString() : res(nullptr), len(0) //default constructor
        {}

        MyString(const char* str) //Parameterized constructor
        {
            cout<<"Parameterized  ctor : <"<<str<<">"<<endl;
            len = strlen(str);
            res = new char[len + 1];
            strcpy(res, str);
        }

        MyString(const MyString& obj) //copy constructor 
        {
            len = obj.len;
            res = new char[len + 1];
            strcpy(res, obj.res);
        }

        MyString& operator=(const MyString& obj) //copy assignement operator
        {
            if(this != &obj)
            {
                len = obj.len;
                delete[] res;
                res = new char[len + 1];
                strcpy(res, obj.res);
            }
            return *this;
        }

        MyString(MyString&& obj) //move copy constructor
        {
            res = obj.res;
            len = obj.len;
            obj.res = nullptr;
            obj.len = 0;
        }

        MyString& operator=(MyString&& obj) //move copy assignment operator
        {
            if(this!=&obj)
            {
                delete [] res;
                res = obj.res;
                len = obj.len;

                obj.res = nullptr;
                obj.len = 0;
            }
            return *this;
        }  


        unsigned int length() //get length
        {
            return len;
        }

        ~MyString() //destructor
        {
            if(res)
            {
                delete [] res;
                res = nullptr;
                len = 0;
            }
        } 

        friend ostream& operator<<(ostream& out, const MyString& str); //overloading cout <<
        friend istream& operator>>(istream& in, const MyString& str); //overloading cin >>

};

ostream& operator<<(ostream& out, const MyString& str)
{
    out<<str.res<<endl;
    return out;
}

istream& operator>>(istream& in, const MyString& str)
{
    in>>str.res;
    return in;
}

int main()
{
    MyString str1; //Default Ctor
    MyString str2 = "Hello"; //Parameterized Ctor
    MyString str3 = str2; //Copy Constructor
    str1 = str2; //copy assignement operator
    int len = str2.length();
    cout<<len<<endl;
    cout<<str2;
    cout<<str1;
    cout<<str3;
    return 0;
}