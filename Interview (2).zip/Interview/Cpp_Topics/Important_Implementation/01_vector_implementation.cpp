#include <iostream>
// #include <vector>
using namespace std;


class myVector
{
    private:
        int* arr;
        int capacity;
        int current;

    public:
        myVector()
        {
            arr = new int[1];
            capacity = 1;
            current=0;
        }

        myVector(int size)
        {
            arr = new int[size];
            capacity = size;
            current = 0;
        }

        ~myVector() // Destructor to free memory
        {
            delete[] arr;
        }   

        int size()
        {
            return current;
        }

        void push_back(int num)
        {
            if(current == capacity)
            {
                capacity = 2*capacity;
                int* temp = new int[capacity];
                for(int i=0; i<current; i++)
                {
                    temp[i] = arr[i];
                }

                delete [] arr;
                arr = temp;
            }

            arr[current] = num;
            current++;
        }

        void pop_back()
        {
            current--;
        }

        int at(int index)
        {   
            try{
                if(index < current)
                {
                    return *(arr+index);
                }    
                else
                {
                throw out_of_range("Index out of bound");
                }
            } 
            catch (const out_of_range& e)
            {
            cout << e.what() << endl;
            return -1; // Returning a default value
            }
        }

        int getCapacity()
        {
            return capacity;
        }

};



int main()
{
    myVector vec;
    cout<<"size : "<<vec.size()<<endl;
    cout<<vec.getCapacity()<<endl;
    
    vec.push_back(100);
    cout<<"size : "<<vec.size()<<endl;
    cout<<vec.getCapacity()<<endl<<endl;
    
    vec.push_back(200);
    cout<<"size : "<<vec.size()<<endl;
    cout<<vec.getCapacity()<<endl<<endl;


    for(int i=0; i<vec.size(); i++)
    {
        cout<<vec.at(i)<<endl;
    }
    cout<<endl<<endl;
    vec.push_back(300);
    vec.push_back(400);
    vec.pop_back();
    vec.push_back(9);
    vec.push_back(3);
    for(int i=0; i<vec.size(); i++)
    {
        cout<<vec.at(i)<<endl;
    }
    
    cout<<"completed"<<endl;
    cout<<"size : "<<vec.size()<<endl;
    cout<<vec.getCapacity()<<endl<<endl;
}