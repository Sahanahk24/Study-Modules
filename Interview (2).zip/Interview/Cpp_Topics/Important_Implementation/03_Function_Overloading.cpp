#include <iostream>
#include <vector>
using namespace std;

class Calculator{

    public:
        int add(int a, int b)
        {
            return a+b;
        }

        int add(int a, int b, int c)
        {
            return a+b+c;
        }

        double add(double a, double b)
        {
            return a+b;
        }
};


int main()
{
    Calculator cal;
    cout<<cal.add(2, 3)<<endl;
    cout<<cal.add(2, 3, 4)<<endl;
    cout<<cal.add(2.2, 3.3)<<endl;

    return 0;
}