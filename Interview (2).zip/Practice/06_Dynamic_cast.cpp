#include <iostream>
#include <vector>
using namespace std;

class Base
{
    public:
    virtual void diplay()
    {
        cout<<"BASE"<<endl;
    }
};

class Derived1 : public Base
{
    public:
    void diplay(){cout<<"DERIVED  1"<<endl;}
};

class Derived2 : public Base
{
    public:
    void diplay(){cout<<"DERIVED  2"<<endl;}
};


int main()
{
    Derived1 d1;
    Base *ptr = dynamic_cast<Base*>(&d1); //upcasting

    Derived2 *dp = dynamic_cast<Derived2*>(ptr); //downcasting 

    if(dp == nullptr)
    {
        cout<<"NULL"<<endl;
    }
    else{
        cout<<"Not Null"<<endl;
    }

    return 0;
}