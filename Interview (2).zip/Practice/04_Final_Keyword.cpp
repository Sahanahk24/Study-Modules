#include <iostream>
#include <vector>
using namespace std;


class Parent //final
{
    public:
        virtual void show() //final
        {
            cout<<"Show from Parent"<<endl;
        }
};

class Child : public Parent
{
    public:
        void show()
        {
            cout<<"Show from Child"<<endl;
        }
};


int main()
{
    // Parent *ptr = new Child();
    Child ch;
    ch.show();
    // cout<<"*"<<endl;
    // ptr->show();
    return 0;
}