//Armstrong ==> 153 == 1^3 + 5^3 + 3^3

#include <iostream>
#include <math.h>
using namespace std;

bool armStrongNumberCheck(int num)
{
    int realValue = num;
    int result = 0;
    while(num>0)
    {
        int dig = num%10;
        result += dig*dig*dig;
        cout<<dig*dig*dig<<endl<<endl;
        num = num/10;
    }
    cout<<"result : "<<result<<endl;
    if(result==realValue)
    {
        return true;
    }
    return false;
}


int main()
{
    int num;
    cout<<"Enter Number : ";
    cin>>num;
    if(armStrongNumberCheck(num))
    {
        cout<<num<<" is ArmStrong number!\n";
    }
    else
    {
        cout<<num<<" is not an ArmStrong number!\n";
    }
}
