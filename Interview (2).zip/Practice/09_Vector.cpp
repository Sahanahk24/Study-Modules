#include <iostream>
#include <vector>
using namespace std;

class MyVector{
    private:
        int *arr;
        int capacity;
        int current;

    public:
        MyVector()
        {
            arr = new int[1];
            capacity = 1;
            current = 0;
        }

        MyVector(int size)
        {
            arr = new int[size];
            capacity = size;
            current = 0;
        }

        ~MyVector()
        {
            delete[] arr;
        }

        int size()
        {
            return current;
        }

        int getCapacity()
        {
            return capacity;
        }

        void push(int val)
        {
            if(current == capacity)
            {
                capacity = 2*capacity;
                int *temp = new int[capacity];
                for(int i=0; i<current+1; i++)
                {
                    *(temp+i) = *(arr+i);
                }
                delete [] arr;
                arr = temp;
            }

            *(arr+current) = val;
            current++;
        }

        void pop()
        {
            current = current-1;
        }

        int back()
        {
            return *(arr+current-1);
        }

        int front()
        {
            return *arr;
        }

        int at(int index)
        {
            try{
                if(index < current)
                {
                    return *(arr+index);
                }    
                else
                {
                throw out_of_range("Index out of bound");
                }
            } 
            catch (const out_of_range& e)
            {
            cout << e.what() << endl;
            return -1; // Returning a default value
            }
        }


};


int main()
{
    MyVector vec;
    cout<<vec.getCapacity()<<endl;
    cout<<vec.size()<<endl;

    vec.push(10);
    cout<<vec.getCapacity()<<endl;
    cout<<vec.size()<<endl;

    vec.push(20);
    cout<<vec.getCapacity()<<endl;
    cout<<vec.size()<<endl;

    vec.push(30);
    cout<<vec.getCapacity()<<endl;
    cout<<vec.size()<<endl;

    vec.push(40);
    vec.push(50);
    cout<<vec.getCapacity()<<endl;
    cout<<vec.size()<<endl;

    cout<<vec.back()<<endl;
    cout<<vec.front()<<endl;
    cout<<vec.at(3)<<endl;
    cout<<endl;
    for(int i=0; i<vec.size(); i++)
    {
        cout<<vec.at(i+1)<<endl;
    }
    return 0;
}