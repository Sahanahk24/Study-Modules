#include <iostream>
using namespace std;

bool isPrimeNumber(int num)
{
    bool isPrime = true;
    if(num<2)
    {
        return false;
    }
    for(int i=2; i<num; i++)
    {
        if(num%i==0)
        {
            isPrime = false;
            break;
        }
    }
    return isPrime;
}

int main()
{
    int num;
    cout<<"Enter the Number to check if its Prime : \n";
    cin>>num;
    if(isPrimeNumber(num))
    {
        cout<<num<<" is Prime"<<endl;
    }
    else
    {
        cout<<num<<" is not a Prime"<<endl;
    }

    cout<<endl<<endl;
    for(int i=0; i<=num;i++)
    {
        if(isPrimeNumber(i))
        {
            cout<<i<<" is Prime"<<endl;
        }
        else
        {
            cout<<i<<" is not a Prime"<<endl;
        }
    }
}