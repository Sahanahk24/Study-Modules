#include <iostream>
using namespace std;

int main()
{
    cout<<"GCD of 2 numbers"<<endl;
    int m,n;
    cout<<"Enter two numbers : \n";
    cin>>m>>n;
    while(m!=n)
    {
        if(m>n)
        {
            m=m-n;
        }
        else
        {
            n=n-m;
        }
    }
    cout<<"GCD : "<<m<<endl;
}