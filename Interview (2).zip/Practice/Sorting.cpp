#include <iostream>
using namespace std;
//Space complexity is O(1) for all three basic sortings


void bubbleSort(int arr[], int n)  
{
    //Best - O(n)  (for sorted Array)
    // Avg - O(n^2)
    //Worst - O(n^2)
    for(int i=0; i<n-1; i++)
    {
        bool isSwap = false;
        for(int j=0; j<n-i-1; j++)
        {
            if(arr[j]>arr[j+1])
            {
                isSwap = true;
                swap(arr[j], arr[j+1]);
            }
        }
        if(!isSwap)
        {
            return;
        }
        cout<<"run\n";
    }
}

void selectionSort(int arr[], int n)
{
    //Best - O(n^2) 
    // Avg - O(n^2)
    //Worst - O(n^2)
    for(int i=0; i<n-1; i++)
    {
        int min = i;
        for(int j=i+1; j<n-1; j++)
        {
            if(arr[j]<arr[min])
            {
                min = j;
            }
            swap(arr[i], arr[min]);
        }
    }
}

void insertionSort(int arr[], int n)
{
    //Best - O(n)  (for sorted Array)
    // Avg - O(n^2)
    //Worst - O(n^2)
    for(int i=0; i<n-1; i++)
    {
        int j = i;
        while(j>0 && arr[j-1]>arr[j])
        {
            swap(arr[j], arr[j-1]);
            j--;
        }
    }
}

void printArray(int arr[], int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    int arr[] = {34, 12, 9, 23, 0, -2, 60};
    //int arr[] = {1,2,3,4,5,6};
    // int arr[] = {6,5,4,3,2,1};
    int size = sizeof(arr)/sizeof(arr[0]);
    printArray(arr,size);

    //bubbleSort(arr,size);
    //selectionSort(arr,size);
    insertionSort(arr, size);
    printArray(arr,size);
    return 0;
}