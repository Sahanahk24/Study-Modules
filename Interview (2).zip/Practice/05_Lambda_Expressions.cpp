#include <iostream>
#include <vector>
using namespace std;

// Lambda expression
// syntax : [capture_List](paramter_list){body of func;}
// syntax : [capture_List](paramter_list){body of func}(); --> calling a function


int main()
{
    [](){cout<<"Lambda\n";}();

    [](int x, int y){cout<<"sum : "<<x+y<<endl;}(10,20);

    auto fun = [](int x, int y){cout<<"sum : "<<x+y<<endl;};
    fun(10,20);

    cout<<([](int x, int y){return x+y;}(10,20))<<endl;
    auto m = [](int x, int y){return x+y;}(10,20);
    cout<<m<<endl;
    auto n = [](int x, int y){return x+y;};
    cout<<n(10,20)<<endl;


    int a=10;
    [a](){cout<<a<<endl;}();
    auto f = [a](){cout<<a<<endl<<endl;}; //[&a]
    f();
    a++;
    f();


    return 0;
}