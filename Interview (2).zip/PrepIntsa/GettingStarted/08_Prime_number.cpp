/*
A prime number is a number that can be divided by 1 and itself 
i.e. a number that can not be divided by any other number other than 1 or itself is a prime number.
*/

#include <iostream>
using namespace std;

bool isPrime_number(int num){
    bool isPrime = true;
    if(num<2){
        return isPrime = false;
    }
    //if from 1 to n, count>2 then not prime
    //iterate from 2 to n --> Time Complexity : O(N)
    //iterate from 2 to n/2 --> Time Complexity : O(N)
    //iterate from 2 to sqrt(n) -->Time Complexity : O(√N) ,  most optimized code 
    //iterate from 3 to sqrt(n) -->Time Complexity : O(√N) ,  most optimized code with 1 more condition - if(num%2 == 0) -> not prime
    //check prepInsta for explanation
    
    for(int i=2; i<num;i++){
        if(num%i==0){
            isPrime = false;
            break;
        }
    }
    return isPrime;
}

int main(){
    int num;
    bool isPrime = true;
    cout<<"Enter a Number to check if its prime or not : ";
    cin>>num;
    //isPrime = isPrime_number(num);
        isPrime = isPrime_number(num);
        isPrime ? cout<<num<<" is prime number\n" : cout<<num<<" is not prime number\n";
    //isPrime ? cout<<num<<" is prime number\n" : cout<<num<<" is not prime number\n";
}