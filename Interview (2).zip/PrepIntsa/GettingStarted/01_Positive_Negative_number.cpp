//Check if a Number is Positive or Negative

#include <iostream>
using namespace std;

int main(){
    int num;
    cout<<"Enter the number to check if its +ve or -ve : ";
    cin>>num; 
    if(num>=0){
        if(num==0){
            cout<<num<<" is zero"<<endl;
        }
        else{
            cout<<num<<" is positive"<<endl;
        }
    }
    else{
        cout<<num<<" is negative"<<endl;
    }
    //ternary operator -> condition ? (if true) actionX : (if false) actionY 
    //if condition true then x else y

    num>=0 ? ((num>0) ? cout<<"Positive\n" : cout<<"Zero\n") : cout<<"Negative\n";


    num>=0 ? (num>0 ? cout<<"Positive" : cout<<"Zero")  : cout<<"negative";
}