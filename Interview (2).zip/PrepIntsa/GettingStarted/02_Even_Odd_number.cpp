#include <iostream>
using namespace std;

int main(){
    int num;
    cout<<"Enter the number to check if its odd or even : ";
    cin>>num; 
    (num%2==0) ? cout<<num<<" is even\n": cout <<num<<" is odd\n";

    if(num&1 == 1){
        cout<<"Odd";
    }
    else{
        cout<<"even";
    }
}

/*
Exaplanation : 
 5 - 101
 6 - 110
 12- 1100
 23- 10111

 now 5 & 1 --> 101 & 1
               101
               001
               ---
               001  --> 1 (odd)

 23 & 1 --> 10111 & 1
            10111
            00001
            -----
            00001 --> 1 (odd)

 12 & 1 --> 1100 & 1
            1100
            0001
            ----
            0000 --> 0 (even)              

*/