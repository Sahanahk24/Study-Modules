#include <iostream>
#include <math.h>
using namespace std;

int main(){
    cout<<"Greatest of Two Numbers"<<endl;
    int num1, num2, maxi;
    cout<<"Enter the 1st number : ";
    cin>>num1;
    cout<<"Enter the 2nd number : ";
    cin>>num2;
    cout<<"Using if-else"<<endl;
    if(num1==num2)
    {
        cout<<"Both numbers are equal and its "<<num1<<endl;
    }
    else if(num1>num2)
    {
        cout<<num1<<" is greatest"<<endl;
    }
    else{
        cout<<num2<< " is greatest"<<endl;
    }
    cout<<"Using ternary Operator"<<endl;
    if(num1==num2){
        cout<<"Both numbers are equal and its "<<num1<<endl;
    }
    else{
        num1>num2 ? cout<<num1<<" is largest\n" : cout<<num2<<" is largest\n";
    }
    cout<<"Using in-build function <math.h>"<<endl; 
    cout<<max(num1,num2)<<" is greater than "<<min(num1, num2)<<endl;
}