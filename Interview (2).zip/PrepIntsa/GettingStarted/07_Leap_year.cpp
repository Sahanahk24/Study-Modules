/*
Condtions for Leap Year
Following are the rules to predict if a given is a year leap or not. If any one of the conditions below is met then it's a leap year -
1. If a year is divisible by 400, it's a leap year.
2. If a year is divisible by 4 but not by 100 then its leap year
*/

//1800, 1900, 2100, 2200, 2300 and 2500 -> List of not Leap Years

#include <iostream>
using namespace std;

int main()
{
    int year;
    cout << "Enter year to check if its LEAP YEAR or not : ";
    cin >> year;
        if (year % 400 == 0 || ((year % 4 == 0) && (year % 100 != 0)))
        {
            cout << year << " is LEAP YEAR\n";
        }
        else
        {
            cout << year << " is not a LEAP YEAR\n";
        }

        cout<<"Using Ternary Operator\n";
        (year % 400 == 0 || ((year % 4 == 0) && (year % 100 != 0))) ? cout<<year<<" -> Leap year\n" : cout<<year<<" -> Not Leap year\n";
}

