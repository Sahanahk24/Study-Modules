/*
A prime number is a number that can be divided by 1 and itself 
i.e. a number that can not be divided by any other number other than 1 or itself is a prime number.
*/
//Most optimized code for prime number

#include <iostream>
#include <math.h>
using namespace std;

bool isPrime(int num){
    if(num<2){
        return false;
    }
    else if(num==2){
        return true;
    }
    else if(num%2 == 0){
        return false;
    }
    for(int i=3; i<=sqrt(num); i+=2){
        if(num%i == 0){
            return false;
            break;
        }
    }
    return true;
}


int main()
{   
    int lower, higher;
    cout<<"Enter the lower limit : ";
    cin>>lower;
    cout<<"Enter the higher limit : ";
    cin>>higher;
    for(int num=lower; num<=higher; num++){
        if(isPrime(num)){
            cout<<num<<" ";
        }
        //isPrime(num) ? cout<<num<<" is prime\n" : cout<<num<<" is not prime\n";
    }
}