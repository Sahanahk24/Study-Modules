#include <iostream>
using namespace std;
//(n(n+1))/2
int get_sum(int num){
    if(num==0){
        return num;
    }
    return num + get_sum(num-1);
}

int main(){
    int num;
    cout<<"Enter number to get the sum of first 'N' numbers : ";
    cin>>num;
    cout<<"\nUsing for loop\n";

    int sum=0;
    for(int i=1; i<=num; ++i){
        sum += i;
    } 
    cout<<"Sum of first "<<num<<" : "<<sum<<endl;
    cout<<endl;
    cout<<"Using recursion\n";

    int rec_sum = get_sum(num);
    
    cout<<"Rec_Sum of first "<<num<<" : "<<rec_sum<<endl;
    


}