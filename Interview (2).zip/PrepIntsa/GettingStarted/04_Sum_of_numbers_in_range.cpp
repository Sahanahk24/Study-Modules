//Find the Sum of Numbers in a Given Range
#include <iostream>
using namespace std;


int get_sum_in_range(int l,int h){
    if(l==h){
        return l;
    }
    return l + get_sum_in_range(l+1,h);
}

int main(){
    int start,end,sum=0;
    cout<<"Enter the start of range: ";
    cin>>start;
    cout<<"Enter the end of range: ";
    cin>>end;
    cout<<"\n Using for loop\n";
    for(int i=start; i<=end; i++){
        sum+=i;
    }
    cout<<"Sum of Number in range("<<start<<","<<end<<") : "<<sum<<endl;
    int formula_sum = end*(end+1)/2  -  start*(start+1)/2  + start;
    cout<<"\n Using formula\n";
    cout<<"Sum of Number in range("<<start<<","<<end<<") : "<<formula_sum<<endl;
    int r_sum = get_sum_in_range(start,end);
    cout<<"\n Using Recursion\n";
    cout<<"R_Sum of Number in range("<<start<<","<<end<<") : "<<r_sum<<endl;
}