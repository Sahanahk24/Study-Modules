#include <iostream>
#include <math.h>
using namespace std;

int main(){
    cout<<"Greatest of Three Numbers"<<endl;
    int num1, num2, num3;
    cout<<"Enter the 1st number : ";
    cin>>num1;
    cout<<"Enter the 2nd number : ";
    cin>>num2;
    cout<<"Enter the 3rd number : ";
    cin>>num3;
    cout<<"Using if-else"<<endl;
    if(num1==num2 && num2==num3)
    {
        cout<<"All 3 numbers are equal and its "<<num1<<endl;
    }
    else if(num1>num2)
    {
        if(num1>num3){
        cout<<num1<<" is greatest"<<endl;
        }
        else{
            cout<<num3<<" is greatest"<<endl;
        }
    }
    else if(num2>num3){
        cout<<num2<< " is greatest"<<endl;
    }
    else{
        cout<<num3<<" is greatest"<<endl;
    }
    cout<<"Using ternary Operator"<<endl;
    if(num1==num2 && num2==num3){
        cout<<"All 3 numbers are equal and its "<<num1<<endl;
    }
    else{
        num1>num2 ? (num1>num3 ? cout<<num1<<" is largest\n" : cout<<num3<<" is largesrt\n") : (num2>num3 ? cout<<num2<<" is largest\n" : cout<<num3<<" is largest\n");
    }
    cout<<"Using in-build function <math.h>"<<endl; 
    if(num1==num2 && num2==num3){
        cout<<"All 3 numbers are equal and its "<<num1<<endl;
    }
    else if(max(num1,num2) == max(num2, num3)){
        cout<<num2<<" is bigger"<<endl;
    }
    else if(max(num1,num2) == max(num1,num3)){
        cout<<num1<<" is bigger"<<endl;
    }
    else{
        cout<<num3<<" is bigger"<<endl;
    }
     cout<<max(num1,max(num2,num3))<<" is BIG"<<endl;
}