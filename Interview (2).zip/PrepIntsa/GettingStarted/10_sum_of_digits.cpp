/*
Sum of digits of a Number in C++
*/

#include <iostream>
using namespace std;

int sum_of_digits(int num){
    int sum=0;
    while(num!=0){
        int digit = num%10;
        sum += digit;
        num = num/10;
    } 
    return sum;
}

int main()
{
    int num;
    cout<<"Enter the number : ";
    cin>>num;
    cout<<"Sum of digits in "<<num<<" is "<<sum_of_digits(num)<<endl;
    string str_num = to_string(num);
    string exp = "";
    //cout<<"len of number: "<<str_num.length()<<endl;
    for(int i=0; i<str_num.length(); i++){
        exp+=str_num[i];
        if (i < str_num.length() - 1)
            exp += " + ";
    }
    cout<<exp<<" = "<<sum_of_digits(num)<<endl;
}