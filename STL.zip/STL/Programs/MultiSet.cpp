#include <iostream>
#include <set>
using namespace std;

int main(){
    cout<<"Multiset - can also store duplicate val in sorted order"<<endl;
    cout<<"multiset<int> s"<<endl;
    cout<<"multiset<int> s = {12, 23 ,32}"<<endl;
    cout<<"s.insert(key)"<<endl;
    cout<<"s.emplace(key)"<<endl;
    cout<<"s.size()"<<endl;
    cout<<"s.empty()"<<endl;
    cout<<"s.find(key)"<<endl;
    cout<<"s.count(key)"<<endl<<endl;
    cout<<"s.lower_bound(key) -  returns key if present or the next immediate greater key"<<endl;
    cout<<"s.upper_bound(key) -  returns greater than key"<<endl;

    multiset<int> s = {12, 23, 23, 23, 32};
    s.insert(12);
    s.insert(11);
    s.insert(123);
    s.emplace(212);
    cout<<"size : "<<s.size()<<endl;
    cout<<"count : "<<s.count(12)<<endl;
    multiset<int>::iterator set_itr;
    for(set_itr = s.begin(); set_itr!=s.end(); ++set_itr){
        cout<<*set_itr<<" ";
       // cout<<++*set_itr<<" ";  We cannot modify the elements in a set
    }
    cout<<endl;

    cout<<"s.lower_bound(12) : "<<*(s.lower_bound(12))<<endl;
    cout<<"s.lower_bound(20) : "<<*s.lower_bound(20)<<endl;
    cout<<"s.lower_bound(250) : "<<*s.lower_bound(250)<<endl; //0

    cout<<"s.upper_bound(11) : "<<*s.upper_bound(11)<<endl;
    cout<<"s.upper_bound(23) : "<<*s.upper_bound(23)<<endl;    
    cout<<"s.upper_bound(212) : "<<*s.upper_bound(212)<<endl;

    auto k = s.find(12);
    cout<<*k<<endl;

    auto c = s.count(23);
    cout<<c<<endl;
}

