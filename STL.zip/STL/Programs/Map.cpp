#include <iostream>
#include <map>

using namespace std;

int  main()
{
    map<string,int> m;
    cout<<"Map"<<endl;
    cout<<"map<string,int> m"<<endl;
    cout<<"m[\"key\"] = value"<<endl;
    cout<<"m.insert({\"key\",value})"<<endl;
    cout<<"m.emplace(\"key\",value)"<<endl;
    cout<<"m.size()"<<endl;
    cout<<"m.empty()"<<endl;
    cout<<"m.find(\"key\")"<<endl;
    cout<<"m.count(\"key\")"<<endl<<endl;

    m["Book"] = 50;
    m["Pen"] = 200;
    m["Laptop"] = 100;
    m.insert({"Camera",30});
    m.emplace("Clothes",130);
    cout<<"size : "<<m.size()<<endl;
    cout<<"isEmpty : "<<m.empty()<<endl<<endl;
    for(auto x:m)
    {
        cout<<x.first<<" "<<x.second<<endl;
    }
    cout<<endl;

    m.erase("Pen");
    cout<<"after removing Pen, size : "<<m.size()<<endl<<endl;
    for(auto x:m)
    {
        cout<<x.first<<" "<<x.second<<endl;
    }
    cout<<endl;

    if(m.find("Laptop") != m.end())
    {
        cout<<"Found\n";
    }
    else
    {
        cout<<"Not Found\n";
    }

    cout<<endl;

    cout<<"Laptop is Present: "<<m.count("Laptop")<<" count: "<<m["Laptop"]<<endl;

}