#include <iostream>
#include <queue>
#include <vector>

using namespace std;

int main()
{
    priority_queue<int> q1;
    q1.push(11);
    q1.push(299);
    q1.push(-30);
    q1.emplace(0);
    cout<<"front : "<<q1.top()<<endl;
    
    cout<<"size of q1 before swap: "<<q1.size()<<endl;

    priority_queue<int> q2;
    cout<<"size of q2 before swap : "<<q2.size()<<endl;
    q2.swap(q1);

    cout<<"size of q1 after swap: "<<q1.size()<<endl;
    cout<<"size of q2 after swap : "<<q2.size()<<endl;
    //by default, the largest element will be on top - highest priority (descending order)
    while(!q2.empty())
    {
        cout<<q2.top()<<" ";
        q2.pop();
    }
    cout<<endl<<endl;
    //To print in ascending order 
    
    priority_queue<int, vector<int>, greater<int>> q3;
    q3.push(290);
    q3.push(0);
    q3.push(87);
    q3.push(900);
    q3.emplace(-90);
    while(!q3.empty())
    {
        cout<<q3.top()<<" ";
        q3.pop();
    }
    cout<<endl;
    cout<<"end\n";
}