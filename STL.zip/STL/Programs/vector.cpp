#include <iostream>
#include <vector>
using namespace std;

int main()
{
    cout<<"Vector - In C++, vector is a dynamic array with the ability to resize itself automatically when an element is inserted or deleted\n\n";
    cout<<"Default Initialization : \n vector<T> vec_name;\n"<<endl;
    cout<<"Initialization with Size and Default Value : \n vector<T> vec_name(size, value);\n"<<endl;
    cout<<"Initialization Using Initializer List : \n vector<T> vec_name = { v1, v2, v3}; \n vector<T> vec_name ({ v1, v2, v3});\n\n";
    cout<<"               Few Functions for Vector \n";
    cout<<"-> size() - returns the number of elements present in a vector\n";
    cout<<"-> capacity() -  returns the number of elements an vector can hold. It keeps on updating (2X) if the existing capacity is completely filled.\n";
    cout<<"\n-> push_back(e) - inserts e at the end of the vector\n";
    cout<<"-> pop_back() - removes the last element from the vector\n";
    cout<<"\n-> v.at(idx) or v[idx] - gives the element at specified idx from the vector\n";
    cout<<"-> front() - returns the first element in the vector\n";
    cout<<"-> back() -  returns the last element int the vector\n";
    cout<<"\n-> erase(itr_idx) - removes the element at a particular index (iterator)\n";
    cout<<"-> erase(start,end) - removed the range of elements from start(inclusive) to end(exclusive) index from a vector\n";
    cout<<"\n-> insert(itr_idx, value) -  inserts value at the specified index\n";
    cout<<"-> insert(itr_idx, n, value) - inserts a value n times at the specified index\n";
    cout<<"-> insert(int_idx, start, end) -  inserts a range of elements at the specified index\n";
}