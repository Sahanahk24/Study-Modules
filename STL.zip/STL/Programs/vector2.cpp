#include <iostream>
#include <vector>
using namespace std;
    

    
int main(){
    vector<int> v1(10);
    vector<int> v2;
    vector<int> v3 = {12,56,400,122,12,6754,79,1009,23,44,-10,290};
    v3.push_back(780);
    v3.push_back(88888);
    cout<<"size : "<<v3.size()<<endl;
    cout<<"Iterating using for loop\n";
    for(int i=0; i<v3.size(); ++i){
        cout<<v3[i]<<" ";
    }
    cout<<endl<<endl;
    cout<<"pop_back() - removes the last elemet\n";
    v3.pop_back();
    cout<<"size : "<<v3.size()<<endl;
    cout<<"Iterating using a for_each loop\n";
    for(int x : v3){
        cout<<x<<" ";
    }
   cout<<endl<<endl;
    cout<<"Other Vector Functions : \n";
    cout<<v3.at(4)<<endl; //returns the element at that index
   // cout<<v3.count(12);
    cout<<v3.back()<<endl; //returns the last element in a vector
    cout<<v3.front()<<endl; //returns the first element in a vector
    cout<<v3.capacity()<<endl; //capacity of vector )(keeps updating based on the number of elements in a vector)
    cout<<v3.max_size()<<endl; //max_size of a vector
    cout<<v3.data()<<endl;  //returns the address of first element
    cout<<*v3.data()<<endl;  //dereferencing the value
    cout<<2*(*v3.data())<<endl;  

    //cout<<v3.emplace()<<endl;
    // v3.clear();
    cout<<endl<<endl;
    cout<<"Iterating using the object of an iterator\n";
    vector<int>::iterator itr;
    for(itr = v3.begin(); itr!=v3.end(); itr++){
        cout<<*itr<<" ";
    }
    cout<<endl;
    cout<<"\nv3.begin() | v3.end() | v3.rbegin() | v3.rend()\n";
    auto start = v3.begin();
    auto end = v3.end();
    auto r_start = v3.rbegin();
    auto r_end = v3.rend();
    cout<<*start<<" "<<*end<<endl;
    cout<<*r_start<<" "<<*r_end<<endl;

    cout<<endl<<endl;

    for(itr=v3.begin(); itr!=v3.end(); itr++){
        cout<<++*itr<<" ";
    }
    cout<<endl;
    cout<<"---------"<<endl;

    for(int x: v3){
        cout<<x<<" ";
    }
    cout<<endl;
    cout<<"---------"<<endl;

    for(int &x:v3){
        cout<<++x<<" ";
    }
    cout<<endl;

    cout<<"---------"<<endl;
    for(int x: v3){
        cout<<x<<" ";
    }
    cout<<endl;
    cout<<"--------"<<endl;
    for(int x: v3){
        cout<<++x<<" ";
    }
    cout<<endl;
    cout<<"-------"<<endl;
    for(int x: v3){
        cout<<x<<" ";
    }
    cout<<endl;
}