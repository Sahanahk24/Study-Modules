#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
    string s = "abc";
    next_permutation(s.begin(), s.end());
    cout<<"next_permutation : "<<s<<endl;

    string s1 = "cba";
    prev_permutation(s1.begin(), s1.end());
    cout<<"prev_permutation : "<<s1<<endl<<endl;

    vector<int> v = {12, -2, 78, 2899, 231};
    for(auto x:v)
    {
        cout<<x<<" ";
    }
    cout<<endl;
    reverse(v.begin(), v.end());
    for(auto x:v)
    {
        cout<<x<<" ";
    }
    cout<<endl<<endl;

    cout<<"min_element : "<<*min_element(v.begin(), v.end())<<endl;
    cout<<"max_element : "<<*max_element(v.begin(), v.end())<<endl<<endl;

    int a=8, b=13;
    cout<<"a : "<<a<<"  b : "<<b<<endl;
    swap(a,b);
    cout<<"a : "<<a<<"  b : "<<b<<endl<<endl;

    cout<<"min : "<<min(a,b)<<endl;
    cout<<"max : "<<max(a,b)<<endl<<endl;

    vector<int> b1 = {1, 23, 43, 53, 222, 289, 987};
    cout<<"binary_search : "<<binary_search(b1.begin(), b1.end(), 43)<<endl<<endl;

    cout<<"count set bits for "<<a<<" : "<<__builtin_popcount(a)<<endl; // 1101
    long c = 30;
    cout<<"count set bits for "<<c<<" : "<<__builtin_popcountl(c)<<endl; //11110


}