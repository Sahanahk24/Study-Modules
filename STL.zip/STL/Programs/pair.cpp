#include <iostream>
#include <vector>
//#include <utility>
using namespace std;

void explainPair(){
    pair<string, double> PAIR2("GeeksForGeeks", 1.23);
    pair<int, int> p1;
    p1 = {1,3};
    cout<<p1.first<<" "<<p1.second<<endl;

    pair<int, string> p2 = {12, "Sufyan"};
    cout<<p2.first<<" : "<<p2.second<<endl;

    pair<int, pair<int , int>> p3 = {10,{20,30}};
    cout<<p3.first<<" "<<p3.second.first<<" "<<p3.second.second<<endl;

    pair<pair<int, int>, pair<int , int>> p4 = {{10,99},{20,30}};
    cout<<p4.first.first<<" "<<p4.first.second<<" "<<p3.second.first<<" "<<p3.second.second<<endl;

    pair<int, int> arr[] = {{112,22},{14,5},{66,74},{-1,-23}};
    cout<<"size : "<<sizeof(arr)/sizeof(arr[0])<<endl;
    cout<<arr[1].second<<endl;

    pair <int, int> g;
    g= make_pair(12, 34);
    cout<<g.first<<" "<<g.second<<endl;

    pair <string, int> p = {"Sufyan", 233};
    cout<<p.first<<" : "<<p.second<<endl;

    vector<pair<int,int>> k = {{2,3},{3,4},{4,5}};
    k.push_back({10,20});
    for(pair<int,int> p : k)
    {
        cout<<p.first<<" "<<p.second<<endl;
    }
    k.emplace_back(100,200);
    cout<<endl;
    for(auto x:k)
    {
        cout<<x.first<<" "<<x.second<<endl;
    }

}

void explainMemberFunctionsOfPair(){
    cout<<"make_pair()"<<endl;
    pair <int, float> p1(199, 23.1f);
    pair <int , int> p2;
    p2 = make_pair(12, 233);
    cout<<p1.first<<" "<<p1.second<<endl;
    cout<<p2.first<<" "<<p2.second<<endl;

    cout<<"swap()\n";
    pair<int, int> p3(10, 20);
    pair<int, int> p4={30,40};
    cout<<"Before Swapping\n";
    cout<<p3.first<<" "<<p3.second<<endl;
    cout<<p4.first<<" "<<p4.second<<endl;
    cout<<"After Swapping\n";
    p3.swap(p4);
    cout<<p3.first<<" "<<p3.second<<endl;
    cout<<p4.first<<" "<<p4.second<<endl;
}

int main(){
    cout<<"Pair in C++"<<endl;
    explainPair();
    //explainMemberFunctionsOfPair();
    return 0;
}