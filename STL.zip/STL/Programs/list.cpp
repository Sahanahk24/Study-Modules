#include <iostream>
#include <list>
using namespace std;

int main()
{
    list<int> v1(10);
    list<int> v2;
    list<int> v3 = {12,56,400,122,6754,79,1009,23,44,-10,290};
    cout<<"list\n";
    cout<<v1.size()<<endl;
    cout<<v2.size()<<endl;
    cout<<v3.size()<<endl;
    cout<<endl<<endl;
    cout<<"push_back() - insert at the end\n";
    v3.push_back(780);
    v3.push_back(88888);
    cout<<"size : "<<v3.size()<<endl;
    cout<<endl<<endl;
    cout<<"pop_back() - removes the last elemet\n";
    v3.pop_back();
    cout<<"size : "<<v3.size()<<endl;
    cout<<"Iterating using a for_each loop\n";
    for(int x : v3){
        cout<<x<<" ";
    }
   cout<<endl<<endl;
    cout<<"Other Vector Functions : \n";
    cout<<v3.back()<<endl; //returns the last element in a vector
    cout<<v3.front()<<endl; //returns the first element in a vector
    cout<<v3.max_size()<<endl; //max_size of a vector 
    //cout<<v3.emplace()<<endl;
    // v3.clear();
    cout<<endl<<endl;
    cout<<"Iterating using the object of an iterator\n";
    list<int>::iterator itr;
    for(itr = v3.begin(); itr!=v3.end(); itr++){
        cout<<*itr<<" ";
    }

    //cout<<v3[3]<<endl; // throws error -> list does not have random access to memory
    cout<<endl;
    cout<<"\nv3.begin() | v3.end() | v3.rbegin() | v3.rend()\n";
    auto start = v3.begin();
    auto end = v3.end();
    auto r_start = v3.rbegin();
    auto r_end = v3.rend();
    cout<<*start<<" "<<*end<<endl;
    cout<<*r_start<<" "<<*r_end<<endl;

    cout<<endl<<endl;

    for(itr=v3.begin(); itr!=v3.end(); itr++){
        cout<<++*itr<<" ";
    }
    cout<<endl;
    cout<<"---------"<<endl;

    for(int x: v3){
        cout<<x<<" ";
    }
    cout<<endl;
    cout<<"---------"<<endl;

    for(int &x:v3){
        cout<<++x<<" ";
    }
    cout<<endl;

    cout<<"---------"<<endl;
    for(int x: v3){
        cout<<x<<" ";
    }
    cout<<endl;
    cout<<"--------"<<endl;
    for(int x: v3){
        cout<<++x<<" ";
    }
    cout<<endl;
    cout<<"-------"<<endl;
    for(int x: v3){
        cout<<x<<" ";
    }
    cout<<endl;
}