#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
    vector<int> v = {12, 23, 43, -90, 2990,-128, 0};
    v.push_back(78);
    v.emplace_back(11);
    for(auto x : v)
    {
        cout<<x<<" ";
    }
    cout<<endl;

    sort(v.begin(), v.end(), greater<int>());  //sorts in descending order
    //sort(v.begin(), v.end());                 //sorts in ascending order

    for(auto x : v)
    {
        cout<<x<<" ";
    }
    cout<<endl<<endl;

    int arr[] = {12,0, 67, 900, 346, 192 , -53};
    int size = sizeof(arr)/sizeof(arr[0]);
    for(int i=0; i<size; i++ )
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    reverse(arr,arr+size);
    for(auto x : arr)
    {
        cout<<x<<" ";
    }
    cout<<endl;

    sort(arr,arr+size);                //sorts in ascending order
    //sort(arr,arr+size,greater<int>()); //sorts in descending order
    for(auto x : arr)
    {
        cout<<x<<" ";
    }
    cout<<endl<<endl;
    


    vector<int> v1 = {90,76,-9, 500, 234, 546,1};
    reverse(v1.begin(),v1.end()-5); //Reverses the elements in an arr/vec
    for(auto x : v1)
    {
        cout<<x<<" ";
    }
    cout<<endl<<endl;


}