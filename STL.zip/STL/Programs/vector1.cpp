#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int> v;
    cout<<"size  : "<<v.size()<<endl;
    cout<<"capacity  : "<<v.capacity()<<endl<<endl;

    v.push_back(10);
    cout<<"size  : "<<v.size()<<endl;
    cout<<"capacity  : "<<v.capacity()<<endl<<endl;

    v.push_back(20);
    cout<<"size  : "<<v.size()<<endl;
    cout<<"capacity  : "<<v.capacity()<<endl<<endl;

    v.push_back(30);
    v.push_back(40);
    v.push_back(50);
    cout<<"size  : "<<v.size()<<endl;
    cout<<"capacity  : "<<v.capacity()<<endl<<endl;
    cout<<"Using iterator\n";
    
    vector<int>::iterator itr;
    for(itr=v.begin(); itr!=v.end(); itr++)
    {
        cout<<*itr<<" ";
    }
    cout<<endl;

    vector<int>::reverse_iterator itr1;
    for(itr1=v.rbegin(); itr1!=v.rend(); itr1++)
    {
        cout<<*itr1<<" ";
    }
    cout<<endl;

    cout<<"Using Auto\n";
    for(auto itr1=v.rbegin(); itr1!=v.rend(); itr1++)
    {
        cout<<*itr1<<" ";
    }
}

    
