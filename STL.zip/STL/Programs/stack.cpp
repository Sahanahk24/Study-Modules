#include <iostream>
#include <stack>
#include <vector>
using namespace std;

int main()
{
    stack<int> s1;
    s1.push(10);
    s1.push(20);
    s1.push(30);
    s1.emplace(40);

    vector<int> vec = {12,-9, 23, 67, 344, 209};
    // Create a stack from the vector
    stack<int, vector<int>> myStack(vec);
    

    stack<int> s2;
    stack<int> s3(s1); //copy s1 to s3
    cout<<"top : "<<s1.top()<<endl;

    cout<<"size of s1 before swap: "<<s1.size()<<endl;
    cout<<"size of s2 before swap : "<<s2.size()<<endl;

    s2.swap(s1);

    cout<<"size of s1 after swap: "<<s1.size()<<endl;
    cout<<"size of s2 after swap : "<<s2.size()<<endl;

    while(!s2.empty())
    {
        cout<<s2.top()<<" ";
        s2.pop();
    }
    cout<<endl<<endl;

    cout<<"s3\n";
    while(!s3.empty())
    {
        cout<<s3.top()<<" ";
        s3.pop();
    }
    cout<<endl<<endl;

     cout<<"myStack\n";
    while(!myStack.empty())
    {
        cout<<myStack.top()<<" ";
        myStack.pop();
    }
    cout<<endl;

}