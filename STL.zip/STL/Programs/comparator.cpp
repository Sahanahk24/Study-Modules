#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;


bool sortSecond(pair<int,int> p1, pair<int,int> p2)
{
    if(p1.second<p2.second) return true;
    if(p1.second>p2.second) return false;
    if(p1.first<p1.second) return true;
    else return false;
}

int main()
{
    vector<pair<int,int>> p = {{2,3},{44,7},{1,22},{4,9},{1,12}};
    p.push_back({78,-23});
    p.emplace_back(11,100);
    vector<pair<int,int>> q(p);

    for(auto x : p)
    {
        cout<<x.first<<" "<<x.second;
        cout<<endl;
    }
    cout<<endl;

    
    sort(p.begin(), p.end());
    for(auto x : p)
    {
        cout<<x.first<<" "<<x.second;
        cout<<endl;
    }
    cout<<endl<<endl;

    sort(q.begin(),q.end(), sortSecond);
    for(auto x : q)
    {
        cout<<x.first<<" "<<x.second;
        cout<<endl;
    }
    cout<<endl;




}