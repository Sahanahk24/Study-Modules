#include <iostream>
#include <queue>
#include <vector>
using namespace std;

int main()
{
    queue<int> q1;
    q1.push(10);
    q1.push(20);
    q1.push(30);
    q1.emplace(40);

    vector<int> vec = {12,-9, 23, 67, 344, 209};
    // Create a stack from the vector
    queue<int, vector<int>> myQueue(vec);

    queue<int> q2;
    queue<int> q3(q1); //copies q1 to q3
    cout<<"front : "<<q1.front()<<endl;

    cout<<"size of q1 before swap: "<<q1.size()<<endl;    
    cout<<"size of q2 before swap : "<<q2.size()<<endl;

    q2.swap(q1);

    cout<<"size of q1 after swap: "<<q1.size()<<endl;
    cout<<"size of q2 after swap : "<<q2.size()<<endl;

    while(!q2.empty())
    {
        cout<<q2.front()<<" ";
        q2.pop();
    }
    cout<<endl<<endl;

    cout<<"q3\n";
    while(!q3.empty())
    {
        cout<<q3.front()<<" ";
        q3.pop();
    }
    cout<<endl<<endl;

    cout<<"myStack\n";
    // while(!myQueue.empty())
    // {
    //     cout<<myQueue.front()<<" ";
    //     myQueue.pop();
    // // }
    // // cout<<endl;
    // while populating a queue with a vector
    // here the pop() will fail because in vector we dont have pop_front
    // but it works in stack.
}