#include <iostream>
#include <unordered_map>

using namespace std;

int  main()
{
    unordered_map<string,int> m;
    cout<<"Unordered_Map"<<endl;
    cout<<"map<string,int> m"<<endl;
    cout<<"m[\"key\"] = value "<<endl;
    cout<<"m.insert({\"key\",value})"<<endl;
    cout<<"m.emplace(\"key\",value)"<<endl;
    cout<<"m.size()"<<endl;
    cout<<"m.empty()"<<endl;
    cout<<"m.find(\"key\")"<<endl;
    cout<<"m.count(\"key\")"<<endl<<endl;

    m["Book"] = 50;
    m.insert({"Pen",390});
    m.insert({"Pen",3});  //ignored
    m.insert({"Pen",30}); //ignored
    m.insert({"Pen",90}); //ignored
    m.emplace("Computer",9);
    m.insert({"Camera",30});
    m.emplace("Clothes",130);

    cout<<"size : "<<m.size()<<endl;
    cout<<"isEmpty : "<<m.empty()<<endl<<endl;
    for(auto x:m)
    {
        cout<<x.first<<" "<<x.second<<endl;
    }
    cout<<endl;

    m.erase("Computer"); //Removes all duplicate keys - Computer
    cout<<"after removing Computer, size : "<<m.size()<<endl<<endl;
    for(auto x:m)
    {
        cout<<x.first<<" "<<x.second<<endl;
    }
    cout<<endl;

    if(m.find("Clothes") != m.end())
    {
        cout<<"Found\n";
    }
    else
    {
        cout<<"Not Found\n";
    }

    cout<<endl;

    cout<<"Book is Present: "<<m.count("Book")<<"  | count: "<<m["Book"]<<endl;
    for( auto it = m.find("Pen"); it != m.end() && it->first == "Pen";it++)
    {
        cout << it->first << ": " << it->second << endl;
    }
    cout<<endl;
    m.erase(m.find("Pen")); //removes only 1st Key Pen : 390
    for(auto x:m)
    {
        cout<<x.first<<" "<<x.second<<endl;
    }
    cout<<endl;

    for(auto c = m.find("Clothes"); c != m.end() && c->first=="Clothes"; c++)
    {
        cout<<c->first<<" : "<<c->second <<endl;
    }
}