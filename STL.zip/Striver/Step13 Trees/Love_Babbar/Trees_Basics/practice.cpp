#include <iostream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;

class Node{
    public:
        int data;
        Node* left;
        Node* right;

        Node(int val)
        {
            this->data = val;
            this->left = NULL;
            this->right = NULL;
        }
};

Node* createTree()
{
    int data;
    cout<<"Enter Data: ";
    cin>>data;
    Node* root = new Node(data);
    if(data == -1)
    {
        return NULL;
    }

    cout<<"Enter left node data for "<<data<<endl;
    root->left = createTree();

    cout<<"Enter right node data for "<<data<<endl;
    root->right = createTree();

    return root;
}

void levelOrderTraversal(Node* root)
{
    if(!root) {return;}
    queue<Node*> q;
    q.push(root);
    while(!q.empty())
    {
        Node* temp = q.front();
        cout<<temp->data<<" ";
        q.pop();

        if(temp->left) {q.push(temp->left);}
        if(temp->right) {q.push(temp->right);}
    }
}

void reverseLevelOrderTree(Node* root)
{
    queue<Node*> q;
    stack<int> s;
    q.push(root);

    while(!q.empty())
    {
        Node* temp = q.front();
        s.push(temp->data);
        q.pop();

        if(temp->right) {q.push(temp->right);}
        if(temp->left) {q.push(temp->left);}
    }

    while(!s.empty())
    {
        cout<<s.top()<<" ";
        s.pop();
    }
}

void Level_Order_Traversal_Tree(Node* root, int& len)
{
    if(!root) { return; }
    queue<Node*> q;
    q.push(root);
    q.push(NULL);

    while(!q.empty())
    {
        Node* temp = q.front();
        q.pop();
        if(temp == NULL)
        {
            len++;
            cout<<endl;
            if(!q.empty())
            {
                q.push(NULL);
            }
        }
        else
        {
            cout<<temp->data<<" ";
            if(temp->left) {q.push(temp->left);}
            if(temp->right) {q.push(temp->right);}
        }
    }
}

int main()
{
    Node* root = createTree(); //1 2 4 -1 -1 5 -1 -1 3 6 -1 -1 7 -1 -1 
    levelOrderTraversal(root);
    cout<<endl;
    int height = 0;
    Level_Order_Traversal_Tree(root, height);
    cout<<"Height of Tree: "<<height<<endl<<endl;
    reverseLevelOrderTree(root);
    return 0;
}