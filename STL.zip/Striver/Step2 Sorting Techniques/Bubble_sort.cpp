#include <iostream>
using namespace std;
//Best - O(n)  (for sorted Array)
//Avg - O(n^2)
//Worst - O(n^2)
//Space complexity - O(1)


void bubble_sort(int arr[], int size)
{
    for(int i=0; i<size-1; i++)
    {
        for(int j=0; j<size-i-1; j++)
        {
            if(arr[j]>arr[j+1])
            {
                swap(arr[j], arr[j+1]);
            }
        }
    }
}

void printArray(int arr[], int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
     //int arr[] = {10, 23, -4, 34, 7, 39, 403, 45, 90};
    int arr[] = {4,1,5,2,3};
    int n = sizeof(arr)/sizeof(arr[0]);

    cout<<"Before Sorting \n";
    printArray(arr, n);
    
    bubble_sort(arr,n);
    
    cout<<"After Sorting\n"; 
    printArray(arr, n);

    return 0;
}