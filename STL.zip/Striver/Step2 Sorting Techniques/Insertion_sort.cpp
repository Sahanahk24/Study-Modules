#include <iostream>
using namespace std;
//Best - O(n)  (for sorted Array)
//Avg - O(n^2)
//Worst - O(n^2)
//Space complexity - O(1)

void printArray(int arr[], int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}


void InsertionSort(int arr[], int n)
{
    for(int i=0; i<n-1; i++){
        int j=i;
        while(j>0 && arr[j-1]>arr[j])
        {
            swap(arr[j], arr[j-1]);
            j--;
        }
    }
}

int main()
{
    int arr[] = {34, 12, 9, 23, 0, -2, 60};
    //int arr[] = {1,2,3,4,5,6};
    // int arr[] = {6,5,4,3,2,1};
    int size = sizeof(arr)/sizeof(arr[0]);
    printArray(arr,size);

    InsertionSort(arr,size);
    printArray(arr,size);
    return 0;
}