//https://www.naukri.com/code360/problems/largest-element-in-the-array-largest-element-in-the-array_5026279?utm_source=youtube&utm_medium=affiliate&utm_campaign=striver_Arrayproblems


#include <iostream>
#include <algorithm>
using namespace std;

int largest_brute(int arr[], int n)
{
    sort(arr,arr+n);
    return arr[n-1];
}

int largest_optimal(int arr[], int n)
{
    int max = arr[0];
    for(int i=0; i<n; i++)
    {
        if(arr[i]>max)
        {
            max = arr[i];
        }
    }
    return max;
}


int main()
{
    int arr[] = {12, 34, 45, 2, 5, 98, 34, -17};
    int size = sizeof(arr)/sizeof(arr[0]);

    cout<<largest_brute(arr,size)<<endl;    //O(nlogn) brute
 
    cout<<largest_optimal(arr, size)<<endl; //O(n) optimal

    return 0;
}