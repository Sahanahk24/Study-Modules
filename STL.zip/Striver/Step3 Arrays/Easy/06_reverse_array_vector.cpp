#include <iostream>
#include <vector>
using namespace std;

void printVector(vector<int> arr)
{
    for(auto x : arr)
    {
        cout<<x<<" ";
    }
    cout<<endl;
}

void printArray(int arr[], int n)
{
    for(int i=0; i<n ; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

void reverseArray(int arr[], int start, int end)
{
    while(start<=end)
    {
        swap(arr[start], arr[end]);
        start++; 
        end--;
    }
}

void reverseVector(vector<int> &arr, int start, int end)
{
    while(start<=end)
    {
        swap(arr[start], arr[end]);
        start++; 
        end--;
    }
}

int main()
{
    cout<<endl;
    int a[] = {10,20,30,40,50,60};
    int n = sizeof(a)/sizeof(a[0]);
    printArray(a, n);
    reverseArray(a,0,n-1);
    printArray(a, n);

    cout<<endl;
    vector<int> v = {11,22,33,44,55,66};
    printVector(v);
    reverseVector(v,0,v.size()-1);
    printVector(v);
    return 0;
}