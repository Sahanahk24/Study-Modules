#include <iostream>
using namespace std;



int main()
{   
    string s = "asdsjsashdabbcba";
    cout<<s<<endl;
    int size = s.length();
    int hash[256] = {0};
    for(int i=0; i<size; i++)
    {
        hash[s[i]] += 1;
    }

    int q;
    cout<<"query : ";
    cin>>q;
    while(q--)
    {
        int num;
        cout<<"Num : "; 
        cin>>num;
        cout<<hash[num]<<endl;
    }
    return 0;
}