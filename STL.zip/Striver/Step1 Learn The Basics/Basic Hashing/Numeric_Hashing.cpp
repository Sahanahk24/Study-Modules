#include <iostream>
using namespace std;

//Incorrect hashmap for values in -ve or out of size.

int main()
{
    int arr[] = {12, 1, 2, 3, 2, 1, 2, 4, 4,5,5};
    int size = sizeof(arr)/sizeof(arr[0]);
    cout<<"size : "<<size<<endl;
    int hash[size+1] = {0};
    for(int i=0; i<size-1; i++)
    {
        hash[arr[i]] += 1;
    }
    int q;
    cout<<"query : ";
    cin>>q;
    while(q--)
    {
        int num;
        cout<<"Num : "; 
        cin>>num;
        cout<<hash[num]<<endl;
    }
    return 0;
}