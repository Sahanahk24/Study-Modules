/*
ecludean algorithm --> gcd(a, b) == gcd (a-b, b) where a>b;
keep repeating unless you find one the number is 0. then the other number is gcd value. 

ex : a = 10, b = 5    x  = min(10,5)
gcd(10, 5) = gcd ( 10-5, 5)
gcd(5,5) = gcd (0, 5) ==> 5 is GCD value
*/

// here the optimised approach is instead of doing a - b we can go with a%b to get less iterations



#include <iostream>
using namespace std;

int gcd_Ecludean(int a, int b)    //TC: O(log_pimin(a,b))  //check notes
{
    while(a>0 && b>0)
    {
        if(a>b)
        {
            a = a % b;
        }
        else
        {
            b = b % a;
        }
    }
    return (a==0 ? b : a);
}


int main()
{
    int num1, num2;
    cout<<"Enter num1: ";
    cin>>num1;
    cout<<"Enter num2: ";
    cin>>num2;
    int res = gcd_Ecludean(num1,num2);
    cout<<"greated Common Divisor of "<<num1<<" and "<<num2<<" : "<<res<<endl;
    return 0;
}