//Very bad approach but its initial brute force


#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int getGcd(int num1, int num2)
{
    vector<int> v1, v2, res;
    for(int i=1; i<=num1; i++)
    {
        if(num1%i==0)
        {   
            cout<<"num1 : "<<i<<endl;
            v1.push_back(i);
        }
    }
    cout<<endl;
    for(int i=1; i<=num2; i++)
    {
        if(num2%i==0)
        {   
            cout<<"num2 : "<<i<<endl;
            v2.push_back(i);
        }
    }
    for(auto x:v1){
        auto it = find(v2.begin(), v2.end(), x);
        if(it != v2.end())
        {
            res.push_back(*it);
        }
    }
    return *max_element(res.begin(), res.end());
}


int main()
{
    int num1, num2;
    cout<<"Enter num1: ";
    cin>>num1;
    cout<<"Enter num2: ";
    cin>>num2;
    int res = getGcd(num1,num2);
    cout<<"greated Common Divisor of "<<num1<<" and "<<num2<<" : "<<res<<endl;
    return 0;
}