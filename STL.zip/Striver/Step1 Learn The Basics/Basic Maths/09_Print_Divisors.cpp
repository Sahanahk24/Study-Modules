//Print all divisors
//https://www.geeksforgeeks.org/problems/sum-of-all-divisors-from-1-to-n4738/1

#include <iostream>
#include <bits/stdc++.h>
using namespace std;

vector<int> getFactors_optimal(int num)  //TC - O(sqrt(n)) //optimal
{
    int sqr = sqrt(num);
    vector<int> factors;

    for(int i=1; i<=sqr; i++)
    {
        if(num%i==0)
        {
            factors.push_back(i);
            if(i != num/i)
            {
                factors.push_back(num/i);
            }
        }
    }
    return factors;
}

vector<int> getFactors_bruteForce(int num)  //TC - O(n)
{
    vector<int> factors;

    for(int i=1; i<=num; i++)
    {
        if(num%i==0)
        {
            factors.push_back(i);
        }
    }
    return factors;
}


int main()
{
    int num;
    cout<<"Enter the number: ";
    cin>>num;
    vector<int> factors = getFactors_optimal(num);
    sort(factors.begin(), factors.end());
    for(auto x : factors)
    {
        cout<<x<<" ";
    }
    cout<<endl<<endl;

    vector<int> res = getFactors_bruteForce(num);
    for(auto x : factors)
    {
        cout<<x<<" ";
    }

    return 0;
}