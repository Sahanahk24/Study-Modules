/*

*         *
* *     * *
* * * * * *
* *     * *
*         *

n=3
*/

#include <iostream>
using namespace std;

void printPattern(int n)
{
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            if(j<=i){
                cout<<"* ";
            }
            else{
                cout<<"  ";
            }
        }
        for(int k=0; k<n; k++){
            if(k<n-i-1){
                cout<<"  ";
            }
            else{
                cout<<"* ";
            }
        }
        cout<<endl;
    }
    n = n-1;
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            if(j<n-i){
                cout<<"* ";
            }
            else{
                cout<<"  ";
            }
            if(j==n-1){
                cout<<"    ";
            }
        }
        for(int k=0; k<n; k++){
            if(k>=i){
                cout<<"* ";
            }
            else{
                cout<<"  ";
            }
        }
        cout<<endl;
    }
}

int main()
{
    int Num;
    cout<<"Num : ";
    cin>>Num;
    printPattern(Num);
}