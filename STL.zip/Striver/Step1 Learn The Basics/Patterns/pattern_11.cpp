/*
        *
      * * *
    * * * * *
  * * * * * * *
* * * * * * * * *
* * * * * * * * *
  * * * * * * *
    * * * * *
      * * *
        *
*/

#include <iostream>
using namespace std;

void printPattern(int n)
{
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            if(j<n-i-1){
                cout<<"  ";
            }
        }
        for(int k=0; k<2*i+1; k++){
            cout<<"* ";
        }
        cout<<endl;
    }


    for(int i=0; i<n; ++i){
        for(int j=0; j<i; ++j)
        {
            cout<<"  ";
        }
        for(int k=0; k<2*(n-i)-1; k++)
        {
            cout<<"* ";
        }
        cout<<endl;
    }
}

void nStarDiamond(int n)
{
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            if(j<n-i-1)
            {
                cout<<" ";
            }
        }
        for(int k=0; k<2*i+1; k++)
        {
            cout<<"*";
        }
        cout<<endl;
    }

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            if(i>j)
            {
                cout<<" ";
            }
        }
        for(int k=0; k<2*(n-i-1)+1; k++)
        {
            cout<<"*";
        }
        cout<<endl;
    }
}

int main()
{
    int Num;
    cout<<"Num : ";
    cin>>Num;
    // printPattern(Num);
    nStarDiamond(Num);
}