/*

4444444
4333334
4322234
4321234
4322234
4333334
4444444

n=4
*/

#include <iostream>
using namespace std;

void printPattern(int n)
{
     int size = 2 * n - 1;

    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j) {
            int top = i;
            int left = j;
            int right = size - 1 -j;
            int bottom = size - 1 -i;
            int min_dist = min(min(top, bottom), min(right, left));
            cout << n - min_dist;
        }
        cout << endl;
    }

}

int main()
{
    int Num;
    cout<<"Num : ";
    cin>>Num;
    printPattern(Num);
}