/*

1             1
1 2         2 1
1 2 3     3 2 1
1 2 3 4 4 3 2 1

*/

#include <iostream>
using namespace std;

void printPattern(int n)
{
    for(int i=0; i<n; i++){
        int val;
        for(int j=0; j<(2*n)+1; j++)
        {
            if(j<=i)
            {
                val=j+1;
                cout<<val<<" ";
            }
            else if(j>=2*n-i){
                cout<<val<<" ";
                val-=1;
            }
            else{
                cout<<"  ";
            }

        }
        cout<<endl;
    }
    

}

int main()
{
    int Num;
    cout<<"Num : ";
    cin>>Num;
    printPattern(Num);
}