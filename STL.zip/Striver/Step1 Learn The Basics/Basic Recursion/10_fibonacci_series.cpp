#include <iostream>
using namespace std;

void getFibonacciSeries(int num)
{

    int first = 0;
    int second = 1;
    int res;
    if(num<=0)
    {
        cout<<-1<<endl;
        return;
    }
    else if(num<=2)
    {
        for(int i=0; i<num; i++)
        {
            cout<<i<<" ";
        }
    }
    else
    {
        cout<<first<<" "<<second<<" ";
        for(int i=2; i<num; i++)
        {  
            res = second + first;
            cout<<res<<" ";
            first = second;
            second = res;
        }
    }
    cout<<endl;
}

int getNthFibonacciNumber(int num)
{
    if(num<1)
    {
        return -1;
    }
    else if(num==1 || num==2)
    {
        return num-1;
    }
    else
    {
        int first = 0;
        int second = 1;
        int res;
        for(int i=2; i<num; i++)
        {
            res = first + second;
            first = second;
            second = res;
        }
        return res;
    }
    return -1;
}

int getFibonacciRecursion(int num)
{
    if(num<=0)
    {
        return -1;
    }
    else if(num<=2)
    {
        return num-1;
    }
    else
    {
        return getFibonacciRecursion(num - 1) + getFibonacciRecursion(num -2);
    }

}

int main()
{
    int num;
    cout<<"Enter the number: ";
    cin>>num;
    cout<<"Fibonacci Series : ";
    getFibonacciSeries(num);
    cout<<num<<"th Fibonacci Number : "<<getNthFibonacciNumber(num)<<endl;
    cout<<num<<"th using recursion :  "<<getFibonacciRecursion(num)<<endl;
    return 0;
}