#include <iostream>
#include <string>
#include <algorithm>
using namespace std;



int main()
{
    // string  s = "Hello World:01_S9sd@";
    string s= "Marge, let's \"[went].\"}I await {news} telegram.";
    cout<<"s : "<<s<<endl;
    string lowerCase, upperCase, result;
    for(auto c : s)
    {   
        lowerCase += tolower(c);
        upperCase += toupper(c);
    }

    cout<<"Lower : "<<lowerCase<<endl;
    cout<<"Upper : "<<upperCase<<endl;

    for(auto c : lowerCase)
    {
        if(!isalnum(c))
        {
            cout<<"c : "<<c<<endl;
            lowerCase.erase(remove(lowerCase.begin(), lowerCase.end(), c), lowerCase.end());
        }
    }

    for (char c : s) 
    { 
        if (std::isalnum(c)) 
        {
            result += std::tolower(c); 
        }
    }

    cout<<"Modified Lower : "<<lowerCase<<endl;
    cout<<"Result : "<<result<<endl;

    return 0;
}