#include <iostream>
using namespace std;

void print_N_to_1(int start, int num)
{
  if(start>num)
  {
    return;
  }
  cout<<num<<endl;
  print_N_to_1(start, num-1);
  //cout<<num<<endl;
}



int main()
{
    int num;
    cout<<"enter num: ";
    cin>>num;
    int i=0;
    print_N_to_1(i, num);
    return 0;
}