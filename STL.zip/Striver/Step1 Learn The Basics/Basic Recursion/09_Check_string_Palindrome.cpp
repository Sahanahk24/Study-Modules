#include <iostream>
using namespace std;

bool checkPalindrome(string s)
{
    string val = s;
    string res = "";
    for(int i=s.length()-1; i>=0; i--)
    {
        res += s[i];
    }

    if(res==val)
    {
        return true;
    }
    return false;
}   

void checkPalindrome_UsingRecursion(string& s, int start, int end)
{
    if(start>=end)
    {
        // cout<<s<<endl;
        return;
    }
    swap(s[start], s[end]);
    return checkPalindrome_UsingRecursion(s, start+1, end-1);
}  

bool checkPalindrome_Recursion_bool(string& s, int start, int end)
{
    if(s[start] != s[end])
    {
        // cout<<s<<endl;
        return false;
    }
    if(start>=end)
    {
        return true;
    }
    return checkPalindrome_Recursion_bool(s, start+1, end-1);
}  

int main()
{
    string s = "GodrrdoGa";
    string val = s;
    if(checkPalindrome(s)){
        cout<<s<<" is Palindrome\n";
    }
    else{
        cout<<s<<" is Not Palindrome\n";
    }
    cout<<endl;
    checkPalindrome_UsingRecursion(s, 0, s.size()-1);
    cout<<s<<endl;

    if(val == s)
    {
        cout<<"YES\n";
    }
    else{
        cout<<"NO\n";
    }

    cout<<endl;

    if(checkPalindrome_Recursion_bool(s, 0, s.size()-1))
    {
        cout<<"It is\n";
    }
    else
    {
        cout<<"It is Not\n";
    }
    return 0;
}