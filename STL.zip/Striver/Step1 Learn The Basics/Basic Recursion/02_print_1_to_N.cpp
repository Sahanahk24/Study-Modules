#include <iostream>
using namespace std;

void print_1_to_N(int start, int num)
{
  if(start>num)
  {
    return;
  }
  cout<<start<<endl;
  return print_1_to_N(start+1, num);
}



int main()
{
    int num;
    cout<<"enter num: ";
    cin>>num;
    int i=1;
    print_1_to_N(i, num);
    return 0;
}