#include <iostream>
using namespace std;

void print_N_to_1(int start, int end)
{
    if(start>end)
    {
        return;
    }
    print_N_to_1(start+1, end);
    cout<<start<<endl;
}

int main()
{
    int num;
    cout<<"Enter the number : ";
    cin>>num;
    int i=0;
    print_N_to_1(i, num);
    return 0;
}