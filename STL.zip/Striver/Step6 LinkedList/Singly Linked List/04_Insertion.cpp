#include <iostream>
#include <vector>
using namespace std;

class Node
{
    public:
        int data;
        Node* next;

        Node(int data)
        {
            this->data = data;
            this->next = nullptr;
        }
};

int lengthOfLL(Node* head)
{
    Node* temp = head;
    int cnt=0;
    while(temp)
    {
        temp = temp->next;
        cnt++;
    }
    return cnt;
}

Node* convertArrayIntoLL(vector<int> arr)
{
    Node* head = new Node(arr[0]);
    Node* curr = head;
    for(int i=1; i<arr.size(); i++)
    {
        Node* NextNode = new Node(arr[i]);
        curr->next = NextNode;
        curr = NextNode;
    }
    return head;
}

void traverseLinkedListElements(Node* head)
{
    Node* curr = head;
    while(curr != nullptr)
    {   
        cout<<curr->data<<" ";
        curr = curr->next;
    }
    cout<<endl;
}

int SearchInLL(Node* head, int k)
{
    Node* temp = head;
    while(temp)
    {
        if(temp->data  == k)
        {
            return 1;
        }
        temp = temp->next;
    }
    return -1;
}

Node* insertAtHead(Node* head, int k)
{
    Node* newNode = new Node(k);

    if(head == nullptr)
    {
        return newNode;
    }
    newNode->next = head;
    return newNode;
}

Node* insertAtTail(Node* head, int k)
{
    Node* newNode = new Node(k);
    Node* temp = head;
    while(temp->next != nullptr)
    {
        temp=temp->next;
    }
    temp->next = newNode;
    return head;
}

Node* insertAtPosition(Node* head, int pos, int k)
{
    Node* newNode = new Node(k);
    if(head == nullptr)
    {
        if(pos==1)
        {
            return newNode;
        }
        return nullptr;
    }
    if(pos==1)
    {
        newNode->next = head;
        return newNode;
    }

    int cnt=0;
    Node* prev = nullptr;
    Node* curr = head;
    while(curr)
    {
        cnt++;
        if(cnt==pos-1)
        {
            newNode->next = curr->next;
            curr->next = newNode;
        }
        curr = curr->next;
    }
    return head;
}

Node* insertBeforeElement(Node* head, int ele, int k)
{
    Node* newNode = new Node(k);
    if(head == nullptr)
    {
        return head;
    }
    if(head->data == ele)
    {
        newNode->next = head;
        return newNode;
    }

    Node* curr = head;
    Node* prev = nullptr;
    while(curr)
    {
        if(curr->data == ele)
        {
            prev->next = newNode;
            newNode->next = curr;
            break;
        }
        prev = curr;
        curr = curr->next;
    }
    return head;
}

Node* insertAfterElement(Node* head, int ele, int k)
{
    Node* newNode = new Node(k);
    if(head == nullptr)
    {
        return head;
    }
    // if(head->data == ele)
    // {
    //     head->next = newNode;
    //     return head;
    // }

    Node* curr = head;
    while(curr)
    {
        if(curr->data == ele)
        {
            newNode->next = curr->next;
            curr->next = newNode;
            break;
        }
        curr = curr->next;
    }
    return head;
}


int main()
{
    Node* head = new Node(100);
    Node* curr = head;

    for(int i=1; i<=10; i++)
    {   
        // int n;
        // cout<<"Enter num "<<i<<" : ";
        // cin>>n;
        Node* nextNode = new Node(i);
        curr->next = nextNode;
        curr = nextNode;
    } 

    traverseLinkedListElements(head);
    cout<<"Length : "<<lengthOfLL(head)<<endl;

    cout<<endl;
    cout<<"Convert Array to Linked List"<<endl;
    vector<int> arr = {10,20,30,40,50,60,70,80,90};
    Node* head2 = convertArrayIntoLL(arr);
    traverseLinkedListElements(head2);
    cout<<"Length : "<<lengthOfLL(head2)<<endl;
    int k = 20;
    cout<<"Element "<<k<<" found : "<<SearchInLL(head2, k)<<endl;

    // cout<<endl;
    // vector<int> arr1 = {30, 20, 10};
    // Node* h2 = convertArrayIntoLL(arr1);
    // traverseLinkedListElements(h2);

    traverseLinkedListElements(head2);
    Node* head3 = insertAtHead(head2, 999);
    traverseLinkedListElements(head3);
    
    cout<<endl;
    Node* head4 = insertAtTail(head3, 1000);
    traverseLinkedListElements(head4);
    
    cout<<endl;
    Node* head5 = insertAtPosition(head4, 1, 123);
    traverseLinkedListElements(head5);

    cout<<endl;
    Node* head6  = insertBeforeElement(head5, 1000, 55);
    traverseLinkedListElements(head6);

    cout<<endl;
    Node* head7 = insertAfterElement(head6, 123, 6);
    traverseLinkedListElements(head7);
   
}