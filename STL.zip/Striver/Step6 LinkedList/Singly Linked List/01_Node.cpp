#include <iostream>
#include <vector>

using namespace std;

class Node
{
    public:
        int data;
        Node* next;

        Node(int data1, Node* next1)
        {
            this->data = data1;
            this->next= next1;
        }

        Node(int data1)
        {
            this->data = data1;
            this->next = nullptr;
        }

};


int main()
{
    Node x = Node(2,nullptr);
    cout<<x.data<<endl;
    cout<<x.next<<endl;

    Node* y = &x;
    cout<<y->data<<endl;
    cout<<y->next<<endl;

    //Best way
    Node* a = new Node(2,nullptr); //gives pointer to the memory location of Node with 2
    Node* b = new Node(3);

    cout<<a->data<<" "<<a->next<<endl;
    cout<<b->data<<" "<<b->next<<endl;

    return 0;
}