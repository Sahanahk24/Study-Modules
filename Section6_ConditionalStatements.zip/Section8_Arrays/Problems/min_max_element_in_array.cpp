#include <iostream>
#include <math.h>
#include <bits/stdc++.h>
using namespace std;



int main()
{
    int arr[] = {12, 1023, 2, 0, 4, -3, 55, 34, -780};
    for(auto s: arr)
    {
        cout<<s<<" ";
    }
    cout<<endl;

    int min = INT_MAX;
    int max = INT_MIN;
    int size = sizeof(arr)/sizeof(arr[0]);

    for(int i=0; i<size; i++)
    {
        if(arr[i]<=min)
        {
            min = arr[i];
        }
        if(arr[i]>=max)
        {
            max = arr[i];
        }
    }
    cout<<"Min : "<<min<<endl;
    cout<<"Max : "<<max<<endl;
    cout<<"After Swapping Min and Max Elements in Array\n";
    for(auto x: arr)
    {
        if(x==min)
        {
            cout<<max<<" ";
        }
        else if(x==max)
        {
            cout<<min<<" ";
        }
        else
        {
            cout<<x<<" ";
        }
    }
   
    return 0;
}