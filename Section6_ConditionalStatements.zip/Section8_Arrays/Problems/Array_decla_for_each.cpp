#include <iostream>
using namespace std;

int main(){



//For-Each loop can be used to access elements in an array without knowing the size of array 
// we can initialize array elements and need not define size of array 

    int A[] = {2,3,6,8,10};
        for(int x:A){
            cout<<x<<endl;
        }
    cout<<endl;

    
 
// here in for each loop since we are using int type to print the float
// values, it will truncate the value and give only int value
    float B[] = {2.3f, 6.9f, 5, 99};
     for(int x:B){
            cout<<x<<endl;
        }

    cout<<endl;

        float C[] = {2.3f, 6.9f, 5, 99};
     for(float x:C){
            cout<<x<<endl;
        }

    cout << endl;

    //Char example -1 

    char D[] = {'A',66,'C',68};

    for(char x:D){
        cout<<x<<endl;
    } 

    cout << endl;

     for(int x:D){
        cout<<x<<endl;
    }

    cout << endl;
// Auto in for-each loop :-> automatically determine the type of Array
// and print the array elements

    float E[] = {1.2, 3.6, 23, 67, 'A'};
    for(auto a:E){
        cout<<a<<endl;
    }
    cout<<endl;

    int G[6] = {1,2};
    for(float x:G){
        cout<<x<<endl;
    }
    cout<<endl;


    int arr[5] = {1,2};
    int s = sizeof(arr)/sizeof(arr[0]);
    cout<<"size : "<<s<<endl;
    for(auto x : arr)
    {
        cout<<x<<" ";
    }
    cout<<endl;

}