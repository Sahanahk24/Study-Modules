#include <iostream>
#include <climits> //for INT_MIN and INT_MAX
using namespace std;

int main(){
    int n, max=INT_MIN, min=INT_MAX;
    cout<<"Get Max and Min from an Array \n";
    cout<<"Enter the size of Array: ";
    cin>>n;
    int A[n];
    for(int i=0; i<n; ++i){
        cin>>A[i];
    }
    cout<<endl;
    cout<<"Array elememts are : ";
    for(int i=0; i<n; ++i){
        cout<<A[i]<<" ";
    }
    cout<<endl;
    int size = sizeof(A)/sizeof(A[0]);
    for(int i=0; i< size ; ++i)
    {
        if(A[i]>=max){
            max=A[i];
        }
        if(A[i]<=min){
            min=A[i];
        }
    }
    cout<<"Max element is : "<<max<<endl;
    cout<<"Min element is : "<<min<<endl;


}