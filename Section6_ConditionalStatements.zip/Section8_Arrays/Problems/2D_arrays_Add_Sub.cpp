#include <iostream>
using namespace std;
//This program is of Multiplication----> change it for addition
typedef int rows;
typedef int cols;

int main(){
    rows r1,r2;
    cols c1,c2;
    int A[10][10], B[10][10], C[10][10];
    cout<<"Enter the rows and cols of Matrix A: ";
    cin>>r1>>c1;
    cout<<"Enter the rows and cols of Matrix B: ";
    cin>>r2>>c2;
    if(c1!=r2){
        cout<<"Cant be Multiplied\n size of column of A matrix must be same as size of row of B matrix";
        return -1;
    }    
    cout<<"Enter the elements of A Matrix: \n";
    for(int i=0; i<r1; i++){
        for(int j=0; j<c1; j++){
            cout<<"enter element a"<<i+1<<j+1<<" : ";
            cin>>A[i][j];
        }
    }
    cout<<endl;
    cout<<"Enter the elements of B Matrix: \n";
    for(int i=0; i<r2; i++){
        for(int j=0; j<c2; j++){
            cout<<"enter element a"<<i+1<<j+1<<" : ";
            cin>>B[i][j];
        }
    }
    cout<<endl;
    cout<<"Ouput Matrix C: \n";
    for(int i=0; i<r1; i++){
        for(int j=0; j<c2; j++){
            C[i][j]=0;
            for(int k=0; k<c1; k++){
                C[i][j] += A[i][k]*B[k][j];
        }
    
    }
    for(int i=0; i<r1; i++){
        for(int j=0; j<c2; j++){
            cout<<C[i][j]<<" ";
        }
        cout<<endl;
    }

}