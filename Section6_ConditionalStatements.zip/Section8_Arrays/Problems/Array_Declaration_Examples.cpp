#include <iostream>
using namespace std;

int main(){

    //printing array element without initialization will 
    //print garbage values

    int A[5];
    for(int i=0; i<5; i++){
        cout<<A[i]<<endl;
    }

//#########################################

    //declaring , initialzing and print array elements
    cout<<endl;
    int B[5] = {2,4,5,7,1};

    for(int i=0; i<5; i++){
         cout<<B[i]<<endl;
     }

//#########################################
    cout<<endl;
    int c[5] = {3,5};
    for(int i=0 ; i<5 ; i++){
        cout<<c[i]<<endl;
    }


//#########################################
    cout<<endl;
    int d[5] = {0};
    for(int i=0 ; i<5 ; i++){
        cout<<d[i]<<endl;
    }

//#########################################

      //int E[3] = {1,2,3,4}; // Error - Excess elements in an array initializer

//#########################################





}