#include <iostream>
using namespace std;

int main()
{
    cout << "Matrices Operations\n";
    int row1, row2, col1, col2;
    cout << "Enter the row1 of A matrix: ";
    cin >> row1;
    cout << "Enter the col1 of A matrix: ";
    cin >> col1;
    cout << "Enter the row2 of B matrix: ";
    cin >> row2;
    cout << "Enter the col2 of B matrix: ";
    cin >> col2;
    if (row1 > 0 && row2 > 0 && col1 > 0 && col2 > 0)
    {
        if (row1 != row2 || col1 != col2)
        {
            cout << "Invalid Matrix size : col1 should be same as row2" << endl;
            return 0;
        }
    }
    int A[row1][col1];
    int B[row2][col2];
    int C[row1][col1];
    cout << "Enter the elements of Matrix A : " << endl;
    for (int i = 0; i < row1; i++)
    {
        for (int j = 0; j < col1; j++)
        {
            cin >> A[i][j];
        }
    }
    cout << "Print Matrix A: " << endl;
    for (int i = 0; i < row1; i++)
    {
        for (int j = 0; j < col1; j++)
        {
            cout << A[i][j] << " ";
        }
        cout << endl;
    }
    cout << "Enter the elements of Matrix B : " << endl;
    for (int i = 0; i < row1; i++)
    {
        for (int j = 0; j < col1; j++)
        {
            cin >> B[i][j];
        }
    }
    cout << "Print Matrix B: " << endl;
    for (int i = 0; i < row1; i++)
    {
        for (int j = 0; j < col1; j++)
        {
            cout << B[i][j] << " ";
        }
        cout << endl;
    }
    int option;
    cout << "Enter the type of Operation: \n1. Add\n2. Sub\n";
    cin >> option;
    switch (option)
    {
    case 1:
        cout << "Addition: \n";
        for (int i = 0; i < row1; i++)
        {
            for (int j = 0; j < col1; j++)
            {
                C[i][j] = A[i][j] + B[i][j];
            }
        }
        cout << "printing result of Matrix C : \n";
        for (int i = 0; i < row1; i++)
        {
            for (int j = 0; j < col1; j++)
            {
                cout << C[i][j] << " ";
            }
            cout << endl;
        }

        break;
    case 2:
        cout << "Subtraction: \n";
        for (int i = 0; i < row1; i++)
        {
            for (int j = 0; j < col1; j++)
            {
                C[i][j] = A[i][j] - B[i][j];
            }
        }
        cout << "printing result of Matrix C : \n";
        for (int i = 0; i < row1; i++)
        {
            for (int j = 0; j < col1; j++)
            {
                cout << C[i][j] << " ";
            }
            cout << endl;
        }
        break;
    default:
        cout << "Invalid Operation\n";
    }
}