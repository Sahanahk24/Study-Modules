#include <iostream>
using namespace std;


int main()
{
    cout<<"Set Zero's\n";
    int A[3][4] = {{0,1,2,0},{4,1,3,1},{9,1,9,1}};
    
    // cout<<sizeof(A)<<endl;
    // cout<<sizeof(A[0])<<endl;
    // cout<<sizeof(A[0][0])<<endl;

    int r = sizeof(A)/sizeof(A[0]);  //size of row =  Matrix/row
    int c = sizeof(A[0])/sizeof(A[0][0]); //size of col = row/col

    cout<<"row : "<<r<<" col : "<<c<<endl;

    cout<<"\nOriginal: \n";
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            cout<<A[i][j]<<" ";
        }
        cout<<endl;
    }   

    
    int X[r],Y[c];

    int m=0;
    int n=0;
    int i=0; 
    int count=0;

    while(i<r)
    {
        int j=0;
        while(j<c)
        {
            if(i<r && A[i][j]==0)
            {
                X[m] = i;
                Y[n] = j;
                m++;
                n++;
                count++;
            }
            j++;
        }
        i++;
    }

    // cout<<"X : ";
    // for(int z=0; z<m; z++){
    //     cout<<X[z]<<" ";
    // }
    // cout<<"\nY : ";
    // for(int z=0; z<n; z++){
    //     cout<<Y[z]<<" ";
    // }

    for(int k=0; k<count; k++){
        for(int i=0; i<r; i++){
            for(int j=0; j<c; j++){
                if(i==X[k] || j==Y[k]){
                    A[i][j]=0;
                }
            }
        }
    }
    

    cout<<"\nZERO\n";

    for(auto& row:A){
        for(auto& c:row){
            cout<<c<<" ";
        }
        cout<<endl;
    }
}