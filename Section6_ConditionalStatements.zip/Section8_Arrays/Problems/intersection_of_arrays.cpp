#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;



int main()
{
    int arr1[] = {2,1, 3, 5, 7, 8};
    int arr2[] = {2, 3, 4, 1, 4};
    vector<int> v;
    vector<int> u;
    set<int> s;
    for(auto x: arr1)
    {
        for(auto y:arr2)
        {
            if(x==y)
            {
                v.push_back(x);  
            }
            s.insert(y);
        }
        s.insert(x);
    }
    for(auto x: v)
    {
        cout<<x<<" ";
    }
    cout<<endl;
    for(auto x: s)
    {
        cout<<x<<" ";
    }
    cout<<endl<<endl;
    sort(v.begin(), v.end());

    for(auto y:v)
    {
        s.erase(y); 
    }
    for(auto x: s)
    {
        cout<<x<<" ";
    }
    cout<<endl;

    return 0;
}