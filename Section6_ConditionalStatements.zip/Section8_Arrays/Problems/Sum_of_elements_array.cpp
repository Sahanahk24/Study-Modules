#include <iostream>
#include <vector>
using namespace std;

int main(){
    int n,sum=0;
    cout<<"Sum of elements in an Array \n";
    cout<<"Enter the Size of Array: ";
    cin>>n;
    
    int A[n]; 
    for(int i=0; i < n; i++){
        cin>>A[i];
    }
    cout <<"Array is : ";
    for(auto x:A){
        cout<<x<<" ";
    }
    cout<<endl;
    int sizeOfArray = sizeof(A)/sizeof(A[0]);
    cout<<"Size of array is : "<<sizeOfArray;
    cout<<endl;
    
    for(int i=0; i<n; i++){
        sum += A[i];
    }
    cout<<"Sum of all Array elements is : "<<sum;

    int prod = 1;
    for(int i=0; i<n; i++){
        prod *= A[i];
    }
    cout<<"\nProduct of all Array elements is : "<<prod;
}