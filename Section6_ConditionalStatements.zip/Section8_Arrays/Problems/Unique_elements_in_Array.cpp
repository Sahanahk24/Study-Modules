#include <iostream>
#include <unordered_map>
using namespace std;



int main()
{
    int arr[] = {1,2,1,1,2,3,4,8,5};
    int size = sizeof(arr)/sizeof(arr[0]);
    cout<<"Unique Elements in Array Using for nested for loops\n";
    for(int i=0; i<size; i++)
    {
        int cont=0;
        for(int j=1; j<size; j++)
        {
            if(arr[i]==arr[j])
            {
                cont+=1;
            }
        }
        if(cont==1)
        {
            cout<<arr[i]<<" ";
        }
    }
    cout<<endl;
    unordered_map<int,int> map;
    cout<<"Unique Elements in Array Using Hash Map\n";
    for(auto x : arr)
    {
        map[x]++;
    }
    for(auto x: map)
    {
        if(map[x.first] == 1)
        {
            cout<<x.first<<endl;
        }
    }

    return 0;
}