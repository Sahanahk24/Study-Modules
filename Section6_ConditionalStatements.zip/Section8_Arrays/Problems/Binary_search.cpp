#include <iostream>
using namespace std;

int main(){
    int n, key, mid, high, low;
    cout<<"Binary Search \n";
    cout<<"Enter the size of Array: ";
    cin>>n;
    int A[n];
    for(int i=0; i<n; ++i){
        cin>>A[i];
    }
    cout<<"Enter the key: ";
    cin>>key;
    low = 0;
    high = sizeof(A)/sizeof(A[0])-1;
    while(low<=high){
            mid = (low+high)/2;
            if(key==A[mid]){
                cout<<key<<" found at index :"<<mid;
                return 0;
            }
            else if(key>A[mid]){
                low = mid+1;
            }
            else{
                high = mid-1;
            }
    }
    cout<<key<<" not found"<<endl;
    return 0;
}