#include <iostream>
using namespace std;

int main(){


//Refer notes for explanation
//For-Each loop can be used to access elements in an array without knowing the size of array 
// we can initialize array elements and need not define size of array 

    int A[] = {2,3,6,8,10};
        for(int x:A){
            cout<<x<<endl;
        }
    cout<<endl;

    int Aa[] = {2,3,6,8,10};
        for(int x:Aa){
            cout<<++x<<endl;
        }
    cout<<endl;

    for(int x:Aa){
            cout<<x<<endl;
        }
    cout<<endl;

    for(int &x:Aa){
            cout<<++x<<endl;
        }
    cout<<endl;

    for(int x:Aa){
            cout<<x<<endl;
        }
    cout<<endl;

}