#include <iostream>
using namespace std;

int main(){
    int n,key;

    cout <<"Linear Search\n";
    cout<<"Enter the size of Array: ";
    cin>>n;
    int A[n];
    for(int i=0; i<n; ++i){
        cin>>A[i];
    }
    cout<<endl;
    cout<<"Array elememts are : ";
    for(int i=0; i<n; ++i){
        cout<<A[i]<<" ";
    }
    cout<<"\nEnter the Key to search : ";
    cin>>key;
    cout<<endl;
    for(int i=0; i<n; i++){
        if(key==A[i]){
            cout<<"Element found at index : "<<i<<endl;
            return 0;
        }
    }
    cout<<"Element not found "<<endl;
    return 0;
}