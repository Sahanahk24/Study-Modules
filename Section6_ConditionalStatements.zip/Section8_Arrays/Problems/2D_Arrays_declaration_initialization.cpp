#include <iostream>
using namespace std;

int main(){
    int A[2][3] = {{2,3,5},{10,12,7}};
    int B[2][3] = {2,3,5,10,12,7};
    int C[2][3] = {{2,3},{5}};
//Using nested For Loop
    cout<<"Printing array A: "<<endl;
    for(int i = 0; i<2; i++){
        for(int j=0; j<3; j++){
            cout<<A[i][j]<<" ";
        }
        cout<<endl;
    }

    cout<<endl;
//Using nested for Each Loop
    cout<<"Printing array B: "<<endl;
    for(auto& row:B){
        for(auto& col:row){
            cout<<col<<" ";
        }
        cout<<endl;
    }

    cout<<endl;

    cout<<"Printing array C: "<<endl;
    for(int i = 0; i<2; i++){
        for(int j=0; j<3; j++){
            cout<<C[i][j]<<" ";
        }
        cout<<endl;
    }

    cout<<endl;
}
