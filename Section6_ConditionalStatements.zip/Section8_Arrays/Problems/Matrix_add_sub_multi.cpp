#include <iostream>
using namespace std;

typedef int rows;
typedef int cols;

int main(){
    cout<<"Matrix operations \n";
    rows r1,r2;
    cols c1,c2;
    cout<<"Enter row and col for Matrix A \n";
    cout<<"r1 : ";
    cin>>r1;
    cout<<"c1 : ";
    cin>>c1;
    cout<<"Enter row and col for Matrix B \n";
    cout<<"r2 : ";
    cin>>r2;
    cout<<"c2 : ";
    cin>>c2;
    bool isDiagonal = false;
    int A[r1][c1], B[r2][c2], C[10][10];
    for(int i=0; i<r1; i++){
        for(int j=0; j<c1; j++){
            cout<<"\nA["<<i<<"]["<<j<<"] : ";
            cin>>A[i][j];
        }
    }
    cout<<"Matrix A is given below \n";
    for(auto& row:A){
        for(auto& col:row){
            cout<<col<<" ";
        }
        cout<<endl;
    }
    // int count=0;
    // for(int i=0; i<r1; i++){
    //     for(int j=0; j<c1; j++){
    //         if(i!=j){
    //             if(A[i][j]==0){
    //                 count++;
    //             }
    //         }
    //     }
    // }

    // if(count==(r1*(r1-1))){
    //     cout<<"IS DIAGONALLLLL\n";
    // }

    for(int i=0; i<r2; i++){
        for(int j=0; j<c2; j++){
            cout<<"\nB["<<i<<"]["<<j<<"] : ";
            cin>>B[i][j];
        }
    }
    cout<<"Matrix B is given below \n";
    for(auto& row:B){
        for(auto& col:row){
            cout<<col<<" ";
        }
        cout<<endl;
    }
    int Opt;
    cout<<"Choose Operation to perform on these Matrix : \n";
    cout<<"1. Addition\t\t2. Subtraction\t\t3. Multiplication\n";
    cin>>Opt;
    switch(Opt){
        case 1:
        cout<<"Addition of Matrix A and B : \n";
        if(r1==r2 && c1==c2){
            for(int i=0; i<r1; i++){
                for(int j=0; j<c1; j++){
                    C[i][j] = A[i][j] + B [i][j];
                    cout<<C[i][j]<<" ";
                }
                cout<<endl;
            }
        }
        else{
            cout<<"Addition cannot be performed. Make sure size of rows and cols is equal for both the matrices\n";
        }
        break;
        case 2:
        cout<<"Subtraction of Matrix A and B : \n";
        if(r1==r2 && c1==c2){
            for(int i=0; i<r1; i++){
                for(int j=0; j<c1; j++){
                    C[i][j] = A[i][j] - B [i][j];
                    cout<<C[i][j]<<" ";
                }
                cout<<endl;
            }
        }
        else{
            cout<<"Subtraction cannot be performed. Make sure size of rows and cols is equal for both the matrices\n";
        }
        break;
        case 3:
        cout<<"Multiplication of Matrix A and B : \n";
        if(c1==r2){
            for(int i=0; i<r1; i++){
                for(int j=0; j<c2; j++){
                    C[i][j]=0;
                    for(int k=0; k<c1; k++){
                        C[i][j] += A[i][k]*B[k][j];
                    }
                    cout<<C[i][j]<<" ";
                }
                cout<<endl;
            }
        }
        else
        {
            cout<<"Matrix Multiplication Not allowed. Please make sure the size of rows in Matrix A is same as size of columns in Matrix B\n";
        }
        break;
        default:
        cout<<"Invalide Choice!!!";
    }

    
}