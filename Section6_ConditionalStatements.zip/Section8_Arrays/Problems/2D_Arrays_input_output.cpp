#include <iostream>
using namespace std;

int main(){
    int row,col;
    cout<<"Enter the row(x) : ";
    cin>>row;
    cout<<"Enter the col(y) : ";
    cin>>col;
    cout<<"Enter Elements for A : ";
    int A[row][col];
    int B[row][col];
//Using for loop
    for(int i=0; i<row;i++){
        for(int j=0;j<col;j++){
            cin>>A[i][j];
        }
    }

    // cout<<"Printing 2D array - A : "<<endl;
    // for(int i=0; i<row;i++){
    //     for(int j=0;j<col;j++){
    //         cout<<A[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }
 cout<<"Printing 2D array - A: "<<endl;
    for(auto& row:A){
        for(auto& col:row){
            cout<<col<<" ";
        }
        cout<<endl;
    }

//Using for each loop
    cout<<"Enter Elements for B : ";
    for(auto& row:B){
        for(auto& col:row){
            cin>>col;
        }
    }

    cout<<"Printing 2D array - B : "<<endl;
    for(auto& row:B){
        for(auto& col:row){
            cout<<col<<" ";
        }
        cout<<endl;
    }

}