#include <iostream>
#include <string>
#include <typeinfo>

using namespace std;


int main(){
    string mail;
    string::iterator it;
    cout<<"Enter email address: ";
    getline(cin,mail);
    int count=0;
    cout<<"mail : "<<mail<<endl;
    int x = mail.find('@');
    cout<<"type of x : "<<typeid(x).name()<<"   size of x :"<<sizeof(x)<<endl;
    cout<<"@ : "<<x<<endl;
    cout<<"User Name : "<<mail.substr(0,mail.find('@'))<<endl;
    cout<<"Domain : "<<mail.substr(13)<<endl;
}

