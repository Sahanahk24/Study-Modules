#include <iostream>
using namespace std;

int main(){
    char s1[50],s2[50],s3[50],s4[50];
    cout<<"Enter name : ";
    cin>>s1;
    cout<<"welcome "<<s1<<endl;
    cout<<"Here only 1 word will be read in this method --> cin>>s1"<<endl<<endl;
    cin.ignore();
    cout<<"Enter your name : ";
    cin.getline(s2,50);
    cout<<"welcome "<<s2<<endl<<endl;
    cout<<"Enter your name Again : ";
    cin.get(s3,50);
    cout<<"Welcome : "<<s3<<endl<<endl;
    cin.ignore();
    cout<<"Enter your name Again2 : ";
    cin.get(s4,50);
    cout<<"Welcome : "<<s4<<endl<<endl;

    cout<<"We are using cin.ignore() to clear the stream(input buffer) before reading the next input string \nelse it will be considering the space(new line character)(enter key) as new input"<<endl;

}