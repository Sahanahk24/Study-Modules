#include <iostream>
#include <string>

using namespace std;

int main(){
    string s, rev;
    cout<<"Enter a String to check if its palindrome or not: ";
    getline(cin,s);
    cout<<"s : "<<s<<endl;
    int l = s.length();
    cout<<l<<endl;
    for(int i=l-1;i>=0;i--){
        cout<<s[i]<<" ";
        rev+=s[i];
    }
    cout<<endl;
    cout<<"rev : "<<rev<<endl;

    if(s.compare(rev)==0){
        cout<<"String : "<<s<<" is Palindrome."<<endl;
    }
    else{
        cout<<"String : "<<s<<" is Not Palindrome."<<endl;
    }

}