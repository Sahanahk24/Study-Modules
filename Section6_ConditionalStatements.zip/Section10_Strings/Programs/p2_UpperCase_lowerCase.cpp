#include <iostream>
#include <string>
using namespace std;

int main(){
    string s1,s2,s;
    string::iterator it;
    cout<<"Enter a lower_case string : ";
    getline(cin,s1);
    cout<<"s1 : "<<s1<<endl;
    for(int i=0; s1[i]!='\0'; i++){
        if(s1[i]>=97 && s1[i]<=122){
            s1[i] = s1[i] - 32;
        }
    }
    cout<<"UpperCase s1 : "<<s1<<endl<<endl;

    cout<<"Enter a upper_case string : ";
    getline(cin,s2);
    cout<<"s2 : "<<s2<<endl;
    for(it=s2.begin();it!=s2.end();it++){
        if(*it>=65 && *it<=90){
            *it = *it+32;
        }
    }
    cout<<"LowerCase s2 : "<<s2<<endl<<endl;

    cout<<"Enter a string to interchange the case of all char(s) in it : ";
    getline(cin,s);
    cout<<"s : "<<s<<endl;
    for(it=s.begin();it!=s.end();it++){
        if(*it>=65 && *it<=90){
            *it = *it+32;
        }
        else if(*it>=97 && *it<=122){
            *it = *it-32;
        }
    }
    cout<<"interChanged Cases of s : "<<s<<endl;


    // char ch = 122;
    // cout<<"ch : "<<ch<<endl;
}