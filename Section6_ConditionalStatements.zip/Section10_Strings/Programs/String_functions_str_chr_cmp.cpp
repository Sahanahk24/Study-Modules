#include <iostream>
#include<cstring>
//strstr, strchr, strrchr, strcmp

using namespace std;


int main(){
    char s1[50] = "Programming";
    char s2[20] = "rog";
    cout<<"s1 : "<<s1<<endl;
    cout<<"s2 : "<<s2<<endl;
    //strstr(mainStr,SubStr) - if the substring is found in mainStr then it will we retrun everything in the mainStr from that subStr
    if(strstr(s1,s2)!=NULL){
    cout<<"strstr(s1,s2) - "<<strstr(s1,s2)<<endl<<endl;
    }
    else{
        cout<<"subStr : "<<s2<<" Not found in mainStr : "<<s1<<endl;
    }

    cout<<"s1 : "<<s1<<endl;
    char ch = 'r';
    //strchr(mainStr,char) - if the 'char' is found in mainStr then it will we retrun everything in the mainStr from that 'char' based on the first occurence of that 'char'
    if(strchr(s1,ch)!=NULL){
    cout<<"strchr(s1,"<<ch<<") - "<<strchr(s1,ch)<<endl<<endl;
    }
    else{
        cout<<"char : "<<ch<<" Not found in mainStr : "<<s1<<endl;
    }

    cout<<"s1 : "<<s1<<endl;
    //strrchr(mainStr,char) - if the 'char' is found in mainStr then it will we retrun everything in the mainStr from that 'char' based on the last occurence of that 'char'
    if(strrchr(s1,ch)!=NULL){
    cout<<"strrchr(s1,"<<ch<<") - "<<strrchr(s1,ch)<<endl<<endl;
    }
    else{
        cout<<"char : "<<ch<<" Not found in mainStr : "<<s1<<endl;
    }

    //strcmp - Compares two strings and returns value in integer(-ve, 0, +ve)
    //Comparison is done based on Alphabetical order and if its same then 
    //based on its ASCII difference - 'h','H'

    char s3[50] = "bananz";
    char s4[50] = "banana";

    cout<<"s3 : "<<s3<<endl;
    cout<<"s4 : "<<s4<<endl<<endl;

    cout<<"strcmp(s3,s4) -  "<<strcmp(s3,s4)<<endl;
    cout<<"strcmp(s4,s3) -  "<<strcmp(s4,s3)<<endl<<endl;


}