#include <iostream>
using namespace std;

int main()
{
    cout << "Declaration and Initialization of String Using Array of Char" << endl;
    char a = 'A';
    cout << a << endl;
    char S1[6] = "Hello"; // One extra for null character at the end of String -'\0'
    cout << "S1 : " << S1 << endl;
    char S2[] = "Hello";
    cout << "S2 : " << S2 << endl;
    char S3[] = {'H', 'e', 'l', 'l', 'o'};
    cout << "S3 : " << S3 << endl;
    char S4[] = {'H', 'e', 'l', 'l', 'o','\0'};
    cout << "S4 : " << S4 << endl; 
    cout<<"Address of S4 : "<<&S4<<endl; //Address of S4
    for(int i=0;i<5;i++){
        cout<<"S4["<<i<<"] : "<<S4[i]<<endl;
    }
    cout<<endl;
    char S5[] = {'H', 'e', 'l', 'l', 'o',0};
    cout << "S5 : " << S5 << endl;
    char S6[] = {'H', 'e', 'l', 'l', 'o',0};
    cout << "S6 : " << (int)S6 << endl; //Gives int value of hexaDecimal (address)
    char S7[] = {65,66,67,68,0};
    cout<<"S7 : " << S7 << endl;
    for(char x:S5){
        cout<<(int)x<<" ";
    }
    cout<<endl;
    for(char x:S5){
        cout<<x<<" ";
    }
    cout<<endl;
}