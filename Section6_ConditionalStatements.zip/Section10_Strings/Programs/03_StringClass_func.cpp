#include <iostream>
#include <string>
using namespace std;
//s.replace(,,); s.erase(); s.push_back(); s.pop_back(); s1.swap(s2);

int main(){
    string s1 = "Programming is Fun!";
    cout<<"s1 : "<<s1<<endl;
    s1.replace(3,5,"zzz"); //Replaces the string with zzz from index 3  to next 5 characters
    cout<<"s1.replace(3,5,\"zzz\")"<<endl;
    cout<<"s1 : "<<s1<<endl<<endl;
    s1.erase();
    cout<<"s1.erase()"<<endl; //same as s.clear()
    cout<<"s1 : "<<s1<<endl<<endl;
    string s2 = "Hello";
    cout<<"s2 : "<<s2<<endl;
    s2.push_back('Q');
    cout<<"s2.push_back('Q')"<<endl; //appends a 'char' at the end of String
    cout<<"s2 : "<<s2<<endl<<endl;
    string s3 = "Chemistry";
    cout<<"s3 : "<<s3<<endl;

    s3.pop_back();
    cout<<"s3.pop_back()"<<endl; //removes the last char from string
    cout<<"s3 : "<<s3<<endl<<endl;

    string s4 = "AAA";
    string s5 = "BBB";
    cout<<"s4 : "<<s4<<"  "<<"s5 : "<<s5<<endl;
    s4.swap(s5);
    cout<<"s4.swap(s5)"<<endl; //swaps the contains between 2 strings
    cout<<"s4 : "<<s4<<"  "<<"s5 : "<<s5<<endl;



}