#include <iostream>
#include <string>
using namespace std;
//s.find(); s.rfind(); s.find_first_of(); s.find_last_of(); s.substr(start_index,num); s.at(); s.front(); s.back();

int main(){
    string s1 =  "yep! Lets do it. Keep Grinding saturne great";
    cout<<"s1 : "<<s1<<" --> "<<s1.length()<<endl;
    //s.find("str" or 'char') - returns the index of first occurance of it
    cout<<"s1.find(\"ee\")"<<endl;
    cout<<s1.find("ee")<<endl;
    cout<<"s1.find('s')"<<endl;
    cout<<s1.find('s')<<endl<<endl;

    //s.rfind("str" or 'char') - returns the index of last occurance of it
    cout<<"s1.rfind(\"ee\")"<<endl; 
    cout<<s1.rfind("ee")<<endl;
    cout<<"s1.rfind('s')"<<endl;
    cout<<s1.rfind('s')<<endl<<endl;

    //s.find_first_of('char' or "chars") - returns the index of first occurance of char(even if passed in "" it will consider to find the index of first occurance  of it and return its index)
    //s.find_first_of('char' or "chars", Number) - number to search after what index
    cout<<"s1.find_first_of(\"et\")"<<endl;
    cout<<s1.find_first_of("te")<<endl;
    cout<<"s1.find_first_of('e',4)"<<endl;
    cout<<s1.find_first_of('e',4)<<endl<<endl;  

    cout<<"s1.find_last_of('e')"<<endl;
    cout<<s1.find_last_of('e')<<endl;
    cout<<"s1.find_last_of('e',40)"<<endl;
    cout<<s1.find_last_of('e',40)<<endl<<endl;
      
    cout<<s1.substr(30)<<endl<<endl;


    cout<<"s1.at(14)"<<endl;
    cout<<s1.at(14)<<endl;
    s1.at(14) = 'z';
    cout<<"s1.at(14) = 'z'"<<endl;
    cout<<s1.at(14)<<endl<<endl;

    string s2 = "Good";
    string s3 = "Evening";
    string s4= s2+s3;
    cout<<"s4 = s2+s3"<<endl;
    cout<<"s4 : "<<s4<<endl<<endl;

    cout<<"s4.front()"<<endl;
    cout<<s4.front()<<endl;
    cout<<"s4.back()"<<endl;
    cout<<s4.back()<<endl;

    s4.front() = 'L';
    cout<<"s4.front() = 'L'"<<endl;
    cout<<"s4 : "<<s4<<endl;
}