#include <iostream>
#include <string>

using namespace std;

int main(){
    string s1,s2;
    string :: iterator it;
    cout<<"Enter String s1 : ";
    getline(cin,s1);
    cout<<"Enter string s2 : ";
    getline(cin,s2);
    cout<<"s1 : "<<s1<<endl;
    int f_count=0,i_count=0;
    for(int i=0;s1[i]!='\0';i++){
        f_count++;
    }
    cout<<"Length of s1 : "<<f_count<<endl<<endl;
    cout<<"s2 : "<<s2<<endl;
    for(it=s2.begin(); it!=s2.end();it++){
        i_count++;
    }
    cout<<"Length of s2 : "<<i_count<<endl<<endl;


}