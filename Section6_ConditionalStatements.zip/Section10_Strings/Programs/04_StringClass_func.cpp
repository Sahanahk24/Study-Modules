#include <iostream>
#include <string>
#include <cstring>
using namespace std;
//s.copy(char str[],number);  

int main(){
    string s1 = "Hello World!";
    cout<<"s1 : "<<s1<<" --> "<<s1.length()<<endl;
    char str[40],str2[40];
    s1.copy(str,s1.length()+1);
    str[s1.length()] = '\0'; //append null character at the end to avoid garabage value in result
    cout<<"s1.copy(str,s1.length())"<<endl;
    cout<<"str : "<<str<<" --> "<<strlen(str)<<endl<<endl;

    s1.copy(str2,5);
    str2[5] = '\0';
    cout<<"s1.copy(str2,5)"<<endl;
    cout<<"str2 : "<<str2<<" --> "<<strlen(str2)<<endl<<endl;

    string s2 = "Hello";
    string s3 = "hello";
    cout<<"s2 : "<<s2<<" | "<<"s3 : "<<s3<<endl;
    cout<<"s2.compare(s3)"<<endl;
    cout<<s2.compare(s3)<<endl;

}