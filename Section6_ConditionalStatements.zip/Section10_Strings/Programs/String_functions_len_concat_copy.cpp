#include <iostream>
#include <cstring>
#include <string.h>
using namespace std;
//strlen, strcpy, strncpy, strcat, strncat

int main(){
    char s1[20] = "Sufyan";
    // cout<<"Enter the String : ";
    // cin.getline(s1,20);
    cout<<"s1 : "<<s1<<endl;
    //Length of String - strlen(s)
    cout<<"strlen(s1) - Length of \""<<s1<<"\" : "<<strlen(s1)<<endl<<endl;

    char s2[50] = "Hello, How are you? ";
    cout<<"s2 : "<<s2<<endl;
    //Concat two strings -  strcat(destination,source)
    cout<<"strcat(s2,s1) - Concatinating two Strings : "<<strcat(s2,s1)<<endl<<endl;

    char s3[100] = "Programming is Fun ~ ";
    cout<<"s3 : "<<s3<<endl;
    //Concat two strings based on len of 2nd string-  strncat(destination,source,length)
    cout<<"strncat(s3,s1,n) - Concatinating two Strings based on len of 2nd string : "<<strncat(s3,s1,3)<<endl<<endl;
    
    char s4[20] = "Hello World!";
    char s5[70] = "okkkkkkkkkkkkkk";

    cout<<"s4 : "<<s4<<endl;
    cout<<"s5 : "<<s5<<endl;

    strcpy(s5,s4);
    //Copy the contains of one string to another - strcpy(destination,source)
    //If destination String has any characters then it will be replaced by source string
    cout<<"strcpy(s5,s4) - s5 : "<<s5<<endl<<endl;

    char s6[25] = "Good";
    cout<<"s6 : "<<s6<<endl;
    //Copy the contains of one string to another based on len - strncpy(destination,source,length)
    //characters in destination string will be replaced by source string of len specified, other characters will appear as it is 
    strncpy(s4,s6,3);
    cout<<"strncpy(s4,s6,3) - s4 : "<<s4<<endl<<endl;

}   