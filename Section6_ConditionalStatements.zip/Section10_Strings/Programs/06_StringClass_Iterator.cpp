#include <iostream>
#include <string>
//string::iteratro; string::reverse_iterator; s.begin(); s.end(); s.rbegin(); s.rend();
using namespace std;

int main(){
    string s1 = "cloud";
    string::iterator it;
    for(it=s1.begin();it!=s1.end();it++){
        cout<<*it;
        *it=*it-32;
    }
    cout<<"\nin caps : ";
    cout<<s1;
cout<<endl;
string s2="Programming";
    string::reverse_iterator r_it;
    for(r_it=s2.rbegin(); r_it!=s2.rend();r_it++){
        cout<<*r_it;
    }
    cout<<endl;
    for(int i=0;s2[i]!='\0';i++){
        cout<<s2[i];
    }    
    cout<<endl;
    for(int i=0;i<s2.length();i++){
        cout<<s2[i];
    }   
     cout<<endl;
    for(int i=s2.length();i>=0;i--){
        cout<<s2[i];
    }  
    cout<<endl;
    for(int i=s2.length()-1;i>=0;i--){
        cout<<s2.at(i);
    }  
}