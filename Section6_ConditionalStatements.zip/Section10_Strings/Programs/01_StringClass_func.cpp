#include <iostream>
#include <string>
using namespace std;
//s.length(); s.size(); s.capacity(); s.resize(n); s.max_size(); s.empty(); s.clear();
//str.shrink_to_fit();


int main(){
    string s1 = "hello";
    cout<<"s1: "<<s1<<endl;
    cout<<"s1.length() : "<<s1.length()<<endl;
    cout<<"s1.size() : "<<s1.size()<<endl;
    string *p = &s1;
    cout<<"Address of s1 :"<<p<<endl;
    cout<<"dereferencing of s1 :"<<*p<<endl;

    cout<<"s1.capacity() : "<<s1.capacity()<<endl;
    s1.resize(16);
    cout<<"after s1.resize()"<<endl;
    cout<<"s1.capacity() : "<<s1.capacity()<<endl;
    cout<<"s1.length() : "<<s1.length()<<endl;
    delete p;
    p=nullptr;
    string *p1 = &s1;
    cout<<"Address of s1 after resize : "<<p1<<endl;
    cout<<"resize() will increase or decrease the capacity(size) of the string and address will be same(no new memory occupied)"<<endl;
    cout<<"s1.max_int() "<<s1.max_size()<<endl;
    s1.clear();
    cout<<"after clearing s1 : s1.clear() "<<s1<<endl;
    string s2 = "SomeString";
    cout<<"s2 : "<<s2<<endl;
    cout<<"s2.empty() : returns true(1) if string is empty else false(0) -> "<<s2.empty()<<endl;
    s2.clear();
    cout<<"after clearing s2"<<endl;
    cout<<"s2.empty() : returns true(1) if string is empty else false(0) -> "<<s2.empty()<<endl;

    

}