#include <iostream>
#include <string>
//s.append(""); s.insert(index,""); s.insert(index,"",num)
using namespace std;

int main(){
    string s1 = "Hello";
    string *p = &s1;
    cout<<"s1 : "<<s1<<endl;
    s1.append(" World");
    cout<<"s1 : "<<s1<<endl;
    cout<<"Address of s1 : "<<p<<endl;
    cout<<"s1.length() : "<<s1.length()<<endl;
    cout<<"s1.capacity() : "<<s1.capacity()<<endl;
    s1.append("! How are you? asasddddddddddddddddddssssssssssss ssssssssss");
    string *p1=&s1;
    cout<<"s1 : "<<s1<<endl;
    cout<<"Address of s1 : "<<p1<<endl;
    cout<<"s1.length() : "<<s1.length()<<endl;
    cout<<"s1.capacity() : "<<s1.capacity()<<endl;

    string s2="hello how you";
    cout<<"s2 : "<<s2<<endl;
    cout<<"s2.insert(6,\"user \") : "<<s2.insert(6,"user ")<<endl;
    cout<<"s2.insert(15,\"are ook\",3) : "<<s2.insert(15,"are ook",4)<<endl;

}