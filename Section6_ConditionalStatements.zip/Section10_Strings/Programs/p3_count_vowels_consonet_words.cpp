#include <iostream>
#include <string>
using namespace std;

int main()
{
    string s;
    cout << "Enter a String : ";
    getline(cin, s);
    cout << "s : " << s << endl;
    int vowel = 0, consonent = 0, word = 0,spcl_Char=0,number=0;
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == ' ')
        { 
            if(s[i+1]!=' ' && s[i+1]!='\0'){
                word++;
            }
        }
        else
        {
            if ((s[i] >= 65 && s[i] <= 90) || (s[i] >= 97 && s[i] <= 122))
            {
                if (s[i] == 'a' || s[i] == 'e' || s[i] == 'i' || s[i] == 'o' || s[i] == 'u' || s[i] == 'A' || s[i] == 'E' || s[i] == 'I' || s[i] == 'O' || s[i] == 'U')
                {
                    vowel++;
                }
                else
                {
                    consonent++;
                }
            }
            else if(s[i]>=48 && s[i]<=57){
                number++;
            }
            else{
                spcl_Char++;
            }
        }
    }
    cout << "Vowel count : " << vowel << endl;
    cout << "Consonent count : " << consonent << endl;
    cout << "Words : " << word+1 << endl;
    cout << "spcl Char count : " << spcl_Char << endl;
    cout << "number count : " << number << endl;


}