#include <iostream>
#include <cstring>
//strtok, strtol, strtof
using namespace std;

int main(){
    char s1[50] = "Programming;in;c++;is;Fun";
    char s2[] = "x=10;y=20;z=30";

    char *token = strtok(s2,";"); //we can also pass multiple delimiters - " ;" "=;"
    //here the token is the pointer to s1 so the address of s1 and token will be same
    // cout<<" s1 : "<<&s1<<endl;
    // cout<<" token : "<<&token<<endl;
    // cout<<token<<endl;
    while (token!=NULL){
        cout<<token<<" "<<endl;

        token = strtok(NULL,";"); // when NULL is given in strtok, it will consider the previous String where Strtok was used
    }


    char s3[] = "1000";
    char s4[] = "54.23";
    //Converts String to long int
    long int x = strtol(s3,NULL,10);
    cout<<"strtol(s3,NULL,10) -> "<<x<<endl;
    cout<<"x + 10 = "<<x+10<<endl;
    //Converts string to float
    float y = strtof(s4,NULL);
    cout<<"strtof(s4,NULL) -> "<<y<<endl;
    cout<<"y+ 10 = "<<y+10<<endl;



}