#include <iostream>
using namespace std;

int main(){
    float basic;
    float perc_allowance;
    float perc_deductions;
    float salary;
//NetSalary = basic + basic*allowance - basic*deduction

    cout<<"Enter Basic Pay : ";
    cin>>basic;

    cout <<"Enter Percentage of allowance : ";
    cin>>perc_allowance;

    cout << "Enter Percentage of dedecutions : ";
    cin>>perc_deductions;

    salary = basic + (basic*(perc_allowance/100)) - (basic*(perc_deductions/100));

    cout << "Salary is " <<salary;
    return 0;


}