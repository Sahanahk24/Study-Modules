#include <iostream> 
#include <limits.h>
using namespace std;

int main ()
{

    char x = 127;
    x++;

    cout << "x : "<< x << endl;
    cout << "x : "<< (int)x << endl;

    int y= INT_MAX;
    cout << y << endl;
    y++;
    cout << y << endl;
}