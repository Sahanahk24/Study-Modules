#include <iostream>
using namespace std;

int main(){
    cout << "Bitwise Opertaors - &, |, ^, ~, <<, >>" << endl;

    cout << "AND (&)" << endl;

    int x = 11, y = 5;
    int a = x & y;
    cout << a << endl; //1

    cout << "OR (|)" << endl;
    int b = x | y;
    cout << b << endl; //15

    cout << "XOR (^)" << endl;
    int c = x ^ y;
    cout << c << endl; //14

    cout << "Left Shift (<<)" << endl;
    int d = y << 1;
    cout << d << endl; //10

    cout << "Right Shift (>>)" << endl;
    int w = 20;
    int e = 20 >> 1;
    cout << e << endl; //10

    cout << "NOT (~)" << endl;
    int z = ~y;
    cout << z << endl; //-6

cout <<"####" << endl;
    int m = 25;
    cout << ~m << endl; //-26
}