#include <iostream>
using namespace std;

int main(){
    unsigned int num = -1;
    int x = num;
    cout<<"num : " << num << "\tx : " << x << endl;
    return 0;
}