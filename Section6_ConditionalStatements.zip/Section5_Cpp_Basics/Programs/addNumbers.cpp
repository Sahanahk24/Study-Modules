#include <iostream>
//using namespace std;

// int main(){
// 	int num1, num2, sum;
// 	std::cout<<"Enter two numbers to add "<<std::endl;
// 	std::cout<<"Enter 1st number : ";
// 	std::cin>>num1;
// 	std::cout<<"Enter 2nd number : ";
// 	std::cin>>num2;
// 	sum = num1 + num2;
// 	std::cout<<"Sum of "<<num1<<" and "<<num2<<" is "<<sum<<std::endl;
// 	//return 0;
// }




using namespace std;

int main(){
	int num1, num2, sum;
	cout<<"Enter two numbers to add "<<endl;
	cout<<"Enter 1st number : ";
	cin>>num1;
	cout<<"Enter 2nd number : ";
	cin>>num2;
	sum = num1 + num2;
	cout<<"Sum of "<<num1<<" and "<<num2<<" is "<<sum<<endl;
	//return 0;
}