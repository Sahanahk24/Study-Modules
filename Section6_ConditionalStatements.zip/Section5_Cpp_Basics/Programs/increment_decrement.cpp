#include <iostream>
using namespace std;

int main(){
    int x, y;
    x = 5;

    y = x++; //change the y value as x++, ++x, x--, --x and see the change in results

    cout << "x : " << x << endl;
    cout << "y : " << y << endl;

}