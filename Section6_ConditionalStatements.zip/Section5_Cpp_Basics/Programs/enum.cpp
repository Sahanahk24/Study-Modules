#include <iostream>
using namespace std;


enum day {mon = 1, tue, wed, thur, fri, sat, sun};

int main(){
    // day d;
    // d= mon;
    // cout<< mon << endl;
    int i;
    for (i=mon; i<=sun;i++){
        cout<<i<<endl;
    }
    return 0;
}