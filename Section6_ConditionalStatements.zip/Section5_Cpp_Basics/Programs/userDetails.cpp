#include <iostream>
#include <string>

using namespace std;

typedef string names;

void anotherFunction(names n1, names n2)
{
    cout<<"\nIts good to have you along with us, "<<n1<<endl;
    cout<<"Have a great evening, "<<n2<<endl;
}


int main() {
    int id;
    string name;
    string name2;
	cout << "Enter User name : ";
    cin >> name;

    cout << "Enter User Id : ";
    cin >> id;
    cout << "User name is - "<< name << " and Id is - " << id << endl;
    cin.ignore();

    cout<<"May I know your name ";
    //cin >> name2;
    getline(cin, name2);
    cout << "Hello " << name2;
    anotherFunction(name, name2);

    return 0;
}