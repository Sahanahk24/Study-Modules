#include <iostream>
#include <cmath>
using namespace std;


int power(int num, int power)
{
    int mulitplier = num;
    for(int i=1; i<power; i++)
    {
        num *= mulitplier;
    }
    return num;
}

int main(){
    float radius, area;
    cout << "Enter radius : \t";
    cin >> radius;
    area = 22/7.0 * pow(radius,2);
    cout << "Area of Triangle is " << area<<endl;

    cout<<"2^2 : "<<power(2,2)<<endl;
    cout<<"2^3 : "<<power(2,3)<<endl;
    cout<<"2^4 : "<<power(2,4)<<endl;

}