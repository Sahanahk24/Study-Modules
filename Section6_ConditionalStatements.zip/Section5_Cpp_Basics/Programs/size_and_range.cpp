#include <iostream>
#include <limits>
using namespace std;

int main()
{
    cout << "Size of char : " << sizeof(char) << " bytes" << endl;
    cout << "Range of char : " << static_cast<int>(numeric_limits<char>::min()) << " to " << static_cast<int>(numeric_limits<char>::max()) << endl
         << endl;
    cout << "Size of signed char : " << sizeof(char) << " bytes" << endl;
    cout << "Range of signed char : " << static_cast<int>(numeric_limits<signed char>::min()) << " to " << static_cast<int>(numeric_limits<signed char>::max()) << endl
         << endl;

    cout << "Size of unsigned char : " << sizeof(char) << " bytes" << endl;
    cout << "Range of unsigned char : " << static_cast<int>(numeric_limits<unsigned char>::min()) << " to " << static_cast<int>(numeric_limits<unsigned char>::max()) << endl
         << endl;

    cout << "Size of int/signed int : " << sizeof(int) << " bytes" << endl;
    cout << "Range of int/signed int : " << numeric_limits<int>::min() << " to " << numeric_limits<int>::max() << endl
         << endl;

    cout << "Size of unsigned int : " << sizeof(unsigned int) << " bytes" << endl;
    cout << "Range of unsigned int : " << numeric_limits<unsigned int>::min() << " to " << numeric_limits<unsigned int>::max() << endl
         << endl;

    cout << "Size of signed short int/short int : " << sizeof(short int) << " bytes" << endl;
    cout << "Range of signed short int/short int : " << numeric_limits<short int>::min() << " to " << numeric_limits<short int>::max() << endl
         << endl;

    cout << "Size of unsigned short int : " << sizeof(unsigned short int) << " bytes" << endl;
    cout << "Range of short int : " << numeric_limits<unsigned short int>::min() << " to " << numeric_limits<unsigned short int>::max() << endl
         << endl;

    cout << "Size of long int : " << sizeof(long int) << " bytes" << endl;
    cout<< "Range of long int : "<<numeric_limits<long int>::min() << " to "<<numeric_limits<long int>::max() << endl 
          << endl;

    cout << "Size of float : " << sizeof(float) << " bytes" << endl;
    cout << "Range of float : " << numeric_limits<float>::min() << " to " << numeric_limits<float>::max() << endl
         << endl;

    cout << "Size of double : " << sizeof(double) << " bytes" << endl;
    cout << "Range of double : " << numeric_limits<double>::min() << " to " << numeric_limits<double>::max() << endl
         << endl;

    cout << "Size of wchar_t : " << sizeof(wchar_t) << " bytes" << endl;
    cout << "Range of wchar_t : " << numeric_limits<wchar_t>::min() << " to " << numeric_limits<wchar_t>::max() << endl
         << endl;

    cout << "Size of char : " << sizeof(char) << " bytes" << endl;
    cout << "Range of char : " << static_cast<int>(numeric_limits<char>::min()) << " to " << static_cast<int>(numeric_limits<char>::max()) << endl
         << endl;

    return 0;
}