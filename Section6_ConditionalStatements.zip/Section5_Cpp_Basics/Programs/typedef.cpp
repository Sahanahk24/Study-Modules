#include <iostream>
using namespace std;

//example for usage of typedef

// int main(){
//     int m1,m2,r1,r2;
//     .
//     .
//     .
//     .
// }

typedef int marks;
typedef int roll_no;

int main(){
    marks m1,m2;
    roll_no r1,r2;

return 0;
}

