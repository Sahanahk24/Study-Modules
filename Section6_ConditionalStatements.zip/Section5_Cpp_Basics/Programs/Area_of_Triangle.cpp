#include <iostream>
using namespace std;

int main(){
    float height, base, area;
    cout << "Enter Height : \t";
    cin >> height;
    cout << "Enter base : \t";
    cin >> base;
    area = (base*height)/2;
    cout << "Area of Triangle is " << area;
}