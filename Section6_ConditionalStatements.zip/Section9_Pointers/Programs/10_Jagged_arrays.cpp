/*
1 2 3
2 3
4 4 5 2 2
3 4 5
*/

#include <iostream>

using namespace std;

int main(){
    cout<<"2D Array in Heap - Jagged Array\n";
    int rows;
    cout<<"rows: ";
    cin>>rows;
    int cols[rows];
    cout<<"Enter cols for Jagged Array : ";
    for(int i=0; i<rows; i++)
    {
        cin>>cols[i];
    }

    cout<<"Creating Jagged Array\n";

    int c=0;
    //creating  2D array
    int **arr = new int*[rows];
    for(int i=0; i<rows; i++)
    {
        if(c<rows)
        {
            arr[i] = new int[cols[c]];
        }
        c++;
    }

    c=0;
    //taking input
    for(int i=0; i<rows; i++)
    {
        if(c<rows)
        {
            for(int j=0; j<cols[c]; j++)
            {
                cin>>arr[i][j];
            }
        }
        c++;
    }
    //produce output
    c=0;
    for(int i=0; i<rows; i++)
    {
        if(c<rows)
        {
            for(int j=0; j<cols[c]; j++)
            {
                cout<<arr[i][j]<<" ";
            }
            cout<<endl;
        }
        c++;
    }

    //deallocate memory
     for(int i=0; i<rows; i++)
    {
        delete[] arr[i];
    }

    delete[] arr;

    arr = nullptr;
}