#include <iostream>
using namespace std;

void getMinAndMax(int Arr[], int size, int *min, int *max){
    for(int i=1; i<size; i++){
        if(Arr[i] < *min){
            *min = Arr[i];
        }
        if(Arr[i] > *max){
            *max = Arr[i];
        }
    }
}

int main(){
    int size;
    cout<<"Enter the size of an Array : ";
    cin>>size;
    int A[size];
    cout<<"Enter the Array Elements : ";
    for(int i=0; i<size; i++){
        cin>>A[i];
    }
    int min=A[0];
    int max=A[0];
    getMinAndMax(A, size, &min, &max);
    cout<<"Min : "<<min<<endl;
    cout<<"Max : "<<max<<endl;

}