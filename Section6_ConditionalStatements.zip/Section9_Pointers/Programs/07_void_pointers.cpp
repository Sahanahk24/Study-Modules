// C++ Program to demonstrate the declaration and use of a 
// void pointer 

#include <iostream> 
using namespace std; 

int main() 
{ 
	int a = 10; 

	// void pointer holds address of int 'a' 
	void* myptr = &a; 
	// printing the value of a and adress of a stored in 
	// myptr 
	cout << "The value of a is: " << a << endl; 
	cout << "The Adress of a is " << myptr << endl; 
    // cout << "Dereferencing a " << *myptr<<endl; 
    //Error as we cannot dereference a void pointer directly
    //We need to typeCast it for dereferencing the pointer
    cout << "Dereferencing a " << *(int *)myptr<<endl;

}
 