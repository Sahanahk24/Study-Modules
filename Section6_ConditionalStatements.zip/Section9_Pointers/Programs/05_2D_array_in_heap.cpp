#include <iostream>

using namespace std;

int main(){
    cout<<"Array in heap \n";
    int *p = new int[5];
    p[0]= 12;
    p[1]= 2;
    p[2]= 23;
    for(int i=0; i<5; i++){
        cout<<p[i]<<endl;
    }
    cout<<endl;
    delete []p;
    p=nullptr;


    cout<<"2D Array in Heap\n";
    int rows, cols;
    cout<<"rows: ";
    cin>>rows;
    cout<<"cols: ";
    cin>>cols;

    //creating  2D array
    int **arr = new int*[rows];
    for(int i=0; i<rows; i++)
    {
        arr[i] = new int[cols];
    }


    //taking input
    for(int i=0; i<rows; i++)
    {
        for(int j=0; j<cols; j++)
        {
            cin>>arr[i][j];
        }
    }

    //produce output
     for(int i=0; i<rows; i++)
    {
        for(int j=0; j<cols; j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }

    //deallocate memory
     for(int i=0; i<rows; i++)
    {
        delete[] arr[i];
    }

    delete[] arr;

    arr = nullptr;
}