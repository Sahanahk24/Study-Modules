#include <iostream>
using namespace std;

int main(){
    int A[5]{112,3,4,5,6};
    int *p = A, *q=&A[3];

    cout<<p<<" "<<*p<<endl;
    p++;
    cout<<p<<" "<<*p<<endl;
    p--;
    cout<<p<<" "<<*p<<endl;
    p=p+4;
    cout<<p<<" "<<*p<<endl;
    p=p-2;
    cout<<p<<" "<<*p<<endl;
    cout<<q<<" "<<*q<<endl;
    // p=p+5; //garbage value
    // cout<<p<<" "<<*p<<endl;


    int d=p-q;
    cout<<d<<endl;

    for(int i=0; i<5; i++){
        cout<<A[i]<<" ";
    }
    cout<<endl;
    for(int i=0; i<5; i++){
        cout<<i[A]<<" ";
    }
    cout<<endl;
    for(int i=0; i<5; i++){
        cout<<A+i<<" ";
    }
    cout<<endl;
    for(int i=0; i<5; i++){
        cout<<*(A+i)<<" ";
    }
    cout<<endl;
    delete p;  //since we are assigning the memory address of A[0] to p which makes it only a int pointer
                // in case if *p = new int[size] then use delete []p;
    p=nullptr;
    int *w=&A[0];
    for(int i=0; i<6; i++){
        cout<<w[i]<<" ";
    }
    cout<<endl;
    delete w;
    w=nullptr;
}