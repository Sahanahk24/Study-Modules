#include <iostream>
using namespace std;

int main(){
    cout<<"Pointer\n"; //(pointer is a variable which stores the address of the data)
    int x = 10;
    int* p; //declaration  (we use * before as prefix to name a pointer variable)
    p = &x; //initialization (we assigne the address of data to pointer variable)

    cout<<x<<endl;  //10
    cout<<&x<<endl; //200
    cout<<p<<endl;  //200
    cout<<&p<<endl; //300
    cout<<*p<<endl; //10 - dereferencing a pointer variable, this gives the value of data stored in that address
    cout<<*(p+3)<<endl; //garbage value
    cout<<"\nPointer to Pointer\n";

    int** q = &p;  
    cout<<q<<endl; //300
    cout<<*q<<endl; //200
    cout<<p<<endl; //200
    cout<<**q<<endl; //10

}