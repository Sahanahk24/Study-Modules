#include <iostream>
using namespace std;

void printArray(int arr[], int n)
{
    cout<<*arr+1<<endl;
    cout<<*(arr+1)<<endl<<endl;
    for(int i=0; i<n; i++)
    {
        cout<<*(arr+i)<<" ";
    }
    cout<<endl<<endl;
}

int main()
{
    cout<<"array\n";
    int arr[] = {11,22,33,44,55};

    printArray(arr,5);

    int *p = new int[5]; //Creating an Array in Heap memory
    p[1]=12;
    p[3]=39;
    cout<<p<<endl;
    for(int i=0; i<5; i++){
        cout<<"p["<<i<<"] : "<<p[i]<<" "<<&p[i]<<endl;
    }

    cout<<endl;

    int A[5] = {12,39};
    for(int i=0; i<5; i++){
        cout<<"A["<<i<<"] : "<<A[i]<<" "<<&A[i]<<endl;
    }

    //a[i] = *(a+i)
    //i[a] = *(i+a) 

    cout<<endl;
    for(int i=0; i<5; i++){
        cout<<i<<"[A] : "<<i[A]<<" "<<&i[A]<<endl;
    }

    cout<<p<<endl;
    delete []p;
    cout<<p<<endl;
    p=nullptr;
    cout<<p<<endl;

    
    
}
