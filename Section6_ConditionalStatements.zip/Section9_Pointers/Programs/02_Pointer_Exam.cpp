#include <iostream>
using namespace std;

int main(){
    int x=10;
    int *p = &x;
    char s = 'a';
    char *ch = &s;

    cout<<"size of int x : "<<sizeof(x)<<endl;
    cout<<"size of int pointer : "<<sizeof(p)<<endl;
    cout<<"size of char s : "<<sizeof(s)<<endl;
    cout<<"size of char pointer : "<<sizeof(ch)<<endl<<endl;

   cout<<"assume address of 0th index of array is 200. What is the output -\n";

    char b[] = "xyzabc";
    char *q = &b[1];
    cout << q << endl;
    cout << *q << endl;


    int *h = new int[5];
    h[1] = 23;
    //cout<<*h<<endl;
    for(int i=0; i<5; i++)
    {
        cout<<"&h["<<i<<"] : "<<&h[i]<<" "<<h[i]<<endl;
    }
    cout<<endl;

    cout<<"&h[1] : "<<&h[1]<<" "<<h[1]<<endl;
    cout<<"&h[2] : "<<&h[2]<<endl;
    cout<<"&h[3] : "<<&h[3]<<endl;
    cout<<"&h[4] : "<<&h[4]<<" "<<h[4]<<endl;
    cout<<"h : "<<h<<endl;
    cout<<endl;
    
    int a[5] = {2,3,4};
    int *c = a;
    cout<<"a[] : "<<&a<<endl;
    cout<<"c : "<<c<<endl;
    cout<<"x : "<<x<<endl;
    cout<<"&x : "<<&x<<endl;
    cout<<"p : "<<p<<endl;
    cout<<"&p : "<<&p<<endl;
    cout<<"*p : "<<*p<<endl;
    cout<<"deleted1\n";
    delete c;
    c=nullptr;
    delete h;
    h=nullptr;
    delete p;
    cout<<"deleted2\n";
    cout<<"*p : "<<*p<<endl;
    p = nullptr;
    cout<<"deleted3\n"; ////////
    // cout<<"*p : "<<*p<<endl;
    cout<<p<<endl;
    cout<<*p<<endl; //terminates the program since the pointer is not pointer any where and it doesnt have value for that address
    cout<<"deleted4\n";
}


