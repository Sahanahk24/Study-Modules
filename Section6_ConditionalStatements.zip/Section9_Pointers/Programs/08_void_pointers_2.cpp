#include <iostream>
using namespace std;


void printNumber(int *ptr){
    cout<<*ptr<<endl;
}

void printLetter(char *ptr){
    cout<<*ptr<<endl;
}

void printValue(void *ptr, char type){
    switch (type)
    {
    case 'i':
        cout<<*(int *)ptr<<endl;
        break;
    case 'c':
        cout<<*(char *)ptr<<endl;
        break;
    default:
        cout<<"Invalide Operation\n";
    }
}

int main(){
    int a=10;
    char c='w';
    printNumber(&a);
    printLetter(&c);
    cout<<"generic pointer : void pointer usage\n";
    printValue(&a,'i');
    printValue(&c,'c');

}