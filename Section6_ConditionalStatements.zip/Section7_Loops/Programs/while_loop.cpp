#include <iostream>
using namespace std;

// int main(){
//     int n,i=1; 
//     cout<<"Enter the number : ";
//     cin>>n;
//     while(i<=n){
//         if(i==1)
//         {
//             cout<<i<<" time"<<endl;
//         }
//         else
//         {
//             cout<<i<<" times"<<endl;
//         }
//         i++;
//     }
//     return 0;
// }

///////////////////////////////Infinite while Loop

int main(){
    int n,i=1; 
    cout<<"Enter the number : ";
    cin>>n;
    while(1){  //always true so infinite loop
        cout<<i<<" times"<<endl;
        i++;
        // if(i>n){
        //     break; // apply a condition to exit out of infinit loop
        // }
    }
    return 0;
}

// int main(){
//     int n,i=1; 
//     cout<<"Enter the number : ";
//     cin>>n;
//     while(i<=n){
//         cout<<i<<" times"<<endl;
//         //No updation so infinite loop again
//     }
//     return 0;
// }