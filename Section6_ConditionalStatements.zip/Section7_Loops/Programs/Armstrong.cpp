//Armstrong ==> 153 == 1^3 + 5^3 + 3^3

#include <iostream>
using namespace std;

int main(){
    int num;
    cout<<"Enter the Number : ";
    cin>>num;
    int m = num;
    int sum=0;
    while(num>0){
        int digit = num%10;
        sum += digit*digit*digit;
        num = num/10; 
    }
    if(sum==m)
    cout<<m<<" is Armstrong Number"<<endl;
    else
    cout<<m<<" is Not an Armstrong Number"<<endl;
}