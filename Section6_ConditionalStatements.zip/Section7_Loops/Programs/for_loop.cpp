#include<iostream>
using namespace std;

int main(){
    int n;
    cout<<"Enter the Number : ";
    cin>>n;
    for(int i =1; i<=n; i++){
        cout<<i<<" times"<<endl;
    }
    return 0;
}

/////////////////////Infinite loop

// int main(){
//     int n;
//     cout<<"Enter the Number : ";
//     cin>>n;
//     int i=1;
//     for(; ;){
//         cout<<i<<" times"<<endl;
//        // i++;
//     }
//     return 0;
// }

//To break infinite loop

// int main(){
//     int n;
//     cout<<"Enter the Number : ";
//     cin>>n;
//     int i=1;
//     for(; ;){
//         cout<<i<<" times"<<endl;
//         i++;
//         if(i>=10){
//             break;
//         }
//     }
//     return 0;
// }