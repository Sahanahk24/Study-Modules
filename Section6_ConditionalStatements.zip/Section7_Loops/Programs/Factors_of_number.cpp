#include <iostream>
using namespace std;

int main()
{
    int num;
    cout<<"Enter the Number to get Factors of it : ";
    cin>>num;
    int prod=1;
    cout<<"Factors of "<<num<<" are : ";
    for(int i=1; i<=num; i++)
    {
        if(num%i==0)
        {
            cout<<i<<" ";
        }
    }
}