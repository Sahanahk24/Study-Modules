// Using While Loop

// #include <iostream>
// using namespace std;


//Using For Loop  n(n+1)/2

#include <iostream>
using namespace std;

int main(){
    int num;
    cout<<"Enter the Number to get sum of first 'n' numbers : ";
    cin>>num;
    int sum=0;
    for(int i=1; i<=num; i++){
        sum+=i;
    }
    cout<<"Sum of first "<<num <<" is : "<<sum<< endl;
    cout<<"Formula "<<num*(num+1)/2<<endl;
}