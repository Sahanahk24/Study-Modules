#include <iostream>
using namespace std;

int main(){
    int num;
    cout<<"Enter the Number to get Facatorial of 'nth' number : ";
    cin>>num;
    int prod=1;
    for(int i=1; i<=num; i++){
        prod*=i;
    }
    cout<<"Factorial of "<<num <<" is : "<<prod<< endl;
}