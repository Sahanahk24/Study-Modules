// Perfect_number - Sum of factor of a number == 2*number

#include <iostream>
using namespace std;

int main(){
    int num;
    cout<<"Enter the Number to get Factors of it : ";
    cin>>num;
    int prod=1, sum=0;
    cout<<"Factors of "<<num<<" are : ";
    for(int i=1; i<=num; i++){
        if(num%i==0){
            cout<<i<<" ";
            sum+=i;
        }
    }
    cout<<"\nSum of all Factors : "<<sum<<endl;
    
    if(sum==2*num){
        cout<<num<<" is a Perfect Number"<<endl;
    }else{
        cout<<num<<" is Not a Perfect Number"<<endl;
    }
}