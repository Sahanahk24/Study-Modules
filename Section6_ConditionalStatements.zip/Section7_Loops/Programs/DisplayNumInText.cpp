#include <iostream>
using namespace std;

int main(){
    int num, dig, rev=0, m;
    m= num;
    cout<<"Enter the Number : ";
    cin>>num;
    while(num>0){
        dig = num%10;
        num = num/10;
        rev =  rev*10 + dig;
    }

    int pal = 0, d;
    while(rev>0){
        d = rev%10;
        rev = rev/10;
        switch(d){
            case 0 : cout<<"zero "; break;
            case 1 : cout<<"One "; break;
            case 2 : cout<<"Two "; break;
            case 3 : cout<<"Three ";break;
            case 4 : cout<<"Four ";break;
            case 5 : cout<<"Five ";break;
            case 6 : cout<<"Six ";break;
            case 7 : cout<<"Seven ";break;
            case 8 : cout<<"Eight "; break;
            case 9 : cout<<"Nine ";break;
        }
    }



}