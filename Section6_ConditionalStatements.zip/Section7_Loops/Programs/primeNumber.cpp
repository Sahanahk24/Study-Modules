#include <iostream>
using namespace std;

int main(){
    int num,prime;
    cout<<"Enter number to check if its Prime or not: ";
    cin>>num;
    bool flag = true;
    for(int i=2; i<num; i++){
        if(num%i==0){
            flag = false;
        }
    }
    if(flag){
        cout<<num<<" is a Prime Number"<<endl;
    }
    else{
        cout<<num<<" is Not a Prime Number"<<endl;
    }
}