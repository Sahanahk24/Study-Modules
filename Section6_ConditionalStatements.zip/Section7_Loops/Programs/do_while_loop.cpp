#include <iostream>
using namespace std;

// int main(){
//     int n,i=1; 
//     cout<<"Enter the number : ";
//     cin>>n;
//     do{
//         cout<<i<<" times"<<endl;
//         i++;
//     }while(i<=n);
//     return 0;
// }

/////////////////////////////Infinite while Loop

// int main(){
//     int n,i=1; 
//     cout<<"Enter the number : ";
//     cin>>n;
//     do{  //always true so infinite loop
//         cout<<i<<" times"<<endl;
//         i++;
//         if(i>100){
//             break;
//         }
//     }while(1); //always true so infinite loop
//     return 0;
// }

int main(){
    int n,i=1; 
    cout<<"Enter the number : ";
    cin>>n;
    do{
        cout<<i<<" times"<<endl;
        //No updation so infinite loop again
    }while(i<=n);
    return 0;
}