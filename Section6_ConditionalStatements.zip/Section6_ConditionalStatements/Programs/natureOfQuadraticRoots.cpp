#include <iostream>
#include <cmath>

using namespace std;

// (-b+-sqrt(b^2 - 4ac)) / (2a) 

// d = b*b - 4*a*c

// if d = 0 --> Roots are real and equal
// if d > 0 --> Roots are real and unique
// if d < 0 --> roots are imaginary
typedef int quad_variables;

int main(){
    quad_variables a,b,c,r1,r2;
    int d;
    cout<<"Enter values : ";
    cin >> a >> b >> c ;
    d = b*b - 4*a*c;
    if(d==0){
        cout <<"Roots are real and equal : "<<-b/(2*a*c); // 1 4 4
    }
    else if(d>0){
        cout <<"Roots are real and Unique : "<<(-b+sqrt(d))/(2*a)<< " "<<(-b-sqrt(d))/(2*a); //1 4 2
    }
    else{
        cout<<"roots are imaginary : "<<(-b+sqrt(d))/(2*a)<<" "<<(-b-sqrt(d))/(2*a);//4 4 4
    }
}