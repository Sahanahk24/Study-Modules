#include<iostream>
using namespace std;

int main()
{
    int option,a,b,c;
    cout<<"Enter 2 numbers\n";
    cin >> a>>b;
    float d;
    cout<<"Operation to perform\n";
    cout<<"1. Addition\n"<<"2. Subtraction\n" <<"3. Multiply\n"<<"4. Division\n";
    cin>>option;

    switch(option){
        case 1:
            c = a+b;
            cout<<"add : "<<c<<endl;
            break;
        case 2:
            c = a-b;
            cout<<"sub : "<<c<<endl;
            break;
        case 3:
            c = a*b;
            cout<<"multi : "<<c<<endl;
            break;
        case 4:
            d = (float)a/b;
            cout<<"div : "<<d<<endl;
            break;
        default: cout<<"Invalid Operation\n"<<"Re-Enter Valid Number";
    }
}