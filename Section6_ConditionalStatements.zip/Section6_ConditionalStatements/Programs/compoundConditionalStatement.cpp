#include<iostream>
using namespace std;

int main()
{
    int age;
    cout<<"enter age to check if the person is young or not: ";
    cin>>age;
    if(age>=12 && age<=50){
        cout<<age<< " is young\n";
    }
    else{
        cout<<age<< " is not young\n";
    }
    cout<<"If the Person is not young then the person is eligible for offer\n";
    if(age<12 || age>50){
        cout<<age<< " - eligible for offer";
    }
    else{
        cout<<age<< " - not eligible for offer";
    }
}