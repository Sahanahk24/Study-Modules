#include<iostream>

using namespace std;

int main(){
    float x,y,z;
    cout<<"Enter 2 numbers : ";
    cin>>x>>y;
    if(y==0){
        cout<<y<< " Invalid Denominator ";
    }
    else{
        z=x/y;
        cout<<z<< " is result after dividing "<<x<<" by "<<y;
    }
}