#include <iostream>
using namespace std;

// Here the variable c will be allocated in the stack of main memory 
//and will remain until the execution of program is completed and then it will be removed/deleted
// int main(){
//     int a=10, b=5;
//     int c = a+b;
//     if(c>10){
//         cout<<c<<endl;
//     }
//     cout<<c;
// }

// Here the variable c will be allocated memory in stack of main memory 
// but it will remain only until the if() is getting executed and then it will be deleted.
int main(){
    int a=10, b = 5;
    if(true){
        int c = a+b;
        cout<<c;
    }
//    cout<<c;
}

// int main(){
//     int a=10,b=5;
//     if(int c=a+b; c>10){
//         cout<<c<<endl;
//     }
//     //cout<<c;
// }
//supported in c++17 and above