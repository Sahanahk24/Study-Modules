#include<iostream>

using namespace std;

int main(){
    int roll_no;
    cout<<"Enter Roll No to check if its valid or not : ";
    cin>>roll_no;
    if(roll_no>1){
        cout<<roll_no<< " is Valid Roll Number\n";
    }
    else{
        cout<<roll_no<< " is Invalid Roll Number\n";
    }
}