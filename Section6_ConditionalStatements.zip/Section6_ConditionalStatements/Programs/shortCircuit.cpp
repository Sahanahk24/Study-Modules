#include <iostream>
using namespace std;
int main()
{
int a=10,b=5;
int i=5,j=5,x=5,y=5;
if(a>b && ++i<=b)
 {
 }
 cout<<i<<endl;
if(a<b && ++j<=b)
 {
 }
 cout<<j<<endl;
if(a>b || ++x<=b){

}
cout<<x<<endl;
if(a<b || ++y<=b){

}
cout<<y<<endl;

}